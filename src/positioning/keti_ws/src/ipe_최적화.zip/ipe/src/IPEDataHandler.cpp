/******************************************************************************
*
* Copyright (C) 2023 - 2028 KETI, All rights reserved.
*                           (Korea Electronics Technology Institute)
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the 
), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running for Korean Government Project, or
* (b) that interact with KETI project/platform.
*
* THE SOFTWARE IS PROVIDED 
, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* KETI BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the KETI shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from KETI.
*
******************************************************************************/

#include "IPEDataHandler.h"

IPEDataHandler::IPEDataHandler(){
}

IPEDataHandler::~IPEDataHandler(){
}

DataPacket IPEDataHandler::next(){
    DataPacket packet;
    if(data_packet_buffer_.empty()){
        return DataPacket();
    }
    packet = data_packet_buffer_.front();
    return packet;
}

void IPEDataHandler::packetPop(){
    if(!data_packet_buffer_.empty()){
        data_packet_buffer_.pop_front();
    }
}

void IPEDataHandler::onLiveDataAvailable(IPEDataPacket packet){
    DataPacket data_packet;
    data_packet.first = packet.getTimestamp();
    data_packet.second = packet;
    data_packet_buffer_.push_back(data_packet);
}

bool IPEDataHandler::getBuffer_isempty(){  // 클래스 메소드로 정의
    return data_packet_buffer_.empty();
}
