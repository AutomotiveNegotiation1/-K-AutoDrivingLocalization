/******************************************************************************
*
* Copyright (C) 2023 - 2028 KETI, All rights reserved.
*                           (Korea Electronics Technology Institute)
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the 
), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running for Korean Government Project, or
* (b) that interact with KETI project/platform.
*
* THE SOFTWARE IS PROVIDED 
, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* KETI BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the KETI shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from KETI.
*
******************************************************************************/

#include "ros/ros.h"
#include "IPEcore.h"
#include <thread>

int main(int argc, char **argv)
{
    // ROS 노드 초기화
    ros::init(argc, argv, "Indoor_Positioning_node");
    ros::NodeHandle nh;

    // 테스트 모드 파라미터를 확인하여 IPEInterface 인스턴스 생성
    bool test_mode;
    nh.param("test_mode", test_mode, false);
    IPECore core(nh, test_mode);

    // 비동기 처리를 위한 스레드 생성
    std::thread spin_thread;

    std::thread spin_thread(&IPECore::run, &core);

    // 메인 스레드에서는 다른 작업을 수행할 수 있음
    // 예: 사용자 입력 처리, 상태 모니터링, 기타 비동기 작업 등

    // 스레드가 완료될 때까지 기다림
    spin_thread.join();

    return 0;
}
