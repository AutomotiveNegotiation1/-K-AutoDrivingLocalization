/******************************************************************************
*
* Copyright (C) 2023 - 2028 KETI, All rights reserved.
*                           (Korea Electronics Technology Institute)
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the 
), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running for Korean Government Project, or
* (b) that interact with KETI project/platform.
*
* THE SOFTWARE IS PROVIDED 
, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* KETI BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the KETI shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from KETI.
*
******************************************************************************/

#include "UWBHandler.h"

UWBHandler::UWBHandler(ros::NodeHandle _nh, _uwbnum, IPEDataPacket* _data_packet, IPEDataHandler* _data_handler) : data_packet_(_data_packet), data_handler_(_data_handler) {
    std::cout << "UWB setup UWBHandler starting..." << std::endl;
    std::ostringstream topic_name_stream;
    topic_name_stream << "/dwm1001/anchor/tag" << _uwbnum;
    std::string topic_name = topic_name_stream.str();
    sub_uwb_ = _nh.subscribe<ipe::Anchor>(topic_name, 10, &UWBHandler::uwbCallback, this);
}

UWBHandler::~UWBHandler(){
}

UWBHandler::uwbCallback(const ipe::Anchor::ConstPtr& _msg){
    data_packet_->setSensorUWB(_msg);
    data_packet_->setProcessUWB(_msg);

    if (data_handler_){
        data_handler_->onLiveDataAvailable(*data_packet_);
    }
}

UWBHandler::positioningUWB(IPEDataPacket* _data_packet){

    bool isEmpty = true;
    if (_data_packet->getNanchor() > 1){
        for(int i=0; i < (int)_data_packet->getNanchor(); i++){
            if(_data_packet->getRxID.data()[i] == 0){
                isEmpty = false;
                break;
            }
        }
    
        if (isEmpty){
            double UWBout[21];
            UWBpos6(_data_packet->getLn(), _data_packet->getLp(), _data_packet->getLnC(), _data_packet->getPP(), _data_packet->getNanchor(), _data_packet->getRxID().data(), _data_packet->getRxDist().data(), _data_packet->getTimestamp(), _data_packet->gettag_b_pos(), _data_packet->getxain_list().data(), _data_packet->getyain_list().data(), _data_packet.getPrevTagPos(), -_data_packet->getkf_psi(), UWBout);
            _data_packet->setUWBEstPos(UWBout);

        }
    }
}   
