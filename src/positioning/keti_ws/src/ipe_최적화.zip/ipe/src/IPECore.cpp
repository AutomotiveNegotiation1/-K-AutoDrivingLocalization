/******************************************************************************
*
* Copyright (C) 2023 - 2028 KETI, All rights reserved.
*                           (Korea Electronics Technology Institute)
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the 
), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running for Korean Government Project, or
* (b) that interact with KETI project/platform.
*
* THE SOFTWARE IS PROVIDED 
, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* KETI BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the KETI shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from KETI.
*
******************************************************************************/

#include "IPECore.h"

IPECore::IPECore(ros::NodeHandle& _nh, bool _test_mode){
    init(_nh, _test_mode);
}

IPECore::~IPECore(){
    if (test_mode_){
        delete uwb_handler_;
        delete imu_handler_;
    }
}

IPECore::init(ros::NodeHandle& _nh, bool _test_mode){
    test_mode_ = _test_mode;
    nh_ = _nh;

    // 하드웨어 셋팅 클래스 초기화

    try {
        registerSubcribers(nh_);
    } catch (const std::exception& e) {
        ROS_ERROR("%s", e.what());
    }
}

IPECore::registerSubscribers(ros::NodeHandle& _nh){
    bool m_should_publish;
    IMUHandler* _imuHandler = new IMUHandler(_nh, &data_packet_, &data_handler_);
    std::list<double> totalTag;

    if (ros::param::get("/ipe_node/Tag_on", m_should_publish) && m_should_publish) {
        for(int i = 0; i < 4; i++) {
            std::string param_name = "/ipe_node/sub_UWB" + std::to_string(i);
            if (ros::param::get(param_name, m_should_publish) && m_should_publish) {
                UWBHandler* _uwbHandler = new UWBHandler(_nh, std::to_string(i), &data_packet_, &data_handler_);
                registerCallback(_uwbHandler);
            }
        }
    }

    if (ros::param::get("/ipe_node/IMU_on", m_should_publish) && m_should_publish) {
        registerCallback(_imuHandler);
    }
}

IPECore::registerCallback(PacketCallback _packet_callback){
    packet_callback_.push_back(_packet_callback);
}

IPECore::run(){
    if(test_mode_){
        simulate();
    }
    else{
        positioning();
    }
}

IPECore::simulate(){
    rosbag::Bag bag;
    try {
        // bag.open("/home/umaps/rosbag/[zed_f9r]2023-08-31-17-56-41_slow.bag", rosbag::bagmode::Read);
        bag.open("/home/ubuntu/ros_delivery_workspace/-K-AutoDrivingLocalization/src/positioning/matlab/Positioning_Alg_20231004/2023-12-05-18-16-11.bag", rosbag::bagmode::Read);
    } catch (rosbag::BagException& e) {
        ROS_ERROR("Error opening bag file: %s", e.what());
    }

    // std::vector<std::string> topics = {
    //     "/dwm1001/anchor/ttyUWB0",
    //     "/dwm1001/anchor/ttyUWB1",
    //     "/dwm1001/anchor/ttyUWB2",
    //     "/dwm1001/anchor/ttyUWB3",
    //     "/zed_f9r/imu"
    // };

    std::vector<std::string> topics = {
        "/dwm1001/anchor/tag0",
        "/dwm1001/anchor/tag1",
        "/dwm1001/anchor/tag2",
        "/dwm1001/anchor/tag3",
        "/zed_f9r/imu"
    };

    std::map<std::string, ros::Publisher> publishers;

    for (const auto& topic : topics) {
        if (topic == "/zed_f9r/imu") {
            publishers[topic] = r_nh.advertise<sensor_msgs::Imu>(topic, 10);
        } else {
            publishers[topic] = r_nh.advertise<ipe::Anchor>(topic, 10);
        }
    }

    rosbag::View view(bag);

    for (const rosbag::MessageInstance& message : view) {
        if (publishers.find(message.getTopic()) != publishers.end()) {
            if (message.getTopic() == "/zed_f9r/imu") {
                sensor_msgs::Imu::ConstPtr imu_data = message.instantiate<sensor_msgs::Imu>();
                if (imu_data != NULL) {
                    publishers[message.getTopic()].publish(imu_data);
                }
            } 
            if (message.getTopic().find("/dwm1001/anchor/tag") == 0 && message.getTopic().back() >= '0' && message.getTopic().back() <= '3') {
                ipe::Anchor::ConstPtr uwb_data = message.instantiate<ipe::Anchor>();
                if (uwb_data != NULL) {
                    publishers[message.getTopic()].publish(uwb_data);
                }
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
            spinFor();  // Assuming that 'spinFor()' is some kind of sleep/delay function. If not, please clarify.
            ros::spinOnce();
        }
    }

    bag.close();
    ROS_INFO("Finish...");
}

IPECore::positioning(){
    while (ros::ok()) {
        spinFor();
        ros::spinOnce();
    }
}

IPECore::spinFor(){
    data_packet_ = data_handler_.next();
    if(data_packet_.getisUWB() && data_packet_.getisIMU()){
        for (auto& callback : packet_callback_) {
            ImuSubscriber* imuSub = dynamic_cast<ImuSubscriber*>(cb);
            if (data_packet_.second.frameID_ == "imu") {
                if (imuSub){
                    callback->preprocess(&data_packet_);
                    data_handler_.packetPop()
                    break;
                }
            } else {
                if (!imuSub){
                    callback->preprocess(&data_packet_);
                    data_handler_.packetPop()
                    break;
                }
            }
        }
    }
}

