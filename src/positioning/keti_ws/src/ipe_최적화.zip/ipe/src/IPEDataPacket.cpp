/******************************************************************************
*
* Copyright (C) 2023 - 2028 KETI, All rights reserved.
*                           (Korea Electronics Technology Institute)
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the 
), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running for Korean Government Project, or
* (b) that interact with KETI project/platform.
*
* THE SOFTWARE IS PROVIDED 
, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* KETI BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the KETI shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from KETI.
*
******************************************************************************/

#include "IPEDataPacket.h"

IPEDataPacket::IPEDataPacket(){
    // init();   
    this->imuDataType_ = 2;
    this->kalmanFlag_ = 1;

    this->isIMU_ = false;
    this->isUWB_ = false;
    this->init_flag = 0;
    getInitTag(this->prevTagPos);
}

IPEDataPacket::~IPEDataPacket(){
    // Do nothing
}

void IPEDataPacket::setSensorUWB(const ipe::Anchor::ConstPtr& _msg){
    this->frameID_ = extractNumber(_msg->header.frame_id);
    this->s_time_ = convertToDouble(_msg->header.stamp);
    this->anchorID_.assign(_msg->id.begin(), _msg->id.end());
    this->x_.assign(_msg->x.begin(), _msg->x.end());
    this->y_.assign(_msg->y.begin(), _msg->y.end());
    this->z_.assign(_msg->z.begin(), _msg->z.end());
    this->distanceFromTag_.assign(_msg->distanceFromTag.begin(), _msg->distanceFromTag.end());

    this->isUWB_ = true;
}

void IPEDataPacket::setSensorIMU(const sensor_msgs::Imu::ConstPtr& _msg){
    this->frameID_ = _msg->header.frame_id;
    this->s_time_ = convertToDouble(_msg->header.stamp);
    this->angular_x_.assign(_msg->angular_velocity.x.begin(), _msg->angular_velocity.x.end());
    this->angular_y_.assign(_msg->angular_velocity.y.begin(), _msg->angular_velocity.y.end());
    this->angular_z_.assign(_msg->angular_velocity.z.begin(), _msg->angular_velocity.z.end());
    this->linear_x_.assign(_msg->linear_acceleration.x.begin(), _msg->linear_acceleration.x.end());
    this->linear_y_.assign(_msg->linear_acceleration.y.begin(), _msg->linear_acceleration.y.end());
    this->linear_z_.assign(_msg->linear_acceleration.z.begin(), _msg->linear_acceleration.z.end());

    this->isIMU_ = true;
}

double IPEDataPacket::convertToDouble(const ros::Time& _time){
    return static_cast<double>(_time.sec) + static_cast<double>(_time.nsec) / 1e9;
}

void IPEDataPacket::getisUWB(){
    return this->isUWB_;
}

void IPEDataPacket::getisIMU(){
    return this->isIMU_;
}


void IPEDataPacket::setProcessUWB(const ipe::Anchor::ConstPtr& _msg){
    std::vector<std::string> newIds = msg->id;
    std::vector<double> newXs = msg->x;
    std::vector<double> newYs = msg->y;

    // Check for new IDs and update RxID_list_
    for (const auto& newId : newIds) {
        if (std::find(this->RxID_list_.begin(), this->RxID_list_.end(), newId) == this->RxID_list_.end()) {
            RxID_list_.push_back(newId);
            // Add default values for new IDs to xain and yain lists
            this->xain_list.push_back(0.0);
            this->yain_list.push_back(0.0);
        }
    }

    // Update xain_list and yain_list based on newIds
    for (size_t i = 0; i < newIds.size(); ++i) {
        auto idIndex = std::find(this->RxID_list_.begin(), this->RxID_list_.end(), newIds[i]) - this->RxID_list_.begin();
        if (idIndex < this->RxID_list_.size()) {
            this->xain_list[idIndex] = newXs[i];
            this->yain_list[idIndex] = newYs[i];
        }
    }

    // Update RxID_list
    this->RxID_list.clear();
    for (size_t i = 0; i < this->RxID_list_.size(); ++i) {
        this->RxID_list.push_back(i);
    }

    this->Ln_ = 6;
    this->Lp_ = 4;
    this->LnC_ = static_cast<double>(this->RxID_list.size());////
    this->PP_ = this->.frame_id;
    this->Nanchor_ = this->anchorID_.size();

    double zt_b = 1.53;
    for (size_t i = 0; i < Nanchor; ++i) {
        auto it = std::find(this->RxID_list.begin(), this->RxID_list.end(), this->anchorID_[i]);
        if (it != this->RxID_list.end()) {
            this->RxID[i] = std::distance(this->RxID_list.begin(), it) + 1;
            
        }
        this->RxDist[i] = std::real(std::sqrt(std::pow(this->distanceFromTag[i], 2) - std::pow(this->z_ - zt_b, 2)));
    }
}

void IPEDataPacket::setProcessIMU(const sensor_msgs::Imu::ConstPtr& _msg){
    if (!packet.linear_x.empty()) {
        this->imu_data_.IMUacc_c_[0] = this->linear_x_.back();
        // IMUacc_c[0] = this->linear_x_.back();
    }
    if (!packet.linear_y.empty()) {
        this->imu_data_.IMUacc_c_[1] = this->linear_y_.back();
        // IMUacc_c[1] = this->linear_y_.back();
    }
    if (!packet.linear_z.empty()) {
        this->imu_data_.IMUacc_c_[2] = this->linear_z_.back();
        // IMUacc_c[2] = this->linear_z_.back();
    }

    if (!this->angular_x_.empty()) {
        this->imu_data_.IMUgyro_c[0] = this->angular_x_.back();
        // IMUgyro_c[0] = this->angular_x_.back();
    }
    if (!this->angular_y_.empty()) {
        this->imu_data_.IMUgyro_c[1] = this->angular_y_.back();
        IMUgyro_c[1] = this->angular_y_.back();
    }
    if (!this->angular_z_.empty()) {
        this->imu_data_.IMUgyro_c[2] = this->angular_z_.back();
        // IMUgyro_c[2] = this->angular_z_.back();
    }
}

double IPEDataPacket::extractNumber(const std::string& input) {
    double value = 0.0;
    for (char c : input) {
        if (std::isdigit(c)) {
            value = value * 10 + (c - '0');
        }
    }
    return value;
}

creal_T IPEDataPacket::calcBody(int idx)
{
    creal_T result;
    std::vector<double> xt_b = {-0.525, 0.525, -0.525, 0.525};
    std::vector<double> yt_b = {0.505, 0.505, -0.505, -0.505};

    if (idx < xt_b.size()) {
        result.re = xt_b[idx];
        result.im = yt_b[idx];
    }
    return result;
};

creal_T IPEDataPacket::getBody(creal_T result[4])
{
    /* Loop over the array to initialize each element. */
    for (int idx1 = 0; idx1 < 4; idx1++) {
        result[idx1] = calcBody(idx1);
    }
    return result;
};

creal_T IPEDataPacket::calcPreTag(int idx)
{
    creal_T result;
    std::vector<double> xt_b = {0, 0, 0, 0};
    std::vector<double> yt_b = {0, 0, 0, 0};

    for (size_t i = 0; i < xt_b.size(); ++i) {
        result.re = xt_b[i];
        result.im = yt_b[i];
    }
    return result;
};

creal_T IPEDataPacket::getInitTag(creal_T result[4])
{
    int idx1;
    /* Loop over the array to initialize each element. */
    for (idx1 = 0; idx1 < 4; idx1++) {
        result[idx1] = calcPreTag(idx1);
    }
    return result;
};


void IPEDataPacket::setUWBEstPos(double _UWBout[21])
{
    for (int i = 0; i < 4; i++) {
        this->tag_pos_est_[i].re = _UWBout[i];
        this->tag_pos_est_[i].im = _UWBout[i + 4];

        this->tag_pos_est_aver_[i].re = _UWBout[i + 9];
        this->tag_pos_est_aver_[i].im = _UWBout[i + 13];
    }

    this->heading_est_ = _UWBout[8];
    this->headingest_a_aver_v_ = _UWBout[17];


    this->tag_center_vel_est_.re = _UWBout[18];
    this->tag_center_vel_est_.im = _UWBout[19];

    this->UWBErrSum_ = _UWBout[20];

    if (this->heading_est_ != 0 && this->init_flag_ == 0) {
        this->init_flag _= 1;
    } else if (this->heading_est_ != 0 && this->init_flag_ ==1) {
        this->init_flag_ = 1;
    } else if (this->init_flag_ == 2) {
        this->init_flag_ = 3;
    } else if (this->init_flag_ == 3) {
        this->init_flag_ = 3;
    } else {
        this->init_flag_ = 0;
    }
};

void IPEDataPacket::setIMUEstPos(double _cent_pos_est)
{
    std::complex<real_T> j(0, 1); // 복소수 단위

    // creal_T cent_pos_est_;
    creal_T current_tag_pos_b[4];
    for (int i = 0; i < 4; ++i) {                    
        std::complex<double> cent_pos_est_c(_cent_pos_est[0], _cent_pos_est[1]);
        std::complex<double> current_tag_pos_b_c(tag_pos_b[i].re, tag_pos_b[i].im);
        std::complex<double> TagPos = cent_pos_est_c + std::exp(j * (-this->kf_psi)) * (current_tag_pos_b_c + 0.4 * j);
        creal_T TagPos_;
        TagPos_.re = std::real(TagPos);
        TagPos_.im = std::imag(TagPos);
        this->prevTagPos[i].re = TagPos_.re;
        this->prevTagPos[i].im = TagPos_.im;
    }
}

// IMUData IPEDataPacket::getIMUData(IMUData* _imu_data){
//     IMUData imu_data = *_imu_data;

//     _imu_data.IMUacc_c_[0] = IMUacc_c_[0];
//     _imu_data.IMUacc_c_[1] = IMUacc_c_[1];
//     _imu_data.IMUacc_c_[2] = IMUacc_c_[2];
//     _imu_data.IMUgyro_c_[0] = IMUgyro_c_[0];
//     _imu_data.IMUgyro_c_[1] = IMUgyro_c_[1];
//     _imu_data.IMUgyro_c_[2] = IMUgyro_c_[2];
//     _imu_data.s_time_ = s_time_;
//     _imu_data.b_acc_o_[0] = b_acc_o_[0];
//     _imu_data.b_acc_o_[1] = b_acc_o_[1];
//     _imu_data.b_acc_o_[2] = b_acc_o_[2];
//     _imu_data.b_gyro_[0] = b_gyro_[0];
//     _imu_data.b_gyro_[1] = b_gyro_[1];
//     _imu_data.b_gyro_[2] = b_gyro_[2];
//     _imu_data.imuDataType_ = imuDataType_;
//     _imu_data.kf_psi_ = kf_psi_;
//     _imu_data.gyro_psi_ = gyro_psi_;
//     _imu_data.cent_pos_est_[0] = cent_pos_est_[0];
//     _imu_data.cent_pos_est_[1] = cent_pos_est_[1];
//     _imu_data.cent_pos_est_[2] = cent_pos_est_[2];
//     _imu_data.cent_vel_est_[0] = cent_vel_est_[0];
//     _imu_data.cent_vel_est_[1] = cent_vel_est_[1];
//     _imu_data.cent_vel_est_[2] = cent_vel_est_[2];
//     _imu_data.state_o_ = state_o_;
//     _imu_data.acc_b_phi_ = acc_b_phi_;
//     _imu_data.acc_b_theta_ = acc_b_theta_;

//     return imu_data;
// }

IMUData IPEDataPacket::getIMUData(){
    return this->imu_data_ ;
}

creal_T getPreTag(){
    return this->prevTagPos_;
}

double IPEDataPacket::getTimestamp(){
    return this->s_time_;
}

double IPEDataPacket::getNanchor(){
    return this->Nanchor_;
}

double IPEDataPacket::getRxID(){
    return this->RxID_;
}

double IPEDataPacket::getRxDist(){
    return this->RxDist_;
}

double IPEDataPacket::getxain_list(){
    return this->xain_list;
}

double IPEDataPacket::getyain_list(){
    return this->yain_list;
}

double IPEDataPacket::getkf_psi(){
    return this->kf_psi_;
}

double IPEDataPacket::getLn(){
    return this->Ln_;
}

double IPEDataPacket::getLp(){
    return this->Lp_;
}

double IPEDataPacket::getLnC(){
    return this->LnC_;
}

double IPEDataPacket::getPP(){
    return this->PP_;
}

creal_T IPEDataPacket::gettag_b_pos(){
    return this->tag_b_pos_;
}

double IPEDataPacket::getB_acc_o(){
    return this->b_acc_o_;
}

double IPEDataPacket::getB_gyro(){
    return this->b_gyro_;
}

// void IPEDataPacket::getIMUDataType(){
//     return this->imuDataType_;
// }

// void IPEDataPacket::getKalmanFlag(){
//     return this->kalmanFlag_;
// }