/******************************************************************************
*
* Copyright (C) 2023 - 2028 KETI, All rights reserved.
*                           (Korea Electronics Technology Institute)
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the 
), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running for Korean Government Project, or
* (b) that interact with KETI project/platform.
*
* THE SOFTWARE IS PROVIDED 
, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* KETI BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the KETI shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from KETI.
*
******************************************************************************/

#include "IMUHandler.h"

IMUHandler::IMUHandler(ros::NodeHandle _nh, IPEDataPacket* _data_packet, IPEDataHandler* _data_handler) : data_packet_(_data_packet), data_handler_(_data_handler) {
    std::cout << "IMU test setup starting..." << std::endl;
    std::ostringstream topic_name_stream;
    topic_name_stream << "/zed_f9r/imu";
    std::string topic_name = topic_name_stream.str();

    sub_imu_ = _nh.subscribe<sensor_msgs::Imu>(topic_name, 10, &IMUHandler::imuCallback, this);
}

IMUHandler::~IMUHandler(){
    delete this->data_handler_;
    delete this->data_packet_;
}

void IMUHandler::imuCallback(const sensor_msgs::Imu::ConstPtr& _msg){
    data_packet_->setSensorIMU(_msg);
    data_packet_->setProcessIMU(_msg);

    if (data_handler_){
        data_handler_->onLiveDataAvailable(*data_packet_);
    }
}

void IMUHandler::positioningIMU(IPEDataPacket* _data_packet){

    IMUpos(IMUacc_c, IMUgyro_c, s_time, b_acc_o, b_gyro, mode, &kf_psi,
        &gyro_psi, cent_pos_est, cent_vel_est, &state_o, &acc_b_phi,
        &acc_b_theta);
    _data_packet->setIMUEstPos(cent_pos_est);
}