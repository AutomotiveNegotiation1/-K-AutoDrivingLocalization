#include <gtest/gtest.h>
#include <ros/ros.h>
#include <IPEcore.h>

TEST(IPECoreTest, RegisterSubscribersTest) {
    // Create a mock ROS NodeHandle
    ros::NodeHandle nh;

    // Create an instance of IPECore
    IPECore ipeCore;

    // Call the registerSubscribers function
    ipeCore.registerSubscribers(nh);

    // TODO: Add your assertions here to verify the expected behavior
    // For example, you can check if the subscribers are correctly registered
    // using ASSERT_TRUE or ASSERT_FALSE macros.
    // You can also use EXPECT_* macros for non-fatal assertions.

    // Example assertion:
    // ASSERT_TRUE(ipeCore.isSubscribersRegistered());
}

int main(int argc, char** argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}