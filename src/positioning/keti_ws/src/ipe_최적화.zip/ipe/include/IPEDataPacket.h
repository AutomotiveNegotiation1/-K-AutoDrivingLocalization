/******************************************************************************
*
* Copyright (C) 2023 - 2028 KETI, All rights reserved.
*                           (Korea Electronics Technology Institute)
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the 
), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running for Korean Government Project, or
* (b) that interact with KETI project/platform.
*
* THE SOFTWARE IS PROVIDED 
, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* KETI BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the KETI shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from KETI.
*
******************************************************************************/

#ifndef IPEDATAPACKET_H
#define IPEDATAPACKET_H

#include <ipe/Anchor.h>
#include <sensor_msgs/Imu.h>
#include <ros/ros.h>
#include <string>
#include <vector>
#include <cmath>
#include <iostream>
#include <sstream>
#include <complex>

#include "rt_nonfinite.h"

struct IMUData;

class IPEDataPacket
{
public:
    IPEDataPacket();
    ~IPEDataPacket();

    void setSensorUWB(const ipe::Anchor::ConstPtr& _msg);
    void setSensorIMU(const sensor_msgs::Imu::ConstPtr& _msg);
    void setProcessUWB(const ipe::Anchor::ConstPtr& _msg);
    void setProcessIMU(const sensor_msgs::Imu::ConstPtr& _msg);
    void setUWBEstPos(double UWBout[21]);
    
    bool getisUWB();
    bool getisIMU();

    double getTimestamp(); 
    creal_T getPreTag();
    double getNanchor();
    double getRxID();
    double getRxDist();
    double getxain_list();
    double getyain_list();
    double getkf_psi();
    double getLn();
    double getLp();
    double getLnC();
    double getPP();
    creal_T gettag_b_pos();
    double getB_acc_o();
    double getB_gyro();

    
    
     IMUData getIMUData(IMUData* _imu_data);

    struct packetUWB;
    struct packetIMU;

private:
    void init();
    double convertToDouble(const ros::Time& _time);

    bool isUWB_;
    bool isIMU_;
    int imuDataType_;
    bool kalmanFlag_;

    
    std::string frameID_;
    std::vector<std::string> anchorID_;
    std::vector<double> x_;
    std::vector<double> y_;
    std::vector<double> z_;
    std::vector<double> distanceFromTag_;

    std::vector<double> linear_x_;
    std::vector<double> linear_y_;
    std::vector<double> linear_z_;

    std::vector<double> angular_x_;
    std::vector<double> angular_y_;
    std::vector<double> angular_z_;

    std::vector<double> xain_list_;
    std::vector<double> yain_list_;

    std::vector<double> RxID_;
    std::vector<double> RxDist_;
    std::vector<std::string> RxID_list_;

    creal_T tag_pos_b_[4];
    creal_T tag_b_pos_[4];
    creal_T prevTagPos_[4];
    creal_T tag_pos_est_[4];
    creal_T tag_pos_est_aver_[4];
    creal_T tag_center_vel_est_;

    double heading_est_;
    double headingest_a_aver_v_;
    double UWBErrSum_;
    double init_flag_;

    double s_time_;

    struct IMUData
    {
        double IMUacc_c_[3];
        double IMUgyro_c_[3];
        double b_acc_o_[3];
        double b_gyro_[3];
        double imuDataType_;
        double kf_psi_;
        double gyro_psi_;
        double cent_pos_est_[3];
        double cent_vel_est_[3];
        double state_o_[3];
        double acc_b_phi_;
        double acc_b_theta_;
    };

    IMUData imu_data_;

};

#endif

