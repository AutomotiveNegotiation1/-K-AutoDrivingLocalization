/******************************************************************************
*
* Copyright (C) 2023 - 2028 KETI, All rights reserved.
*                           (Korea Electronics Technology Institute)
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the 
), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running for Korean Government Project, or
* (b) that interact with KETI project/platform.
*
* THE SOFTWARE IS PROVIDED 
, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* KETI BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the KETI shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from KETI.
*
******************************************************************************/
#ifndef IMUHANDLER_H
#define IMUHANDLER_H

#include <sstream>
#include <iostream>
#include <string>
#include <ros/ros.h>
#include <sensor_msgs/Imu.h>

#include "IPEDataPacket.h"
#include "IPEDataHandler.h"

class IMUHandler{
public:
    IMUHandler(ros::NodeHandle _nh, IPEDataPacket* _data_packet, IPEDataHandler* _data_handler);
    ~IMUHandler();

    void positioningIMU(IPEDataPacket* _data_packet);

private:
    ros::Subscriber sub_imu_;
    IPEDataHandler* data_handler_;
    IPEDataPacket* data_packet_;

    IMUpos(IMUacc_c, IMUgyro_c, s_time, b_acc_o, b_gyro, mode, &kf_psi,
        &gyro_psi, cent_pos_est, cent_vel_est, &state_o, &acc_b_phi,
        &acc_b_theta);

    struct IMUData
    {
        double IMUacc_c_[3];
        double IMUgyro_c_[3];
        double s_time_;
        double b_acc_o_[3];
        double b_gyro_[3];
        double imuDataType_;
        double kf_psi_;
        double gyro_psi_;
        double cent_pos_est_[3];
        double cent_vel_est_[3];
        double state_o_[3];
        double acc_b_phi_;
        double acc_b_theta_;
    };
    
    IMUData imu_data_;

    void imuCallback(const sensor_msgs::Imu::ConstPtr& _msg);

};

#endif