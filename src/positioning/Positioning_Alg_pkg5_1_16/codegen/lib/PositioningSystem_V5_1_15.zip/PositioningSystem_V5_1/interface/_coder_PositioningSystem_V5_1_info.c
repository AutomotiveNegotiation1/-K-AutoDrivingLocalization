/*
 * _coder_PositioningSystem_V5_1_info.c
 *
 * Code generation for function 'PositioningSystem_V5_1'
 *
 */

/* Include files */
#include "_coder_PositioningSystem_V5_1_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

/* Function Declarations */
static const mxArray *c_emlrtMexFcnResolvedFunctionsI(void);

/* Function Definitions */
static const mxArray *c_emlrtMexFcnResolvedFunctionsI(void)
{
  const mxArray *nameCaptureInfo;
  const char_T *data[14] = {
      "789ced9ccb6fe3441cc7dd65595642bb84a7b822f604a84adc84a4dcf24e9a269b364eda"
      "74b3781d67123bf52b7ee4515869c5811b0f21f813100809c4813f80"
      "1b425c39ac38e58084382001e2c881a4f66c6b6f8764897193a9e7507bfacdf8f78a3f9e"
      "4c1c136bf9e21a4110d709b3bdc89bdb6b563f606d2f11f6e6d4d7ac",
      "ed338e3e6c8f13976de3a0fe81b56565490743ddec488c081e8c6cc9222f31924e8d1440"
      "a84093853e681d2b6d5e00142f82cae94e69da1333a7a4079da934dd"
      "4f72803dac1822a172da8987c2e9ce837c8c11f15e9e331ff710f90838f45be9dbc9371a"
      "550da85aa390a6f28d94cc1a229074ad518c53dbf144a32c6bbccecb",
      "122f75e8b8d0a1c920190e46c930ad1c762274880e918ff892ca48d38148d726caba08e3"
      "1d2e182faafe01879e2e64e8ea5e82ae6cc78b74be58a543e6ffa11f"
      "7716f4e30ad20f5369c9465300eed5f96da43dbbee559d1fceefba38b53f2bbf4fcd19af"
      "737bf2faabc7dbc8af3fad7969affbd1576d2fedc1765ef6163d4f5f",
      "40d80b38f472d8d8ce7677736a7f54cd160e403393cbeda54efc28cfb033cb0f02d1f7ea"
      "f863c4785ccffb45df374fcf8817ea6515b4a6be6ca4e80a2f2a02bc"
      "9eaf2adfdf42dab3eb9e5dc79df935cb8c2ddf99bb7ff35eda830d77be67052a1c69d66b"
      "d1586ca895aa035d4e66cb399fef1795efcfce8817ea227308a60c8a",
      "3b08bfaa7cbf8bb467d7bdaaf319f93d2e34ae7cfff29d0ee7a53dd870e73bc757b76264"
      "bdccb3c9669f4cb3fb47f20195f5f9beaa7c57168cd7b9fee68c17ea"
      "71a9238022a3b3dcc459e2fcb87e7f417b03a43dbbee557d6d799d9416579e5ff9e4397f"
      "3d86709fe7b1a39bdb839b753dc865b76251355e3f1c90058c78fe35",
      "62fcbc792c208e1f70e8b7f2dbe9db3744461798a62acbfa8d862ecb42531e3680283404"
      "bed930b586220ba3b62135784907aa32a1f15a455727e72e251781ce"
      "c9ad7ccae6ff870bfaffda0cffa1ceca2da0ae1f3b253182b9337195d181b56f7aa7a525"
      "63ae75df59fe391bca3fd8a0bd6fffa33d78fc3767d883faa49ea5b3",
      "eba971cc641edd384e98f5f7556b03d367ed99f96b3c94bfe915d82baeecbc74df534e13"
      "fbf1ef3db56735dc395dcc972335c0470f368be42e2bab3b6228af62"
      "b4aef23962fcbc79cc228e1f70e80b70dadaa307b27ae8f3d9d1f7f97c763c3e9fcde6f3"
      "f9dfedccf28340f457655de41ee2f80187be2cf7addc5930deab8efe",
      "49bca6027a46596024b0aaeb202ad29e5df7aa9e309fd6d796d8ae83bcc27ce3af8310ee"
      "f33bb37fd0ca170775c0f79369b11361956ab489d13ac8453fdfe78d"
      "f309649ca6d23318b2c5ce5e675d566ef790f6ecba5775b4f209cb882db7df7f77adeba5"
      "3dd870e7768b8a2a3bc1c49621ef1b89f466b999cd9576933eb72f1a",
      "b767ceb70d419d826655b9bd7475b4f289fb7cfbd3de77fe7c9b709fdba4b093dfdbdc57"
      "ebc9d79359b5aa6e809686d3f78ed89defe7c4ed0962c8296b7c6ebb"
      "5347984fdcb9fdde6782cf6dc27d6e1fc54655658b95339154a599d8ed94f287ed74061f"
      "6e8f11e3fd75eeb3e3f5f96d369fdfeedaf3f96d369fdf8f76fc3162",
      "3caefc56168cf7baa3ef8c17eab6fbc8c3ab7bfff6d0d1271caf83fab9dc9f1f9e7d5d76"
      "8b3f7ffce92dcf7ff87dfd312fedc1863bcfc1e601d98e25ab9a1204"
      "a3748de732e526e5ff9efec2f21c95df80633b610e7485ae85e9d0aafecef20869cfae7b"
      "555f675e719fa7ef15ff92bcb4071bee5c57b814c3950ec251aab057",
      "a825dbf5012f8f30fa5e738c188feb79bf28d79f9c112fd4277e28b246d7487ac366ffce"
      "82f6bd9ea71b487b76ddc3fac2bc62fdbbf9972ffde6f39c709fe7aa"
      "5aebe6052a988ff5f59074a424e4d26e07a3fbc32fcaf9ee15c7a9811c97586ee269e4b8"
      "ef73dc9dba9eca2bd61c3712639fe384fb1c171261a5178ca58e325d",
      "914f2541aad7aee5123ec797f57cffbf387ecdd177c609758a5301b08813265697e3cbf6"
      "dc135b5e317eeec9c7d77ef4394eb8cf713e2671dd4cb693ce2bd961"
      "7f7fc876a3fb3c461c1f23c6fbeb2b67c73befbc9c9d3eeb3d630882f580f155e5f9b25d"
      "a74fe515eb79f917e3ac7f5f0b31fffbf47984bd8043cf16925a3f9d",
      "d42b1b42e86625ce73bc1c2d103ecf5795e75e3d7776e247d110749e623ae5e9e7840d97"
      "b97ed9d13ff1c354582008a7ed8d17b4b76ccf9d3d23bf58f3fde7cc"
      "2ffe7c9d707fbeae4b65add9a47229a5c76d6a1b11b2dfed3018ac9fff03a7e3e6a6",
      ""};
  nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(&data[0], 26928U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties(void)
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *propFieldName[9] = {"Version",
                                    "ResolvedFunctions",
                                    "Checksum",
                                    "EntryPoints",
                                    "CoverageInfo",
                                    "IsPolymorphic",
                                    "PropertyList",
                                    "UUID",
                                    "ClassEntryPointIsHandle"};
  const char_T *epFieldName[8] = {
      "Name",     "NumberOfInputs", "NumberOfOutputs", "ConstantInputs",
      "FullPath", "TimeStamp",      "Constructor",     "Visible"};
  xEntryPoints =
      emlrtCreateStructMatrix(1, 1, 8, (const char_T **)&epFieldName[0]);
  xInputs = emlrtCreateLogicalMatrix(1, 1);
  emlrtSetField(xEntryPoints, 0, "Name",
                emlrtMxCreateString("PositioningSystem_V5_1"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 0, "FullPath",
      emlrtMxCreateString(
          "C:\\Users\\KETI\\Documents\\MATLAB\\Positioning_Alg_20240724_pkg5_1_"
          "12\\Positioning_Alg_20240724_pkg5_1_12\\PositioningSystem_V5"
          "_1.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp",
                emlrtMxCreateDoubleScalar(739484.84130787035));
  emlrtSetField(xEntryPoints, 0, "Constructor",
                emlrtMxCreateLogicalScalar(false));
  emlrtSetField(xEntryPoints, 0, "Visible", emlrtMxCreateLogicalScalar(true));
  xResult =
      emlrtCreateStructMatrix(1, 1, 9, (const char_T **)&propFieldName[0]);
  emlrtSetField(xResult, 0, "Version",
                emlrtMxCreateString("23.2.0.2515942 (R2023b) Update 7"));
  emlrtSetField(xResult, 0, "ResolvedFunctions",
                (mxArray *)c_emlrtMexFcnResolvedFunctionsI());
  emlrtSetField(xResult, 0, "Checksum",
                emlrtMxCreateString("E0lOz6VlwU2byKZK1cRjZB"));
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

/* End of code generation (_coder_PositioningSystem_V5_1_info.c) */
