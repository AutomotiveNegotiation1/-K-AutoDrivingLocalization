/*
 * mean.h
 *
 * Code generation for function 'mean'
 *
 */

#ifndef MEAN_H
#define MEAN_H

/* Include files */
#include "UWBpos2_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
creal_T b_mean(const emxArray_creal_T *x);

creal_T mean(const emxArray_creal_T *x);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (mean.h) */
