/*
 * _coder_UWBpos2_info.h
 *
 * Code generation for function 'UWBpos2'
 *
 */

#ifndef _CODER_UWBPOS2_INFO_H
#define _CODER_UWBPOS2_INFO_H

/* Include files */
#include "mex.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties(void);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (_coder_UWBpos2_info.h) */
