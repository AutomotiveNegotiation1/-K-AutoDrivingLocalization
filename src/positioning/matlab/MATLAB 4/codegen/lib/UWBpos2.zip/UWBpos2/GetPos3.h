/*
 * GetPos3.h
 *
 * Code generation for function 'GetPos3'
 *
 */

#ifndef GETPOS3_H
#define GETPOS3_H

/* Include files */
#include "UWBpos2_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void GetPos3(const double xa_data[], const double ya_data[],
             const double dist_data[], int dist_size, const double RxID_data[],
             int RxID_size, const creal_T tag_pos_b[4], double Ln, double PP,
             const emxArray_creal_T *PredPos, const emxArray_real_T *DistPrev,
             const emxArray_real_T *b_RxIDprev, const double b_RxIDprevLen[4],
             const double b_PPprev[4], creal_T tag_pos_est[4],
             double *heading_est, creal_T *cand_tag_pos);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (GetPos3.h) */
