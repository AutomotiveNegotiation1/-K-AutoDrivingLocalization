/*
 * _coder_UWBpos2_info.c
 *
 * Code generation for function 'UWBpos2'
 *
 */

/* Include files */
#include "_coder_UWBpos2_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

/* Function Declarations */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

/* Function Definitions */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void)
{
  const mxArray *nameCaptureInfo;
  const char_T *data[8] = {
      "789ced993d6fd3401cc61d54de0a85502104880150e72a4993a681c98d9db4a5495fe288"
      "168a94175f6a377ec98b9da465e9060bf0051880818105c4c0270076"
      "2418d8109f00b1304212fb92d870758bcba531fe2fd7eb53e779ee6fdd2ff695f0cc263c"
      "04419c22b47a32ae8d23fadcab8f87086399758f3e1e37cd611d2686",
      "0cd741fd913ee66549010d459b48591174ae64659197b292c26c960051015559a801b6ad"
      "14780130bc0852bd93646b26c67aa4cea425b57e8e72205f4ca92251"
      "e1aadd8442efa4d38f0662bd43bbecc739443fbc26fd367d87beb696209979727a2d7d73"
      "ba245703e3623747c9668e618b1c508f036556e29545596f06f4cfd8",
      "f43f82f4d71456567302e8fa6ddbf4bb80f433ea86be7717df6a7dbbacd67f7a9779cc63"
      "f7ef8fb5c7ab6f3f7b70fa115f998758fdf4ea971fae7d1c0c960ba9"
      "e555dff2a4706b4e6d6c45d8f87c64ba9b63d1c2c72a078198e3fafc6dc4f5fdda9776b9"
      "78c2220fd499ba4c4a79ae1961c2e09fb1e98f9b8b17917e46ddd0ff",
      "9ec5c31b806b1f8fe1e6e28bd18f58fdf4723a17f38d55969df329b2542f01504dd668b5"
      "9ca05d2efe2b2edabdaf672cf240bd1921a10a0acf64d79b31e24032"
      "e5c8d8cc819b8f97917e46dd7c1f8c4d181771ede793eff0f231f3d8ff0ca71f2ca7f351"
      "8afb4826979a2987a33722b9724dae55826ccc397c74ca7b34ea7cc3",
      "6bd2672505544a9dd7e8bef1d06edfcf23fd8cbaa1ef9dc5e3e320788f97835feede9bc2"
      "e907cbe91c0cfb5754aa1ea3170a35727372292a6649867239b8ef1c"
      "ccd8cc71149943539a8f44ed77e541e5de5ff5595ff46efabc5ffb740333f7be3d95bee3"
      "f483e574ee4dd0d5cdf0562ebdc18a696a919e200353e164dce5de7e",
      "ef47f7bc706f7eee79e1ce7eee79a156ee79e1de3effa0f0d06e8e518b1c50ffed882ca0"
      "fdbe5f5cbc6fd3ef0ad2cfa8ef7c4e18c0fe7fe6e7989f17c183e10f"
      "38fd60399d8fabe1a23fecab0b216e2e068af9a2c065230b51978f07edbc70c43437e780"
      "ba86e66550e025d042e3a03e2f5e42fa19f53f7c2fe98bd790886bff",
      "bec2cc43f5e7eb319c7eb09ccec30ab5a494e9d012b5c227b824159c6f844229ca393cdc"
      "465cdfaf7d898b8b0c5701a0e74dfabfe2a261f178b9f81233177fbc"
      "b9fe09a71fac41e5e259849fd7a4fb45a5bc40ca35df54643d385914d23360bd37c7a072"
      "f1170062b51b",
      ""};
  nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(&data[0], 11960U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties(void)
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *propFieldName[7] = {
      "Version",      "ResolvedFunctions", "Checksum",    "EntryPoints",
      "CoverageInfo", "IsPolymorphic",     "PropertyList"};
  const char_T *epFieldName[6] = {
      "Name",           "NumberOfInputs", "NumberOfOutputs",
      "ConstantInputs", "FullPath",       "TimeStamp"};
  xEntryPoints =
      emlrtCreateStructMatrix(1, 1, 6, (const char_T **)&epFieldName[0]);
  xInputs = emlrtCreateLogicalMatrix(1, 11);
  emlrtSetField(xEntryPoints, 0, "Name", emlrtMxCreateString("UWBpos2"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(11.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 0, "FullPath",
                emlrtMxCreateString("E:\\MATLAB\\UWBpos2.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp",
                emlrtMxCreateDoubleScalar(739109.46400462964));
  xResult =
      emlrtCreateStructMatrix(1, 1, 7, (const char_T **)&propFieldName[0]);
  emlrtSetField(xResult, 0, "Version",
                emlrtMxCreateString("9.13.0.2166757 (R2022b) Update 4"));
  emlrtSetField(xResult, 0, "ResolvedFunctions",
                (mxArray *)emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "Checksum",
                emlrtMxCreateString("b9bQ6fId1CRmhZTHQPKy"));
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

/* End of code generation (_coder_UWBpos2_info.c) */
