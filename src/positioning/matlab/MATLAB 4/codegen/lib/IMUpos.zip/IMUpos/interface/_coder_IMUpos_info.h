/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: _coder_IMUpos_info.h
 *
 * MATLAB Coder version            : 5.6
 * C/C++ source code generated on  : 20-Sep-2023 17:05:14
 */

#ifndef _CODER_IMUPOS_INFO_H
#define _CODER_IMUPOS_INFO_H

/* Include Files */
#include "mex.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for _coder_IMUpos_info.h
 *
 * [EOF]
 */
