/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: _coder_fusion_mex.h
 *
 * MATLAB Coder version            : 5.6
 * C/C++ source code generated on  : 22-Sep-2023 09:43:03
 */

#ifndef _CODER_FUSION_MEX_H
#define _CODER_FUSION_MEX_H

/* Include Files */
#include "emlrt.h"
#include "mex.h"
#include "tmwtypes.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
MEXFUNCTION_LINKAGE void mexFunction(int32_T nlhs, mxArray *plhs[],
                                     int32_T nrhs, const mxArray *prhs[]);

emlrtCTX mexFunctionCreateRootTLS(void);

void unsafe_PosKalman2_mexFunction(int32_T nlhs, mxArray *plhs[1], int32_T nrhs,
                                   const mxArray *prhs[4]);

void unsafe_fusion_mexFunction(int32_T nlhs, mxArray *plhs[6], int32_T nrhs,
                               const mxArray *prhs[16]);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for _coder_fusion_mex.h
 *
 * [EOF]
 */
