function [tag_pos_est, heading_est,tag_pos_est_aver,headingest_a_aver_v] = UWBpos(Ln, Lp, TagNum, Nanchor, RxID, RxDist, s_time, tag_pos_b, xa, ya)

average_len = 10;
NumInterpPoint = 9;
persistent r InterpPosition Tag_Pos_List TagDistInitCount TagDistInit heading_est_a

if isempty (r)
    r = 0;
    InterpPosition = zeros(Lp,2);
    Tag_Pos_List = zeros(NumInterpPoint,2,Lp);
    TagDistInitCount = zeros(Ln,Lp);
    TagDistInit = zeros(Ln,Lp);
    heading_est_a = [];
end
r = r + 1;

PP = TagNum;
anch_pos = xa + j*ya;


if r < 10*Lp

    for NN = 1 : Nanchor
        %             for PP = mod(r-1,Lp)+1:mod(r-1,Lp)+1
        TagDistInitCount(RxID(NN),PP) = TagDistInitCount(RxID(NN),PP) + 1;
        div = TagDistInitCount(RxID(NN),PP);
        TagDistInit(RxID(NN),PP) = TagDistInit(RxID(NN),PP)*(div-1)/div+RxDist(NN)/div;
        %             end
    end
    tag_pos_est = 0;
    heading_est = 0;
    tag_pos_est_aver=0;
    headingest_a_aver_v = 0;

elseif r == 10*Lp

    for NN = 1 : Nanchor
        %             for PP = mod(r-1,Lp)+1:mod(r-1,Lp)+1
        TagDistInitCount(RxID(NN),PP) = TagDistInitCount(RxID(NN),PP) + 1;
        div = TagDistInitCount(RxID(NN),PP);
        TagDistInit(RxID(NN),PP) = TagDistInit(RxID(NN),PP)*(div-1)/div+RxDist(NN)/div;
        %             end
    end

    DistT = TagDistInit;
    DistT(TagDistInit==0) = 1000000;
    IndT = find(sum(DistT,2)<100000);
    DistT = DistT(IndT,:);
    AnchID = IndT;

    [tag_pos_est, heading_est] =  GetInitPos(xa(AnchID),ya(AnchID),DistT,anch_pos(AnchID),tag_pos_b,length(IndT),Lp);

    for LLp= 1 : Lp
        for lo = 1 : NumInterpPoint
            Tag_Pos_List(lo,:,LLp) = [s_time+(-NumInterpPoint+lo)*0.1 tag_pos_est(LLp)];
        end
    end
    tag_pos_est_aver=0;
    headingest_a_aver_v = 0;
else
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%  Next Position Prediction    %%%%%%%%%%%%%%%%%%
    for PPC = 1 : Lp
        [InterpPosition(PPC,1)] = InterpPos(Tag_Pos_List(:,1,PPC),real(Tag_Pos_List(:,2,PPC)),s_time);
        [InterpPosition(PPC,2)] = InterpPos(Tag_Pos_List(:,1,PPC),imag(Tag_Pos_List(:,2,PPC)),s_time);
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    Xt_c_e = mean(InterpPosition(:,1));
    Yt_c_e = mean(InterpPosition(:,2));


    PosC = [];
    PosC_E = [];

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%% New Position Calc.   %%%%%%%%%%%%%%%%%%%%%%%%%%%

    %         for PP = mod(r-1,Lp)+1:mod(r-1,Lp)+1
    if length(RxID)>1
        [tag_pos_est, heading_est, CandPos] = GetPos2(xa,ya,RxDist,RxID,tag_pos_b,Nanchor,PP,InterpPosition(:,1)+j*InterpPosition(:,2));

        [tag_pos_est, heading_est, CandPos] = GetPosRefine2(xa,ya,RxDist,RxID,tag_pos_b,Nanchor,PP,tag_pos_est, heading_est, CandPos);

    else
        InterpPosT = InterpPosition(:,1)+j*InterpPosition(:,2);
        TempC = mean(InterpPosT);
        Est_H_p = 0;
        for P = 1 : length(InterpPosT)
            Est_H_p = Est_H_p+((InterpPosT(P))-Est_C)/tag_pos_b(P);
        end
        Est_H = angle(Est_H_p);

        for P = 1 : size(Pos2C,1)

            tag_pos_est(P) = TempC + tag_pos_b(P)*exp(j*Est_H);

        end

        CandPos = InterpPosition(PP,1)+j*InterpPosition(PP,2);
    end
    Tag_Pos_List(1:NumInterpPoint-1,:,PP) = Tag_Pos_List(2:NumInterpPoint,:,PP);
    Tag_Pos_List(NumInterpPoint,:,PP) = [s_time CandPos];
    %             Tag_Pos_List(1:2,:,PP) = Tag_Pos_List(2:3,:,PP);
    %             Tag_Pos_List(3,:,PP) = [s_time(r) tag_pos_est(PP)];
    Xt_c_e = real(mean(tag_pos_est));
    Yt_c_e = imag(mean(tag_pos_est));
    %         end

    tag_center_pos_est = mean(tag_pos_est);

    if ~isempty(heading_est_a)
        if (heading_est - heading_est_a(r-1)) > pi
            heading_est_a(r) = heading_est - 2*pi;
        elseif (heading_est_a(r-1) - heading_est) > pi
            heading_est_a(r) = heading_est + 2*pi;
        else
            heading_est_a(r) = heading_est;
        end
    else
        heading_est_a(r) = heading_est;
    end

    centerest_a(r,:) = [real(tag_center_pos_est) imag(tag_center_pos_est)];

    if (r>(average_len*2))
        MeanA = mean(centerest_a(r-19:r-10,1)+j*centerest_a(r-19:r-10,2));
        MeanB = mean(centerest_a(r-9:r,1)+j*centerest_a(r-9:r,2));
        centerest_a_aver(r,:) = [real(MeanB + (MeanB-MeanA)/2) imag((MeanB + (MeanB-MeanA)/2))] ;
        MeanA_head = mean(heading_est_a(r-average_len*2+1:r-average_len));
        MeanB_head = mean(heading_est_a(r-average_len+1:r));
        headingest_a_aver(r) = mod([(MeanB_head + (MeanB_head-MeanA_head)/2)],2*pi) ;
    else
        centerest_a_aver(r,:) = [Xt_c_e Yt_c_e];
        headingest_a_aver(r) = heading_est_a(r);
    end

    tag_pos_est_aver = get_tag_pos(centerest_a_aver(r,1)+j*centerest_a_aver(r,2), headingest_a_aver(r), tag_pos_b);
    [K_Xt_c_e] = centerest_a_aver(r,1);
    [K_Yt_c_e] = centerest_a_aver(r,2);
    tag_pos_est_aver = tag_pos_b*exp(j*(headingest_a_aver(r)))+K_Xt_c_e+j*K_Yt_c_e;
    headingest_a_aver_v = headingest_a_aver(r);
    K_heading_est = mod(headingest_a_aver(r),2*pi);
    K_centerest_a_aver(r, :) = centerest_a_aver(r,:);
    K_headingest_a_aver(r) = mod(headingest_a_aver(r),2*pi);

end