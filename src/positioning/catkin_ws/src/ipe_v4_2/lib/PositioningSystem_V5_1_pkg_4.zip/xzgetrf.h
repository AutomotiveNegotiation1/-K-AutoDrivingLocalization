/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: xzgetrf.h
 *
 * MATLAB Coder version            : 24.1
 * C/C++ source code generated on  : 2024-07-23 23:09:33
 */

#ifndef XZGETRF_H
#define XZGETRF_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
int xzgetrf(double A[36], int ipiv[6]);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for xzgetrf.h
 *
 * [EOF]
 */
