/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: abs.h
 *
 * MATLAB Coder version            : 24.1
 * C/C++ source code generated on  : 2024-07-23 23:09:33
 */

#ifndef ABS_H
#define ABS_H

/* Include Files */
#include "PositioningSystem_V5_1_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void b_abs(const emxArray_creal_T *x, emxArray_real_T *y);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for abs.h
 *
 * [EOF]
 */
