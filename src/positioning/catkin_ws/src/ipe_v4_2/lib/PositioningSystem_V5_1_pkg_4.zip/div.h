/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: div.h
 *
 * MATLAB Coder version            : 24.1
 * C/C++ source code generated on  : 2024-07-23 23:09:33
 */

#ifndef DIV_H
#define DIV_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void binary_expand_op_2(creal_T in1[4], const creal_T in2[4], const creal_T in3,
                        const creal_T in4_data[], const int in4_size[2]);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for div.h
 *
 * [EOF]
 */
