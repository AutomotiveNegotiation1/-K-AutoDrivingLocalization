/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: UWBpos_V2_3.c
 *
 * MATLAB Coder version            : 24.1
 * C/C++ source code generated on  : 2024-07-23 23:09:33
 */

/* Include Files */
#include "UWBpos_V2_3.h"
#include "PositioningSystem_V5_1_data.h"
#include "PositioningSystem_V5_1_emxutil.h"
#include "PositioningSystem_V5_1_rtwutil.h"
#include "PositioningSystem_V5_1_types.h"
#include "inv.h"
#include "mldivide.h"
#include "nullAssignment.h"
#include "rt_nonfinite.h"
#include "rt_nonfinite.h"
#include <emmintrin.h>
#include <math.h>
#include <string.h>

/* Function Definitions */
/*
 * Arguments    : double Nanchor
 *                const double RxIDin_data[]
 *                const double RxDistin_data[]
 *                const double xain_data[]
 *                const double yain_data[]
 *                creal_T *Pos1
 *                creal_T Pos2_data[]
 *                int Pos2_size[2]
 *                creal_T Pos3_data[]
 *                int Pos3_size[2]
 * Return Type  : void
 */
void UWBpos_V2_3(double Nanchor, const double RxIDin_data[],
                 const double RxDistin_data[], const double xain_data[],
                 const double yain_data[], creal_T *Pos1, creal_T Pos2_data[],
                 int Pos2_size[2], creal_T Pos3_data[], int Pos3_size[2])
{
  __m128d r;
  __m128d r1;
  __m128d r2;
  __m128d r3;
  emxArray_creal_T *x;
  emxArray_real_T *b_y;
  creal_T tmp_data[12];
  creal_T dc;
  creal_T *x_data;
  double b_x_data[144];
  double A_data[128];
  double b_A_data[128];
  double xa_data[65];
  double ya_data[65];
  double y_data[64];
  double meanTempW_data[12];
  double Pos[4];
  double dv[4];
  double dv1[4];
  double y_tmp[4];
  double X1[2];
  double b_Pos[2];
  double AA;
  double Pos_tmp;
  double a;
  double a_tmp;
  double b_Pos_tmp;
  double b_a_tmp;
  double b_d;
  double bkj;
  double c_Pos_tmp;
  double c_a_tmp;
  double d;
  double d1;
  double d_a_tmp;
  double *b_y_data;
  int b_tmp_data[4];
  int A_size[2];
  int b_A_size[2];
  int boffset;
  int coffset;
  int i;
  int k;
  int loop_ub;
  int loop_ub_tmp;
  int v;
  boolean_T b_x[2];
  boolean_T exitg1;
  boolean_T y;
  if (Nanchor < 1.0) {
    loop_ub = 0;
  } else {
    loop_ub = (int)Nanchor;
  }
  for (i = 0; i < loop_ub; i++) {
    d = RxIDin_data[i];
    xa_data[i] = xain_data[(int)d - 1];
    ya_data[i] = yain_data[(int)d - 1];
  }
  if (Nanchor < 1.0) {
    loop_ub_tmp = -1;
  } else {
    loop_ub_tmp = (int)Nanchor - 1;
  }
  memset(&Pos2_data[0], 0, 6U * sizeof(creal_T));
  Pos3_size[0] = 1;
  Pos3_size[1] = 12;
  memset(&Pos3_data[0], 0, 12U * sizeof(creal_T));
  v = 1;
  if (Nanchor == 2.0) {
    /*  Xa = [0 1]; */
    /*  Ya = [0 0]; */
    /*  dist = [1 1]; */
    coffset = (int)RxIDin_data[0] - 1;
    boffset = (int)RxIDin_data[1] - 1;
    a_tmp = xain_data[boffset];
    b_a_tmp = xain_data[coffset];
    bkj = b_a_tmp - a_tmp;
    c_a_tmp = yain_data[boffset];
    d_a_tmp = yain_data[coffset];
    a = d_a_tmp - c_a_tmp;
    AA = sqrt(bkj * bkj + a * a);
    /*  AA = 2;B=1;C=0.9 */
    bkj = ((AA + RxDistin_data[0]) + RxDistin_data[1]) / 2.0;
    d = bkj * (bkj - AA) * (bkj - RxDistin_data[0]) * (bkj - RxDistin_data[1]);
    if (d > 0.0) {
      b_d = 2.0 * sqrt(d) / AA;
      /*  if (B^2-((B^2-C^2+AA^2)/(2*AA))^2) > 0 */
      /*      d = sqrt(B^2-((B^2-C^2+AA^2)/(2*AA))^2); */
      /*  else */
      /*      d = 0; */
      /*  end */
      a = c_a_tmp - d_a_tmp;
      AA = a_tmp - b_a_tmp;
      Pos[1] = 2.0 * AA;
      Pos[3] = 2.0 * a;
      /*  Y1 =
       * [d*sqrt((Ya(2)-Ya(1))^2+(Xa(2)-Xa(1))^2)+Xa(1)*Ya(2)-Xa(2)*Ya(1);(C^2-B^2-Xa(1)^2+Xa(2)^2-Ya(1)^2+Ya(2)^2)];
       */
      /*  Y2 =
       * [-d*sqrt((Ya(2)-Ya(1))^2+(Xa(2)-Xa(1))^2)+Xa(1)*Ya(2)-Xa(2)*Ya(1);(C^2-B^2-Xa(1)^2+Xa(2)^2-Ya(1)^2+Ya(2)^2)];
       */
      y_tmp[0] = a;
      y_tmp[1] = -AA;
      y_tmp[2] = Pos[1];
      y_tmp[3] = Pos[3];
      d = Pos[1];
      d1 = Pos[3];
      r = _mm_loadu_pd(&y_tmp[0]);
      r1 = _mm_mul_pd(r, _mm_set1_pd(a));
      r2 = _mm_loadu_pd(&y_tmp[2]);
      r3 = _mm_mul_pd(r2, _mm_set1_pd(d));
      r1 = _mm_add_pd(r1, r3);
      _mm_storeu_pd(&Pos[0], r1);
      r = _mm_mul_pd(r, _mm_set1_pd(-AA));
      r1 = _mm_mul_pd(r2, _mm_set1_pd(d1));
      r = _mm_add_pd(r, r1);
      _mm_storeu_pd(&Pos[2], r);
      /*  if X1 == X2 */
      /*      Pos = [0;0]; */
      /*  else */
      inv(Pos, dv);
      inv(Pos, dv1);
      Pos_tmp = sqrt(a * a + AA * AA);
      b_Pos_tmp = b_a_tmp * c_a_tmp;
      c_Pos_tmp = d_a_tmp * a_tmp;
      b_Pos[0] = (b_d * Pos_tmp + b_Pos_tmp) - c_Pos_tmp;
      bkj = ((((-(RxDistin_data[1] * RxDistin_data[1]) +
                RxDistin_data[0] * RxDistin_data[0]) -
               b_a_tmp * b_a_tmp) +
              a_tmp * a_tmp) -
             d_a_tmp * d_a_tmp) +
            c_a_tmp * c_a_tmp;
      d = y_tmp[2];
      d1 = y_tmp[3];
      r = _mm_loadu_pd(&dv[0]);
      r1 = _mm_mul_pd(r, _mm_set1_pd(a));
      r2 = _mm_loadu_pd(&dv[2]);
      r3 = _mm_mul_pd(r2, _mm_set1_pd(-AA));
      r1 = _mm_add_pd(r1, r3);
      r1 = _mm_mul_pd(r1, _mm_set1_pd(b_Pos[0]));
      r = _mm_mul_pd(r, _mm_set1_pd(d));
      r2 = _mm_mul_pd(r2, _mm_set1_pd(d1));
      r = _mm_add_pd(r, r2);
      r = _mm_mul_pd(r, _mm_set1_pd(bkj));
      r = _mm_add_pd(r1, r);
      _mm_storeu_pd(&X1[0], r);
      r = _mm_loadu_pd(&dv1[0]);
      r1 = _mm_mul_pd(r, _mm_set1_pd(a));
      r2 = _mm_loadu_pd(&dv1[2]);
      r3 = _mm_mul_pd(r2, _mm_set1_pd(-AA));
      r1 = _mm_add_pd(r1, r3);
      _mm_storeu_pd(&dv[0], r1);
      r = _mm_mul_pd(r, _mm_set1_pd(d));
      r1 = _mm_mul_pd(r2, _mm_set1_pd(d1));
      r = _mm_add_pd(r, r1);
      _mm_storeu_pd(&dv[2], r);
      b_Pos[0] = (-b_d * Pos_tmp + b_Pos_tmp) - c_Pos_tmp;
      Pos[0] = X1[0];
      Pos[1] = dv[0] * b_Pos[0] + bkj * dv[2];
      Pos[2] = X1[1];
      Pos[3] = b_Pos[0] * dv[1] + bkj * dv[3];
    } else {
      if (loop_ub == 0) {
        b_a_tmp = 0.0;
      } else {
        for (k = 2; k <= loop_ub; k++) {
          b_a_tmp += xa_data[k - 1];
        }
      }
      if (loop_ub == 0) {
        d_a_tmp = 0.0;
      } else {
        for (k = 2; k <= loop_ub; k++) {
          d_a_tmp += ya_data[k - 1];
        }
      }
      X1[0] = b_a_tmp / (double)loop_ub;
      X1[1] = d_a_tmp / (double)loop_ub;
      Pos[0] = X1[0];
      Pos[1] = X1[0];
      Pos[2] = X1[1];
      Pos[3] = X1[1];
    }
    /*  end */
    Pos1->re = 0.0;
    Pos1->im = 0.0;
    Pos2_data[0].re = Pos[0];
    Pos2_data[0].im = Pos[2];
    Pos2_data[1].re = Pos[1];
    Pos2_data[1].im = Pos[3];
    A_size[0] = 1;
    A_size[1] = 6;
    memcpy(&tmp_data[0], &Pos2_data[0], 6U * sizeof(creal_T));
    b_A_size[0] = 1;
    b_A_size[1] = 4;
    _mm_storeu_si128(
        (__m128i *)&b_tmp_data[0],
        _mm_add_epi32(_mm_set1_epi32(3),
                      _mm_add_epi32(_mm_set1_epi32(0),
                                    _mm_loadu_si128((const __m128i *)&iv[0]))));
    nullAssignment(tmp_data, A_size, b_tmp_data, b_A_size);
    Pos2_size[0] = 1;
    loop_ub = A_size[1];
    Pos2_size[1] = A_size[1];
    Pos3_size[0] = 1;
    Pos3_size[1] = A_size[1];
    for (i = 0; i < loop_ub; i++) {
      dc = tmp_data[i];
      Pos2_data[i] = dc;
      Pos3_data[i] = dc;
    }
  } else if (Nanchor >= 3.0) {
    coffset = loop_ub_tmp << 1;
    if (coffset - 1 >= 0) {
      memset(&A_data[0], 0, (unsigned int)coffset * sizeof(double));
    }
    /*  if (ya(2)-y(1))*(xa(3)-xa(1)) ~= (ya(3)-y(1))*(xa(2)-xa(1)) */
    for (k = 0; k < loop_ub_tmp; k++) {
      y_data[k] = 0.0;
      d = RxDistin_data[k];
      if ((d != 0.0) && (RxDistin_data[loop_ub_tmp] != 0.0)) {
        d1 = xa_data[k];
        bkj = xa_data[loop_ub_tmp];
        A_data[k] = -2.0 * (d1 - bkj);
        a = ya_data[k];
        AA = ya_data[loop_ub_tmp];
        A_data[k + loop_ub_tmp] = -2.0 * (a - AA);
        b_d = RxDistin_data[loop_ub_tmp];
        y_data[k] =
            ((d * d - b_d * b_d) - (d1 * d1 - bkj * bkj)) - (a * a - AA * AA);
      }
    }
    /*  else */
    /*       */
    /*  end */
    /*  Pos = (A'*A)\(A'*y); */
    for (loop_ub = 0; loop_ub < 2; loop_ub++) {
      coffset = loop_ub << 1;
      boffset = loop_ub * loop_ub_tmp;
      Pos[coffset] = 0.0;
      Pos[coffset + 1] = 0.0;
      for (k = 0; k < loop_ub_tmp; k++) {
        bkj = A_data[boffset + k];
        Pos[coffset] += A_data[k] * bkj;
        Pos[coffset + 1] += A_data[loop_ub_tmp + k] * bkj;
      }
    }
    A_size[0] = 2;
    A_size[1] = loop_ub_tmp;
    for (i = 0; i < loop_ub_tmp; i++) {
      b_A_data[2 * i] = A_data[i];
      b_A_data[2 * i + 1] = A_data[i + loop_ub_tmp];
    }
    mldivide(Pos, b_A_data, A_size, A_data, b_A_size);
    i = b_A_size[1];
    b_Pos[0] = 0.0;
    b_Pos[1] = 0.0;
    for (k = 0; k < i; k++) {
      r = _mm_loadu_pd(&A_data[k << 1]);
      r1 = _mm_loadu_pd(&b_Pos[0]);
      _mm_storeu_pd(&b_Pos[0],
                    _mm_add_pd(r1, _mm_mul_pd(r, _mm_set1_pd(y_data[k]))));
    }
    if (rtIsNaN(b_Pos[0]) || rtIsNaN(b_Pos[1])) {
      b_Pos[0] = 0.0;
      b_Pos[1] = 0.0;
    }
    /*  Prob = sqrt(mean(abs((xa - Pos(1)).^2 + (ya - Pos(2)).^2 - dist.^2)));
     */
    Pos1->re = b_Pos[0];
    Pos1->im = b_Pos[1];
    i = (int)(Nanchor - 1.0);
    for (k = 0; k < i; k++) {
      loop_ub = (int)(Nanchor + (1.0 - (((double)k + 1.0) + 1.0)));
      if (loop_ub - 1 >= 0) {
        b_x[0] = (RxDistin_data[k] != 0.0);
      }
      for (loop_ub_tmp = 0; loop_ub_tmp < loop_ub; loop_ub_tmp++) {
        boffset = (k + loop_ub_tmp) + 1;
        b_x[1] = (RxDistin_data[boffset] != 0.0);
        y = true;
        coffset = 0;
        exitg1 = false;
        while ((!exitg1) && (coffset < 2)) {
          if (!b_x[coffset]) {
            y = false;
            exitg1 = true;
          } else {
            coffset++;
          }
        }
        if (y) {
          /*  Xa = [0 1]; */
          /*  Ya = [0 0]; */
          /*  dist = [1 1]; */
          bkj = xa_data[k] - xa_data[boffset];
          a = ya_data[k] - ya_data[boffset];
          AA = sqrt(bkj * bkj + a * a);
          /*  AA = 2;B=1;C=0.9 */
          bkj = ((AA + RxDistin_data[k]) + RxDistin_data[boffset]) / 2.0;
          d = bkj * (bkj - AA) * (bkj - RxDistin_data[k]) *
              (bkj - RxDistin_data[boffset]);
          if (d > 0.0) {
            b_d = 2.0 * sqrt(d) / AA;
            /*  if (B^2-((B^2-C^2+AA^2)/(2*AA))^2) > 0 */
            /*      d = sqrt(B^2-((B^2-C^2+AA^2)/(2*AA))^2); */
            /*  else */
            /*      d = 0; */
            /*  end */
            a = ya_data[boffset] - ya_data[k];
            AA = xa_data[boffset] - xa_data[k];
            Pos[1] = 2.0 * AA;
            Pos[3] = 2.0 * a;
            /*  Y1 =
             * [d*sqrt((Ya(2)-Ya(1))^2+(Xa(2)-Xa(1))^2)+Xa(1)*Ya(2)-Xa(2)*Ya(1);(C^2-B^2-Xa(1)^2+Xa(2)^2-Ya(1)^2+Ya(2)^2)];
             */
            /*  Y2 =
             * [-d*sqrt((Ya(2)-Ya(1))^2+(Xa(2)-Xa(1))^2)+Xa(1)*Ya(2)-Xa(2)*Ya(1);(C^2-B^2-Xa(1)^2+Xa(2)^2-Ya(1)^2+Ya(2)^2)];
             */
            y_tmp[0] = a;
            y_tmp[1] = -AA;
            y_tmp[2] = Pos[1];
            y_tmp[3] = Pos[3];
            d = Pos[1];
            d1 = Pos[3];
            r = _mm_loadu_pd(&y_tmp[0]);
            r1 = _mm_mul_pd(r, _mm_set1_pd(a));
            r2 = _mm_loadu_pd(&y_tmp[2]);
            r3 = _mm_mul_pd(r2, _mm_set1_pd(d));
            r1 = _mm_add_pd(r1, r3);
            _mm_storeu_pd(&Pos[0], r1);
            r = _mm_mul_pd(r, _mm_set1_pd(-AA));
            r1 = _mm_mul_pd(r2, _mm_set1_pd(d1));
            r = _mm_add_pd(r, r1);
            _mm_storeu_pd(&Pos[2], r);
            /*  if X1 == X2 */
            /*      Pos = [0;0]; */
            /*  else */
            inv(Pos, dv);
            inv(Pos, dv1);
            Pos_tmp = sqrt(a * a + AA * AA);
            b_Pos_tmp = xa_data[k] * ya_data[boffset];
            c_Pos_tmp = ya_data[k] * xa_data[boffset];
            b_Pos[0] = (b_d * Pos_tmp + b_Pos_tmp) - c_Pos_tmp;
            bkj = ((((-(RxDistin_data[boffset] * RxDistin_data[boffset]) +
                      RxDistin_data[k] * RxDistin_data[k]) -
                     xa_data[k] * xa_data[k]) +
                    xa_data[boffset] * xa_data[boffset]) -
                   ya_data[k] * ya_data[k]) +
                  ya_data[boffset] * ya_data[boffset];
            d = y_tmp[2];
            d1 = y_tmp[3];
            r = _mm_loadu_pd(&dv[0]);
            r1 = _mm_mul_pd(r, _mm_set1_pd(a));
            r2 = _mm_loadu_pd(&dv[2]);
            r3 = _mm_mul_pd(r2, _mm_set1_pd(-AA));
            r1 = _mm_add_pd(r1, r3);
            r1 = _mm_mul_pd(r1, _mm_set1_pd(b_Pos[0]));
            r = _mm_mul_pd(r, _mm_set1_pd(d));
            r2 = _mm_mul_pd(r2, _mm_set1_pd(d1));
            r = _mm_add_pd(r, r2);
            r = _mm_mul_pd(r, _mm_set1_pd(bkj));
            r = _mm_add_pd(r1, r);
            _mm_storeu_pd(&X1[0], r);
            r = _mm_loadu_pd(&dv1[0]);
            r1 = _mm_mul_pd(r, _mm_set1_pd(a));
            r2 = _mm_loadu_pd(&dv1[2]);
            r3 = _mm_mul_pd(r2, _mm_set1_pd(-AA));
            r1 = _mm_add_pd(r1, r3);
            _mm_storeu_pd(&dv[0], r1);
            r = _mm_mul_pd(r, _mm_set1_pd(d));
            r1 = _mm_mul_pd(r2, _mm_set1_pd(d1));
            r = _mm_add_pd(r, r1);
            _mm_storeu_pd(&dv[2], r);
            b_Pos[0] = (-b_d * Pos_tmp + b_Pos_tmp) - c_Pos_tmp;
            Pos[0] = X1[0];
            Pos[1] = dv[0] * b_Pos[0] + bkj * dv[2];
            Pos[2] = X1[1];
            Pos[3] = b_Pos[0] * dv[1] + bkj * dv[3];
          } else {
            X1[0] = (xa_data[k] + xa_data[boffset]) / 2.0;
            X1[1] = (ya_data[k] + ya_data[boffset]) / 2.0;
            Pos[0] = X1[0];
            Pos[1] = X1[0];
            Pos[2] = X1[1];
            Pos[3] = X1[1];
          }
          /*  end */
          coffset = (v << 1) - 1;
          Pos3_data[coffset - 1].re = Pos[0];
          Pos3_data[coffset - 1].im = Pos[2];
          Pos3_data[coffset].re = Pos[1];
          Pos3_data[coffset].im = Pos[3];
          v++;
        }
      }
    }
    emxInit_creal_T(&x);
    i = x->size[0] * x->size[1];
    x->size[0] = 12;
    x->size[1] = 12;
    emxEnsureCapacity_creal_T(x, i);
    x_data = x->data;
    for (i = 0; i < 12; i++) {
      for (loop_ub = 0; loop_ub < 12; loop_ub++) {
        x_data[loop_ub + x->size[0] * i].re =
            Pos3_data[i].re - Pos3_data[loop_ub].re;
        x_data[loop_ub + x->size[0] * i].im =
            Pos3_data[i].im - Pos3_data[loop_ub].im;
      }
    }
    emxInit_real_T(&b_y, 2);
    i = b_y->size[0] * b_y->size[1];
    b_y->size[0] = 12;
    b_y->size[1] = 12;
    emxEnsureCapacity_real_T(b_y, i);
    b_y_data = b_y->data;
    for (k = 0; k < 144; k++) {
      b_y_data[k] = rt_hypotd_snf(x_data[k].re, x_data[k].im);
    }
    emxFree_creal_T(&x);
    for (i = 0; i < 144; i++) {
      bkj = b_y_data[i];
      b_x_data[i] = bkj * bkj;
    }
    emxFree_real_T(&b_y);
    for (boffset = 0; boffset < 12; boffset++) {
      coffset = boffset * 12;
      d = b_x_data[coffset];
      for (k = 0; k < 11; k++) {
        d += b_x_data[(coffset + k) + 1];
      }
      meanTempW_data[boffset] = d;
    }
    for (i = 0; i <= 10; i += 2) {
      r = _mm_loadu_pd(&meanTempW_data[i]);
      _mm_storeu_pd(&meanTempW_data[i], _mm_div_pd(r, _mm_set1_pd(12.0)));
    }
    Pos2_size[0] = 1;
    Pos2_size[1] = 6;
    for (boffset = 0; boffset < 6; boffset++) {
      i = boffset << 1;
      d = meanTempW_data[i];
      d1 = meanTempW_data[i + 1];
      if ((d > d1) || (rtIsNaN(d) && (!rtIsNaN(d1)))) {
        coffset = 1;
      } else {
        coffset = 0;
      }
      /*  meanTemp(kk+1) = v; */
      Pos2_data[boffset] = Pos3_data[i + coffset];
    }
  } else {
    Pos1->re = 0.0;
    Pos1->im = 0.0;
    Pos2_size[0] = 1;
    Pos2_size[1] = 1;
    Pos2_data[0].re = 0.0;
    Pos2_data[0].im = 0.0;
  }
}

/*
 * File trailer for UWBpos_V2_3.c
 *
 * [EOF]
 */
