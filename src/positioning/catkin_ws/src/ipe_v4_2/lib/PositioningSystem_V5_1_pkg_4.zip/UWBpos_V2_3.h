/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: UWBpos_V2_3.h
 *
 * MATLAB Coder version            : 24.1
 * C/C++ source code generated on  : 2024-07-23 23:09:33
 */

#ifndef UWBPOS_V2_3_H
#define UWBPOS_V2_3_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void UWBpos_V2_3(double Nanchor, const double RxIDin_data[],
                 const double RxDistin_data[], const double xain_data[],
                 const double yain_data[], creal_T *Pos1, creal_T Pos2_data[],
                 int Pos2_size[2], creal_T Pos3_data[], int Pos3_size[2]);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for UWBpos_V2_3.h
 *
 * [EOF]
 */
