/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: PositioningSystem_V5_1_rtwutil.h
 *
 * MATLAB Coder version            : 24.1
 * C/C++ source code generated on  : 2024-07-23 23:09:33
 */

#ifndef POSITIONINGSYSTEM_V5_1_RTWUTIL_H
#define POSITIONINGSYSTEM_V5_1_RTWUTIL_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern double rt_atan2d_snf(double u0, double u1);

extern double rt_hypotd_snf(double u0, double u1);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for PositioningSystem_V5_1_rtwutil.h
 *
 * [EOF]
 */
