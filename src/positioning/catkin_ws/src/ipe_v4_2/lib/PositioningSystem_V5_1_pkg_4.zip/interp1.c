/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: interp1.c
 *
 * MATLAB Coder version            : 24.1
 * C/C++ source code generated on  : 2024-07-23 23:09:33
 */

/* Include Files */
#include "interp1.h"
#include "rt_nonfinite.h"
#include "rt_nonfinite.h"
#include <emmintrin.h>
#include <string.h>

/* Function Definitions */
/*
 * Arguments    : const double varargin_1_data[]
 *                const int varargin_1_size[2]
 *                const double varargin_2_data[]
 *                const int varargin_2_size[2]
 *                double varargin_3
 * Return Type  : double
 */
double interp1(const double varargin_1_data[], const int varargin_1_size[2],
               const double varargin_2_data[], const int varargin_2_size[2],
               double varargin_3)
{
  __m128d b_r;
  __m128d r1;
  __m128d r2;
  __m128d r3;
  double pp_coefs_data[396];
  double md_data[100];
  double pp_breaks_data[100];
  double s_data[100];
  double y_data[100];
  double dvdf_data[99];
  double dx_data[99];
  double Vq;
  double d31;
  double dnnm2;
  double r;
  double xtmp;
  int exitg1;
  int i;
  int j2;
  int k;
  int low_ip1;
  int mid_i;
  int nx_tmp;
  int pp_breaks_size_idx_1;
  int yoffset;
  signed char szs_idx_1;
  boolean_T has_endslopes;
  j2 = varargin_2_size[1];
  low_ip1 = varargin_2_size[1];
  if (j2 - 1 >= 0) {
    memcpy(&y_data[0], &varargin_2_data[0], (unsigned int)j2 * sizeof(double));
  }
  j2 = varargin_1_size[1];
  pp_breaks_size_idx_1 = varargin_1_size[1];
  if (j2 - 1 >= 0) {
    memcpy(&pp_breaks_data[0], &varargin_1_data[0],
           (unsigned int)j2 * sizeof(double));
  }
  nx_tmp = varargin_1_size[1] - 1;
  k = 0;
  do {
    exitg1 = 0;
    if (k <= nx_tmp) {
      if (rtIsNaN(varargin_1_data[k])) {
        exitg1 = 1;
      } else {
        k++;
      }
    } else {
      if (varargin_1_data[1] < varargin_1_data[0]) {
        i = (nx_tmp + 1) >> 1;
        for (mid_i = 0; mid_i < i; mid_i++) {
          xtmp = pp_breaks_data[mid_i];
          j2 = nx_tmp - mid_i;
          pp_breaks_data[mid_i] = pp_breaks_data[j2];
          pp_breaks_data[j2] = xtmp;
        }
        i = varargin_2_size[1] >> 1;
        for (mid_i = 0; mid_i < i; mid_i++) {
          j2 = (varargin_2_size[1] - mid_i) - 1;
          xtmp = y_data[mid_i];
          y_data[mid_i] = y_data[j2];
          y_data[j2] = xtmp;
        }
      }
      has_endslopes = (low_ip1 == pp_breaks_size_idx_1 + 2);
      if ((pp_breaks_size_idx_1 <= 3) && (!has_endslopes)) {
        k = 3;
        xtmp = pp_breaks_data[1] - pp_breaks_data[0];
        r = (y_data[1] - y_data[0]) / xtmp;
        pp_coefs_data[0] =
            ((y_data[2] - y_data[1]) / (pp_breaks_data[2] - pp_breaks_data[1]) -
             r) /
            (pp_breaks_data[2] - pp_breaks_data[0]);
        pp_coefs_data[1] = r - pp_coefs_data[0] * xtmp;
        pp_coefs_data[2] = y_data[0];
        xtmp = pp_breaks_data[0];
        r = pp_breaks_data[2];
        pp_breaks_size_idx_1 = 2;
        pp_breaks_data[0] = xtmp;
        pp_breaks_data[1] = r;
      } else {
        if (has_endslopes) {
          szs_idx_1 = (signed char)(low_ip1 - 2);
          yoffset = 1;
        } else {
          szs_idx_1 = (signed char)low_ip1;
          yoffset = 0;
        }
        i = (unsigned char)(pp_breaks_size_idx_1 - 1);
        mid_i = ((unsigned char)(pp_breaks_size_idx_1 - 1) >> 1) << 1;
        j2 = mid_i - 2;
        for (k = 0; k <= j2; k += 2) {
          b_r = _mm_loadu_pd(&pp_breaks_data[k + 1]);
          r1 = _mm_loadu_pd(&pp_breaks_data[k]);
          b_r = _mm_sub_pd(b_r, r1);
          _mm_storeu_pd(&dx_data[k], b_r);
          low_ip1 = yoffset + k;
          r1 = _mm_loadu_pd(&y_data[low_ip1 + 1]);
          r2 = _mm_loadu_pd(&y_data[low_ip1]);
          _mm_storeu_pd(&dvdf_data[k], _mm_div_pd(_mm_sub_pd(r1, r2), b_r));
        }
        for (k = mid_i; k < i; k++) {
          xtmp = pp_breaks_data[k + 1] - pp_breaks_data[k];
          dx_data[k] = xtmp;
          j2 = yoffset + k;
          dvdf_data[k] = (y_data[j2 + 1] - y_data[j2]) / xtmp;
        }
        j2 = (((pp_breaks_size_idx_1 - 2) / 2) << 1) + 2;
        low_ip1 = j2 - 2;
        for (k = 2; k <= low_ip1; k += 2) {
          b_r = _mm_loadu_pd(&dx_data[k - 1]);
          r1 = _mm_loadu_pd(&dvdf_data[k - 2]);
          r2 = _mm_loadu_pd(&dx_data[k - 2]);
          r3 = _mm_loadu_pd(&dvdf_data[k - 1]);
          _mm_storeu_pd(
              &s_data[k - 1],
              _mm_mul_pd(_mm_set1_pd(3.0),
                         _mm_add_pd(_mm_mul_pd(b_r, r1), _mm_mul_pd(r2, r3))));
        }
        for (k = j2; k <= nx_tmp; k++) {
          s_data[k - 1] = 3.0 * (dx_data[k - 1] * dvdf_data[k - 2] +
                                 dx_data[k - 2] * dvdf_data[k - 1]);
        }
        if (has_endslopes) {
          d31 = 0.0;
          dnnm2 = 0.0;
          s_data[0] = y_data[0] * dx_data[1];
          s_data[nx_tmp] = dx_data[pp_breaks_size_idx_1 - 3] *
                           y_data[pp_breaks_size_idx_1 + 1];
        } else {
          d31 = pp_breaks_data[2] - pp_breaks_data[0];
          dnnm2 =
              pp_breaks_data[nx_tmp] - pp_breaks_data[pp_breaks_size_idx_1 - 3];
          s_data[0] = ((dx_data[0] + 2.0 * d31) * dx_data[1] * dvdf_data[0] +
                       dx_data[0] * dx_data[0] * dvdf_data[1]) /
                      d31;
          xtmp = dx_data[pp_breaks_size_idx_1 - 2];
          s_data[nx_tmp] =
              ((xtmp + 2.0 * dnnm2) * dx_data[pp_breaks_size_idx_1 - 3] *
                   dvdf_data[pp_breaks_size_idx_1 - 2] +
               xtmp * xtmp * dvdf_data[pp_breaks_size_idx_1 - 3]) /
              dnnm2;
        }
        md_data[0] = dx_data[1];
        xtmp = dx_data[pp_breaks_size_idx_1 - 3];
        md_data[nx_tmp] = xtmp;
        for (k = 2; k <= low_ip1; k += 2) {
          b_r = _mm_loadu_pd(&dx_data[k - 1]);
          r1 = _mm_loadu_pd(&dx_data[k - 2]);
          _mm_storeu_pd(&md_data[k - 1],
                        _mm_mul_pd(_mm_set1_pd(2.0), _mm_add_pd(b_r, r1)));
        }
        for (k = j2; k <= nx_tmp; k++) {
          md_data[k - 1] = 2.0 * (dx_data[k - 1] + dx_data[k - 2]);
        }
        r = dx_data[1] / md_data[0];
        md_data[1] -= r * d31;
        s_data[1] -= r * s_data[0];
        for (k = 3; k <= nx_tmp; k++) {
          r = dx_data[k - 1] / md_data[k - 2];
          md_data[k - 1] -= r * dx_data[k - 3];
          s_data[k - 1] -= r * s_data[k - 2];
        }
        r = dnnm2 / md_data[pp_breaks_size_idx_1 - 2];
        md_data[nx_tmp] -= r * xtmp;
        s_data[nx_tmp] -= r * s_data[pp_breaks_size_idx_1 - 2];
        s_data[nx_tmp] /= md_data[nx_tmp];
        for (k = nx_tmp; k >= 2; k--) {
          s_data[k - 1] =
              (s_data[k - 1] - dx_data[k - 2] * s_data[k]) / md_data[k - 1];
        }
        s_data[0] = (s_data[0] - d31 * s_data[1]) / md_data[0];
        k = 4;
        for (j2 = 0; j2 < i; j2++) {
          xtmp = dvdf_data[j2];
          r = s_data[j2];
          d31 = dx_data[j2];
          dnnm2 = (xtmp - r) / d31;
          xtmp = (s_data[j2 + 1] - xtmp) / d31;
          pp_coefs_data[j2] = (xtmp - dnnm2) / d31;
          pp_coefs_data[(szs_idx_1 + j2) - 1] = 2.0 * dnnm2 - xtmp;
          pp_coefs_data[((szs_idx_1 - 1) << 1) + j2] = r;
          pp_coefs_data[3 * (szs_idx_1 - 1) + j2] = y_data[yoffset + j2];
        }
      }
      if (rtIsNaN(varargin_3)) {
        Vq = rtNaN;
      } else {
        j2 = pp_breaks_size_idx_1;
        yoffset = 1;
        low_ip1 = 2;
        while (j2 > low_ip1) {
          mid_i = (yoffset >> 1) + (j2 >> 1);
          if (((yoffset & 1) == 1) && ((j2 & 1) == 1)) {
            mid_i++;
          }
          if (varargin_3 >= pp_breaks_data[mid_i - 1]) {
            yoffset = mid_i;
            low_ip1 = mid_i + 1;
          } else {
            j2 = mid_i;
          }
        }
        xtmp = varargin_3 - pp_breaks_data[yoffset - 1];
        Vq = pp_coefs_data[yoffset - 1];
        for (j2 = 2; j2 <= k; j2++) {
          Vq = xtmp * Vq +
               pp_coefs_data[(yoffset + (j2 - 1) * (pp_breaks_size_idx_1 - 1)) -
                             1];
        }
      }
      exitg1 = 1;
    }
  } while (exitg1 == 0);
  return Vq;
}

/*
 * File trailer for interp1.c
 *
 * [EOF]
 */
