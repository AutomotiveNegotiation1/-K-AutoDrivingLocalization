/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: makePredA_3D_Simple.c
 *
 * MATLAB Coder version            : 24.1
 * C/C++ source code generated on  : 2024-07-23 23:09:33
 */

/* Include Files */
#include "makePredA_3D_Simple.h"
#include "rt_nonfinite.h"
#include <math.h>
#include <string.h>

/* Function Definitions */
/*
 * Arguments    : const double Xhat[15]
 *                const double acc[3]
 *                const double p[3]
 *                double A[225]
 * Return Type  : void
 */
void makePredA_3D_Simple(const double Xhat[15], const double acc[3],
                         const double p[3], double A[225])
{
  static const double y[9] = {0.005, 0.0, 0.0, 0.0,  0.005,
                              0.0,   0.0, 0.0, 0.005};
  static const signed char b[3] = {-1, 0, 0};
  static const signed char b_b[3] = {0, -1, 0};
  static const signed char c_b[3] = {0, 0, -1};
  double RotMat[9];
  double RotMatRalp[9];
  double RotMatRbet[9];
  double RotMatRgam[9];
  double ZyroUpdateRbet[9];
  double b_tmp[3];
  double A_tmp;
  double RotMat_tmp;
  double RotMat_tmp_tmp;
  double ZyroUpdate_tmp;
  double b_A_tmp;
  double b_RotMat_tmp;
  double b_RotMat_tmp_tmp;
  double b_ZyroUpdate_tmp;
  double c_A_tmp;
  double c_RotMat_tmp;
  double c_RotMat_tmp_tmp;
  double c_ZyroUpdate_tmp;
  double d;
  double d1;
  double d10;
  double d11;
  double d12;
  double d13;
  double d14;
  double d15;
  double d16;
  double d17;
  double d18;
  double d19;
  double d2;
  double d20;
  double d21;
  double d3;
  double d4;
  double d5;
  double d6;
  double d7;
  double d8;
  double d9;
  double d_A_tmp;
  double d_RotMat_tmp;
  double d_RotMat_tmp_tmp;
  double e_A_tmp;
  double e_RotMat_tmp;
  double e_RotMat_tmp_tmp;
  double f_A_tmp;
  double f_RotMat_tmp;
  double g_A_tmp;
  double g_RotMat_tmp;
  double h_A_tmp;
  double h_RotMat_tmp;
  double i_A_tmp;
  double i_RotMat_tmp;
  double j_A_tmp;
  double j_RotMat_tmp;
  double k_A_tmp;
  double l_A_tmp;
  double m_A_tmp;
  double n_A_tmp;
  int A_tmp_tmp;
  int RotMatRalp_tmp;
  int ZyroUpdateRbet_tmp;
  int b_A_tmp_tmp;
  int i;
  int k;
  memset(&A[0], 0, 225U * sizeof(double));
  for (k = 0; k < 15; k++) {
    A[k + 15 * k] = 1.0;
  }
  RotMat_tmp_tmp = sin(Xhat[9]);
  RotMat_tmp = cos(Xhat[11]);
  b_RotMat_tmp = cos(Xhat[9]);
  b_RotMat_tmp_tmp = sin(Xhat[11]);
  c_RotMat_tmp_tmp = cos(Xhat[10]);
  d_RotMat_tmp_tmp = sin(Xhat[10]);
  c_RotMat_tmp = RotMat_tmp_tmp * c_RotMat_tmp_tmp;
  RotMat[0] = c_RotMat_tmp;
  d_RotMat_tmp = RotMat_tmp_tmp * d_RotMat_tmp_tmp;
  e_RotMat_tmp = b_RotMat_tmp * RotMat_tmp;
  RotMat[3] = d_RotMat_tmp * b_RotMat_tmp_tmp + e_RotMat_tmp;
  f_RotMat_tmp = b_RotMat_tmp * b_RotMat_tmp_tmp;
  d_RotMat_tmp = d_RotMat_tmp * RotMat_tmp - f_RotMat_tmp;
  RotMat[6] = d_RotMat_tmp;
  g_RotMat_tmp = b_RotMat_tmp * c_RotMat_tmp_tmp;
  RotMat[1] = g_RotMat_tmp;
  h_RotMat_tmp = b_RotMat_tmp * d_RotMat_tmp_tmp;
  e_RotMat_tmp_tmp = RotMat_tmp_tmp * RotMat_tmp;
  i_RotMat_tmp = h_RotMat_tmp * b_RotMat_tmp_tmp - e_RotMat_tmp_tmp;
  RotMat[4] = i_RotMat_tmp;
  h_RotMat_tmp = h_RotMat_tmp * RotMat_tmp + RotMat_tmp_tmp * b_RotMat_tmp_tmp;
  RotMat[7] = h_RotMat_tmp;
  RotMat[2] = -d_RotMat_tmp_tmp;
  RotMat[5] = c_RotMat_tmp_tmp * b_RotMat_tmp_tmp;
  j_RotMat_tmp = c_RotMat_tmp_tmp * RotMat_tmp;
  RotMat[8] = j_RotMat_tmp;
  RotMatRalp[0] = g_RotMat_tmp;
  RotMatRalp[3] = i_RotMat_tmp;
  RotMatRalp[6] = h_RotMat_tmp;
  RotMatRalp[1] = -RotMat_tmp_tmp * c_RotMat_tmp_tmp;
  RotMat_tmp_tmp = -RotMat_tmp_tmp * d_RotMat_tmp_tmp;
  i_RotMat_tmp = RotMat_tmp_tmp * b_RotMat_tmp_tmp - e_RotMat_tmp;
  RotMatRalp[4] = i_RotMat_tmp;
  RotMatRalp[7] = RotMat_tmp_tmp * RotMat_tmp + f_RotMat_tmp;
  RotMatRbet[0] = RotMat_tmp_tmp;
  RotMatRbet[3] = c_RotMat_tmp * b_RotMat_tmp_tmp;
  RotMatRbet[6] = c_RotMat_tmp * RotMat_tmp;
  RotMat_tmp_tmp = -b_RotMat_tmp * d_RotMat_tmp_tmp;
  RotMatRbet[1] = RotMat_tmp_tmp;
  RotMatRbet[4] = g_RotMat_tmp * b_RotMat_tmp_tmp;
  RotMatRbet[7] = g_RotMat_tmp * RotMat_tmp;
  RotMatRbet[2] = -c_RotMat_tmp_tmp;
  RotMatRbet[5] = -d_RotMat_tmp_tmp * b_RotMat_tmp_tmp;
  RotMatRbet[8] = -d_RotMat_tmp_tmp * RotMat_tmp;
  RotMatRgam[0] = 0.0;
  RotMatRgam[3] = d_RotMat_tmp;
  RotMatRgam[6] = i_RotMat_tmp;
  RotMatRgam[1] = 0.0;
  RotMatRgam[4] = h_RotMat_tmp;
  RotMatRgam[7] = RotMat_tmp_tmp * b_RotMat_tmp_tmp + e_RotMat_tmp_tmp;
  RotMatRgam[2] = 0.0;
  RotMatRgam[5] = j_RotMat_tmp;
  RotMatRgam[8] = -c_RotMat_tmp_tmp * b_RotMat_tmp_tmp;
  ZyroUpdate_tmp = tan(Xhat[10]);
  b_ZyroUpdate_tmp = RotMat_tmp * ZyroUpdate_tmp;
  c_ZyroUpdate_tmp = RotMat_tmp / c_RotMat_tmp_tmp;
  RotMat_tmp_tmp = c_RotMat_tmp_tmp * c_RotMat_tmp_tmp;
  ZyroUpdateRbet[3] = b_RotMat_tmp_tmp / RotMat_tmp_tmp;
  ZyroUpdateRbet[6] = RotMat_tmp / RotMat_tmp_tmp;
  ZyroUpdateRbet[5] = b_RotMat_tmp_tmp * d_RotMat_tmp_tmp / RotMat_tmp_tmp;
  ZyroUpdateRbet[8] = RotMat_tmp * d_RotMat_tmp_tmp / RotMat_tmp_tmp;
  A_tmp = 0.0;
  b_A_tmp = 0.0;
  c_A_tmp = 0.0;
  b_tmp[0] = acc[0] - Xhat[6];
  b_tmp[1] = acc[1] - Xhat[7];
  b_tmp[2] = acc[2] - Xhat[8];
  d = 0.0;
  d1 = 0.0;
  RotMat_tmp_tmp = 0.0;
  d_A_tmp = 0.0;
  e_A_tmp = 0.0;
  f_A_tmp = 0.0;
  i_RotMat_tmp = 0.0;
  e_RotMat_tmp = 0.0;
  b_RotMat_tmp = 0.0;
  g_A_tmp = 0.0;
  h_A_tmp = 0.0;
  c_RotMat_tmp = 0.0;
  d2 = 0.0;
  f_RotMat_tmp = 0.0;
  d_RotMat_tmp = 0.0;
  g_RotMat_tmp = 0.0;
  h_RotMat_tmp = 0.0;
  e_RotMat_tmp_tmp = 0.0;
  j_RotMat_tmp = 0.0;
  d_RotMat_tmp_tmp = 0.0;
  d3 = 0.0;
  i_A_tmp = 0.0;
  j_A_tmp = 0.0;
  k_A_tmp = 0.0;
  d4 = 0.0;
  d5 = 0.0;
  d6 = 0.0;
  l_A_tmp = 0.0;
  m_A_tmp = 0.0;
  n_A_tmp = 0.0;
  d7 = 0.0;
  d8 = 0.0;
  d9 = 0.0;
  for (i = 0; i < 3; i++) {
    RotMatRalp_tmp = 3 * i + 2;
    RotMatRalp[RotMatRalp_tmp] = 0.0;
    ZyroUpdateRbet_tmp = 3 * i + 1;
    ZyroUpdateRbet[ZyroUpdateRbet_tmp] = 0.0;
    k = 15 * (i + 3);
    A[k] = y[3 * i];
    A[k + 1] = y[ZyroUpdateRbet_tmp];
    A[k + 2] = y[RotMatRalp_tmp];
    d7 = RotMat[3 * i];
    d10 = 1.25E-5 * d7;
    k = b[i];
    A_tmp += d10 * (double)k;
    A_tmp_tmp = b_b[i];
    b_A_tmp += d10 * (double)A_tmp_tmp;
    b_A_tmp_tmp = c_b[i];
    c_A_tmp += d10 * (double)b_A_tmp_tmp;
    d11 = RotMatRalp[3 * i];
    d12 = b_tmp[i];
    d += 1.25E-5 * d11 * d12;
    d13 = RotMatRbet[3 * i];
    d1 += 1.25E-5 * d13 * d12;
    d14 = RotMatRgam[3 * i];
    RotMat_tmp_tmp += 1.25E-5 * d14 * d12;
    d15 = RotMat[ZyroUpdateRbet_tmp];
    d10 = 1.25E-5 * d15;
    d_A_tmp += d10 * (double)k;
    e_A_tmp += d10 * (double)A_tmp_tmp;
    f_A_tmp += d10 * (double)b_A_tmp_tmp;
    d16 = RotMatRalp[ZyroUpdateRbet_tmp];
    i_RotMat_tmp += 1.25E-5 * d16 * d12;
    d17 = RotMatRbet[ZyroUpdateRbet_tmp];
    e_RotMat_tmp += 1.25E-5 * d17 * d12;
    d18 = RotMatRgam[ZyroUpdateRbet_tmp];
    b_RotMat_tmp += 1.25E-5 * d18 * d12;
    d19 = RotMat[RotMatRalp_tmp];
    d10 = 1.25E-5 * d19;
    g_A_tmp += d10 * (double)k;
    h_A_tmp += d10 * (double)A_tmp_tmp;
    c_RotMat_tmp += d10 * (double)b_A_tmp_tmp;
    d2 += 0.0 * d12;
    d20 = RotMatRbet[RotMatRalp_tmp];
    f_RotMat_tmp += 1.25E-5 * d20 * d12;
    d21 = RotMatRgam[RotMatRalp_tmp];
    d_RotMat_tmp += 1.25E-5 * d21 * d12;
    d10 = 0.005 * d7;
    g_RotMat_tmp += d10 * (double)k;
    h_RotMat_tmp += d10 * (double)A_tmp_tmp;
    e_RotMat_tmp_tmp += d10 * (double)b_A_tmp_tmp;
    j_RotMat_tmp += 0.005 * d11 * d12;
    d_RotMat_tmp_tmp += 0.005 * d13 * d12;
    d3 += 0.005 * d14 * d12;
    d10 = 0.005 * d15;
    i_A_tmp += d10 * (double)k;
    j_A_tmp += d10 * (double)A_tmp_tmp;
    k_A_tmp += d10 * (double)b_A_tmp_tmp;
    d4 += 0.005 * d16 * d12;
    d5 += 0.005 * d17 * d12;
    d6 += 0.005 * d18 * d12;
    d10 = 0.005 * d19;
    l_A_tmp += d10 * (double)k;
    m_A_tmp += d10 * (double)A_tmp_tmp;
    n_A_tmp += d10 * (double)b_A_tmp_tmp;
    d7 = d2;
    d8 += 0.005 * d20 * d12;
    d9 += 0.005 * d21 * d12;
  }
  A[90] = A_tmp;
  A[105] = b_A_tmp;
  A[120] = c_A_tmp;
  A[135] = d;
  A[150] = d1;
  A[165] = RotMat_tmp_tmp;
  A[91] = d_A_tmp;
  A[106] = e_A_tmp;
  A[121] = f_A_tmp;
  A[136] = i_RotMat_tmp;
  A[151] = e_RotMat_tmp;
  A[166] = b_RotMat_tmp;
  A[92] = g_A_tmp;
  A[107] = h_A_tmp;
  A[122] = c_RotMat_tmp;
  A[137] = d2;
  A[152] = f_RotMat_tmp;
  A[167] = d_RotMat_tmp;
  A[93] = g_RotMat_tmp;
  A[108] = h_RotMat_tmp;
  A[123] = e_RotMat_tmp_tmp;
  A[138] = j_RotMat_tmp;
  A[153] = d_RotMat_tmp_tmp;
  A[168] = d3;
  A[94] = i_A_tmp;
  A[109] = j_A_tmp;
  A[124] = k_A_tmp;
  A[139] = d4;
  A[154] = d5;
  A[169] = d6;
  A[95] = l_A_tmp;
  A[110] = m_A_tmp;
  A[125] = n_A_tmp;
  A[140] = d7;
  A[155] = d8;
  A[170] = d9;
  b_tmp[1] = p[1] - Xhat[13];
  b_tmp[2] = p[2] - Xhat[14];
  A_tmp = 0.0 * (p[0] - Xhat[12]);
  e_RotMat_tmp = (A_tmp + 0.0 * b_tmp[1]) + 0.0 * b_tmp[2];
  A[174] = ((A_tmp + 0.005 * c_ZyroUpdate_tmp * b_tmp[1]) +
            0.005 * (-b_RotMat_tmp_tmp / c_RotMat_tmp_tmp) * b_tmp[2]) +
           1.0;
  A[159] = (A_tmp + 0.005 * ZyroUpdateRbet[5] * b_tmp[1]) +
           0.005 * ZyroUpdateRbet[8] * b_tmp[2];
  A[144] = e_RotMat_tmp;
  A[145] = e_RotMat_tmp;
  A[146] = e_RotMat_tmp + 1.0;
  d = 0.005 * (b_RotMat_tmp_tmp / c_RotMat_tmp_tmp);
  RotMat_tmp_tmp = d * 0.0;
  b_A_tmp = -d;
  d = 0.005 * RotMat_tmp;
  i_RotMat_tmp = d * 0.0;
  c_A_tmp = -d;
  d = 0.005 * (b_RotMat_tmp_tmp * ZyroUpdate_tmp);
  d_A_tmp = d * 0.0 - 0.005;
  e_A_tmp = -d;
  f_A_tmp = d * 0.0;
  d = 0.005 * c_ZyroUpdate_tmp;
  g_A_tmp = RotMat_tmp_tmp + d * 0.0;
  b_A_tmp += d * 0.0;
  h_A_tmp = RotMat_tmp_tmp - d;
  d1 = 0.005 * -b_RotMat_tmp_tmp;
  c_A_tmp += d1 * 0.0;
  d = 0.005 * b_ZyroUpdate_tmp;
  d_A_tmp += d * 0.0;
  e_A_tmp += d * 0.0;
  f_A_tmp -= d;
  A[189] = g_A_tmp;
  A[204] = b_A_tmp;
  A[219] = h_A_tmp;
  A[175] = (A_tmp + d1 * b_tmp[1]) + 0.005 * -RotMat_tmp * b_tmp[2];
  A[160] = e_RotMat_tmp + 1.0;
  A[190] = i_RotMat_tmp + d1 * 0.0;
  A[205] = c_A_tmp;
  A[220] = i_RotMat_tmp - d1;
  A[176] = (A_tmp + 0.005 * b_ZyroUpdate_tmp * b_tmp[1]) +
           0.005 * (-b_RotMat_tmp_tmp * ZyroUpdate_tmp) * b_tmp[2];
  A[161] = (A_tmp + 0.005 * ZyroUpdateRbet[3] * b_tmp[1]) +
           0.005 * ZyroUpdateRbet[6] * b_tmp[2];
  A[191] = d_A_tmp;
  A[206] = e_A_tmp;
  A[221] = f_A_tmp;
}

/*
 * File trailer for makePredA_3D_Simple.c
 *
 * [EOF]
 */
