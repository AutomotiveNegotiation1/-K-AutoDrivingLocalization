/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: PositioningSystem_V5_1_terminate.h
 *
 * MATLAB Coder version            : 24.1
 * C/C++ source code generated on  : 2024-07-23 23:09:33
 */

#ifndef POSITIONINGSYSTEM_V5_1_TERMINATE_H
#define POSITIONINGSYSTEM_V5_1_TERMINATE_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void PositioningSystem_V5_1_terminate(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for PositioningSystem_V5_1_terminate.h
 *
 * [EOF]
 */
