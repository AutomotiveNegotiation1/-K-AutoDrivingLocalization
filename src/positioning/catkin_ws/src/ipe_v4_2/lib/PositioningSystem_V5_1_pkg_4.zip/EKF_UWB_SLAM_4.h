/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: EKF_UWB_SLAM_4.h
 *
 * MATLAB Coder version            : 24.1
 * C/C++ source code generated on  : 2024-07-23 23:09:33
 */

#ifndef EKF_UWB_SLAM_4_H
#define EKF_UWB_SLAM_4_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void EKF_UWB_SLAM_4(const creal_T PosUWB, double HeadUWB, double dPosSLAM[3],
                    double dHeadSLAM[3], const double PosSLAMc[3],
                    creal_T *Posn, double Headn[3]);

void EKF_UWB_SLAM_4_init(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for EKF_UWB_SLAM_4.h
 *
 * [EOF]
 */
