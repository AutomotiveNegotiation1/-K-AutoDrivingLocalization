/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: PositioningSystem_V5_1_data.c
 *
 * MATLAB Coder version            : 24.1
 * C/C++ source code generated on  : 2024-07-23 23:09:33
 */

/* Include Files */
#include "PositioningSystem_V5_1_data.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
double PosP[3];

double roll;

double pitch;

double yaw;

double s;

double Hroll;

double Hpitch;

double Hyaw;

creal_T totPosP[5];

double UWBless;

const int iv[4] = {0, 1, 2, 3};

boolean_T isInitialized_PositioningSystem_V5_1_4 = false;

/*
 * File trailer for PositioningSystem_V5_1_data.c
 *
 * [EOF]
 */
