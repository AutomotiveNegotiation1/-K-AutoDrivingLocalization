/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: EKF_UWB_SLAM_IMU_1.h
 *
 * MATLAB Coder version            : 24.1
 * C/C++ source code generated on  : 2024-07-23 23:09:33
 */

#ifndef EKF_UWB_SLAM_IMU_1_H
#define EKF_UWB_SLAM_IMU_1_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
double EKF_UWB_SLAM_IMU_1(const double acc[3], const double GyroD[3],
                          double IMUtime, const creal_T PosUWB, double HeadUWB,
                          double UWBtime, creal_T *PosHF, double *GammHF,
                          double *BetaHF);

void EKF_UWB_SLAM_IMU_1_init(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for EKF_UWB_SLAM_IMU_1.h
 *
 * [EOF]
 */
