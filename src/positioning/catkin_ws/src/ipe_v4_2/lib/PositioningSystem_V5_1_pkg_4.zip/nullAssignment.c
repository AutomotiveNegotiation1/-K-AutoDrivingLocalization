/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: nullAssignment.c
 *
 * MATLAB Coder version            : 24.1
 * C/C++ source code generated on  : 2024-07-23 23:09:33
 */

/* Include Files */
#include "nullAssignment.h"
#include "rt_nonfinite.h"
#include <string.h>

/* Function Definitions */
/*
 * Arguments    : creal_T x_data[]
 *                int x_size[2]
 *                const int idx_data[]
 *                const int idx_size[2]
 * Return Type  : void
 */
void nullAssignment(creal_T x_data[], int x_size[2], const int idx_data[],
                    const int idx_size[2])
{
  int k;
  int k0;
  int nxin_tmp;
  int nxout;
  boolean_T b_data[12];
  boolean_T b;
  nxin_tmp = x_size[1];
  if (nxin_tmp - 1 >= 0) {
    memset(&b_data[0], 0, (unsigned int)nxin_tmp * sizeof(boolean_T));
  }
  nxout = idx_size[1];
  for (k = 0; k < nxout; k++) {
    b_data[idx_data[k] - 1] = true;
  }
  nxout = 0;
  k0 = -1;
  for (k = 0; k < nxin_tmp; k++) {
    b = b_data[k];
    nxout += b;
    if ((k + 1 > nxin_tmp) || (!b)) {
      k0++;
      x_data[k0] = x_data[k];
    }
  }
  nxout = x_size[1] - nxout;
  if (nxout < 1) {
    x_size[1] = 0;
  } else {
    x_size[1] = nxout;
  }
}

/*
 * File trailer for nullAssignment.c
 *
 * [EOF]
 */
