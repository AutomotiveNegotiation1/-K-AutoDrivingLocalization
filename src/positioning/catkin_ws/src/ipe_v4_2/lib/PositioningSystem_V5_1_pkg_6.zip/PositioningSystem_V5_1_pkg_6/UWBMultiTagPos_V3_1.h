/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: UWBMultiTagPos_V3_1.h
 *
 * MATLAB Coder version            : 5.5
 * C/C++ source code generated on  : 24-Jul-2024 13:01:20
 */

#ifndef UWBMULTITAGPOS_V3_1_H
#define UWBMULTITAGPOS_V3_1_H

/* Include Files */
#include "PositioningSystem_V5_1_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void UWBMultiTagPos_V3_1(const cell_wrap_4 b_PosUWB2[4],
                         const double xt_b_data[], const int xt_b_size[2],
                         const double yt_b_data[], const int yt_b_size[2],
                         const double xain_data[], const int xain_size[2],
                         const double yain_data[], const int yain_size[2],
                         const emxArray_real_T *b_DistMap, double Ln,
                         creal_T *PosHH, double *HeadingHH);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for UWBMultiTagPos_V3_1.h
 *
 * [EOF]
 */
