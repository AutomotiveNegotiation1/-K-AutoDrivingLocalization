/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: xzgetrf.h
 *
 * MATLAB Coder version            : 5.5
 * C/C++ source code generated on  : 24-Jul-2024 13:01:20
 */

#ifndef XZGETRF_H
#define XZGETRF_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void xzgetrf(double A[36], int ipiv[6], int *info);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for xzgetrf.h
 *
 * [EOF]
 */
