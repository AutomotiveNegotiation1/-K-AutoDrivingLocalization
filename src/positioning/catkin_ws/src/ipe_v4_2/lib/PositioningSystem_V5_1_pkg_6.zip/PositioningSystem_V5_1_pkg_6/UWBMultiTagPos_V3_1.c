/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: UWBMultiTagPos_V3_1.c
 *
 * MATLAB Coder version            : 5.5
 * C/C++ source code generated on  : 24-Jul-2024 13:01:20
 */

/* Include Files */
#include "UWBMultiTagPos_V3_1.h"
#include "PositioningSystem_V5_1_data.h"
#include "PositioningSystem_V5_1_emxutil.h"
#include "PositioningSystem_V5_1_rtwutil.h"
#include "PositioningSystem_V5_1_types.h"
#include "UWBPosition_V4_1.h"
#include "abs.h"
#include "find.h"
#include "mean.h"
#include "rt_nonfinite.h"
#include "sort.h"
#include <math.h>
#include <string.h>

/* Function Declarations */
static creal_T b_binary_expand_op(const creal_T in1[4], const creal_T in2,
                                  const creal_T in3_data[],
                                  const int in3_size[2]);

static void binary_expand_op(emxArray_real_T *in1, const emxArray_real_T *in2);

static void c_binary_expand_op(emxArray_real_T *in1, const emxArray_real_T *in2,
                               const emxArray_real_T *in3);

static void e_binary_expand_op(emxArray_creal_T *in1, const double in3_data[],
                               const int in3_size[2], const double in5_data[],
                               const int in5_size[2]);

/* Function Definitions */
/*
 * Arguments    : const creal_T in1[4]
 *                const creal_T in2
 *                const creal_T in3_data[]
 *                const int in3_size[2]
 * Return Type  : creal_T
 */
static creal_T b_binary_expand_op(const creal_T in1[4], const creal_T in2,
                                  const creal_T in3_data[],
                                  const int in3_size[2])
{
  creal_T b_in1[4];
  double ai;
  double ar;
  double b_s;
  double bi;
  double bim;
  double br;
  double brm;
  int stride_0_1;
  stride_0_1 = (in3_size[1] != 1);
  ar = in1[0].re - in2.re;
  ai = in1[0].im - in2.im;
  br = in3_data[0].re;
  bi = in3_data[0].im;
  if (bi == 0.0) {
    if (ai == 0.0) {
      b_in1[0].re = ar / br;
      b_in1[0].im = 0.0;
    } else if (ar == 0.0) {
      b_in1[0].re = 0.0;
      b_in1[0].im = ai / br;
    } else {
      b_in1[0].re = ar / br;
      b_in1[0].im = ai / br;
    }
  } else if (br == 0.0) {
    if (ar == 0.0) {
      b_in1[0].re = ai / bi;
      b_in1[0].im = 0.0;
    } else if (ai == 0.0) {
      b_in1[0].re = 0.0;
      b_in1[0].im = -(ar / bi);
    } else {
      b_in1[0].re = ai / bi;
      b_in1[0].im = -(ar / bi);
    }
  } else {
    brm = fabs(br);
    bim = fabs(bi);
    if (brm > bim) {
      b_s = bi / br;
      bim = br + b_s * bi;
      b_in1[0].re = (ar + b_s * ai) / bim;
      b_in1[0].im = (ai - b_s * ar) / bim;
    } else if (bim == brm) {
      if (br > 0.0) {
        b_s = 0.5;
      } else {
        b_s = -0.5;
      }
      if (bi > 0.0) {
        bim = 0.5;
      } else {
        bim = -0.5;
      }
      b_in1[0].re = (ar * b_s + ai * bim) / brm;
      b_in1[0].im = (ai * b_s - ar * bim) / brm;
    } else {
      b_s = br / bi;
      bim = bi + b_s * br;
      b_in1[0].re = (b_s * ar + ai) / bim;
      b_in1[0].im = (b_s * ai - ar) / bim;
    }
  }
  ar = in1[1].re - in2.re;
  ai = in1[1].im - in2.im;
  br = in3_data[stride_0_1].re;
  bi = in3_data[stride_0_1].im;
  if (bi == 0.0) {
    if (ai == 0.0) {
      b_in1[1].re = ar / br;
      b_in1[1].im = 0.0;
    } else if (ar == 0.0) {
      b_in1[1].re = 0.0;
      b_in1[1].im = ai / br;
    } else {
      b_in1[1].re = ar / br;
      b_in1[1].im = ai / br;
    }
  } else if (br == 0.0) {
    if (ar == 0.0) {
      b_in1[1].re = ai / bi;
      b_in1[1].im = 0.0;
    } else if (ai == 0.0) {
      b_in1[1].re = 0.0;
      b_in1[1].im = -(ar / bi);
    } else {
      b_in1[1].re = ai / bi;
      b_in1[1].im = -(ar / bi);
    }
  } else {
    brm = fabs(br);
    bim = fabs(bi);
    if (brm > bim) {
      b_s = bi / br;
      bim = br + b_s * bi;
      b_in1[1].re = (ar + b_s * ai) / bim;
      b_in1[1].im = (ai - b_s * ar) / bim;
    } else if (bim == brm) {
      if (br > 0.0) {
        b_s = 0.5;
      } else {
        b_s = -0.5;
      }
      if (bi > 0.0) {
        bim = 0.5;
      } else {
        bim = -0.5;
      }
      b_in1[1].re = (ar * b_s + ai * bim) / brm;
      b_in1[1].im = (ai * b_s - ar * bim) / brm;
    } else {
      b_s = br / bi;
      bim = bi + b_s * br;
      b_in1[1].re = (b_s * ar + ai) / bim;
      b_in1[1].im = (b_s * ai - ar) / bim;
    }
  }
  ar = in1[2].re - in2.re;
  ai = in1[2].im - in2.im;
  br = in3_data[stride_0_1 << 1].re;
  bi = in3_data[stride_0_1 << 1].im;
  if (bi == 0.0) {
    if (ai == 0.0) {
      b_in1[2].re = ar / br;
      b_in1[2].im = 0.0;
    } else if (ar == 0.0) {
      b_in1[2].re = 0.0;
      b_in1[2].im = ai / br;
    } else {
      b_in1[2].re = ar / br;
      b_in1[2].im = ai / br;
    }
  } else if (br == 0.0) {
    if (ar == 0.0) {
      b_in1[2].re = ai / bi;
      b_in1[2].im = 0.0;
    } else if (ai == 0.0) {
      b_in1[2].re = 0.0;
      b_in1[2].im = -(ar / bi);
    } else {
      b_in1[2].re = ai / bi;
      b_in1[2].im = -(ar / bi);
    }
  } else {
    brm = fabs(br);
    bim = fabs(bi);
    if (brm > bim) {
      b_s = bi / br;
      bim = br + b_s * bi;
      b_in1[2].re = (ar + b_s * ai) / bim;
      b_in1[2].im = (ai - b_s * ar) / bim;
    } else if (bim == brm) {
      if (br > 0.0) {
        b_s = 0.5;
      } else {
        b_s = -0.5;
      }
      if (bi > 0.0) {
        bim = 0.5;
      } else {
        bim = -0.5;
      }
      b_in1[2].re = (ar * b_s + ai * bim) / brm;
      b_in1[2].im = (ai * b_s - ar * bim) / brm;
    } else {
      b_s = br / bi;
      bim = bi + b_s * br;
      b_in1[2].re = (b_s * ar + ai) / bim;
      b_in1[2].im = (b_s * ai - ar) / bim;
    }
  }
  ar = in1[3].re - in2.re;
  ai = in1[3].im - in2.im;
  br = in3_data[3 * stride_0_1].re;
  bi = in3_data[3 * stride_0_1].im;
  if (bi == 0.0) {
    if (ai == 0.0) {
      b_in1[3].re = ar / br;
      b_in1[3].im = 0.0;
    } else if (ar == 0.0) {
      b_in1[3].re = 0.0;
      b_in1[3].im = ai / br;
    } else {
      b_in1[3].re = ar / br;
      b_in1[3].im = ai / br;
    }
  } else if (br == 0.0) {
    if (ar == 0.0) {
      b_in1[3].re = ai / bi;
      b_in1[3].im = 0.0;
    } else if (ai == 0.0) {
      b_in1[3].re = 0.0;
      b_in1[3].im = -(ar / bi);
    } else {
      b_in1[3].re = ai / bi;
      b_in1[3].im = -(ar / bi);
    }
  } else {
    brm = fabs(br);
    bim = fabs(bi);
    if (brm > bim) {
      b_s = bi / br;
      bim = br + b_s * bi;
      b_in1[3].re = (ar + b_s * ai) / bim;
      b_in1[3].im = (ai - b_s * ar) / bim;
    } else if (bim == brm) {
      if (br > 0.0) {
        b_s = 0.5;
      } else {
        b_s = -0.5;
      }
      if (bi > 0.0) {
        bim = 0.5;
      } else {
        bim = -0.5;
      }
      b_in1[3].re = (ar * b_s + ai * bim) / brm;
      b_in1[3].im = (ai * b_s - ar * bim) / brm;
    } else {
      b_s = br / bi;
      bim = bi + b_s * br;
      b_in1[3].re = (b_s * ar + ai) / bim;
      b_in1[3].im = (b_s * ai - ar) / bim;
    }
  }
  return mean(b_in1);
}

/*
 * Arguments    : emxArray_real_T *in1
 *                const emxArray_real_T *in2
 * Return Type  : void
 */
static void binary_expand_op(emxArray_real_T *in1, const emxArray_real_T *in2)
{
  emxArray_real_T *b_in2;
  const double *in2_data;
  double *b_in2_data;
  double *in1_data;
  int aux_0_1;
  int aux_1_1;
  int i;
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  in2_data = in2->data;
  in1_data = in1->data;
  emxInit_real_T(&b_in2, 2);
  i = b_in2->size[0] * b_in2->size[1];
  b_in2->size[0] = 4;
  if (in1->size[1] == 1) {
    b_in2->size[1] = in2->size[1];
  } else {
    b_in2->size[1] = in1->size[1];
  }
  emxEnsureCapacity_real_T(b_in2, i);
  b_in2_data = b_in2->data;
  stride_0_1 = (in2->size[1] != 1);
  stride_1_1 = (in1->size[1] != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  if (in1->size[1] == 1) {
    loop_ub = in2->size[1];
  } else {
    loop_ub = in1->size[1];
  }
  for (i = 0; i < loop_ub; i++) {
    b_in2_data[4 * i] =
        in2_data[4 * aux_0_1 + 4 * in2->size[1] * 99] - in1_data[4 * aux_1_1];
    b_in2_data[4 * i + 1] =
        in2_data[(4 * aux_0_1 + 4 * in2->size[1] * 99) + 1] -
        in1_data[4 * aux_1_1 + 1];
    b_in2_data[4 * i + 2] =
        in2_data[(4 * aux_0_1 + 4 * in2->size[1] * 99) + 2] -
        in1_data[4 * aux_1_1 + 2];
    b_in2_data[4 * i + 3] =
        in2_data[(4 * aux_0_1 + 4 * in2->size[1] * 99) + 3] -
        in1_data[4 * aux_1_1 + 3];
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  i = in1->size[0] * in1->size[1];
  in1->size[0] = 4;
  in1->size[1] = b_in2->size[1];
  emxEnsureCapacity_real_T(in1, i);
  in1_data = in1->data;
  loop_ub = b_in2->size[1];
  for (i = 0; i < loop_ub; i++) {
    in1_data[4 * i] = b_in2_data[4 * i];
    stride_0_1 = 4 * i + 1;
    in1_data[stride_0_1] = b_in2_data[stride_0_1];
    stride_0_1 = 4 * i + 2;
    in1_data[stride_0_1] = b_in2_data[stride_0_1];
    stride_0_1 = 4 * i + 3;
    in1_data[stride_0_1] = b_in2_data[stride_0_1];
  }
  emxFree_real_T(&b_in2);
}

/*
 * Arguments    : emxArray_real_T *in1
 *                const emxArray_real_T *in2
 *                const emxArray_real_T *in3
 * Return Type  : void
 */
static void c_binary_expand_op(emxArray_real_T *in1, const emxArray_real_T *in2,
                               const emxArray_real_T *in3)
{
  const double *in2_data;
  const double *in3_data;
  double *in1_data;
  int aux_0_1;
  int aux_1_1;
  int i;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_1;
  in3_data = in3->data;
  in2_data = in2->data;
  i = in1->size[0] * in1->size[1];
  in1->size[0] = 4;
  if (in3->size[1] == 1) {
    in1->size[1] = in2->size[1];
  } else {
    in1->size[1] = in3->size[1];
  }
  emxEnsureCapacity_real_T(in1, i);
  in1_data = in1->data;
  stride_0_0 = (in2->size[0] != 1);
  stride_0_1 = (in2->size[1] != 1);
  stride_1_1 = (in3->size[1] != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  if (in3->size[1] == 1) {
    loop_ub = in2->size[1];
  } else {
    loop_ub = in3->size[1];
  }
  for (i = 0; i < loop_ub; i++) {
    in1_data[4 * i] = in2_data[in2->size[0] * aux_0_1] -
                      in3_data[4 * aux_1_1 + 4 * in3->size[1] * 99];
    in1_data[4 * i + 1] = in2_data[stride_0_0 + in2->size[0] * aux_0_1] -
                          in3_data[(4 * aux_1_1 + 4 * in3->size[1] * 99) + 1];
    in1_data[4 * i + 2] = in2_data[(stride_0_0 << 1) + in2->size[0] * aux_0_1] -
                          in3_data[(4 * aux_1_1 + 4 * in3->size[1] * 99) + 2];
    in1_data[4 * i + 3] = in2_data[3 * stride_0_0 + in2->size[0] * aux_0_1] -
                          in3_data[(4 * aux_1_1 + 4 * in3->size[1] * 99) + 3];
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
}

/*
 * Arguments    : emxArray_creal_T *in1
 *                const double in3_data[]
 *                const int in3_size[2]
 *                const double in5_data[]
 *                const int in5_size[2]
 * Return Type  : void
 */
static void e_binary_expand_op(emxArray_creal_T *in1, const double in3_data[],
                               const int in3_size[2], const double in5_data[],
                               const int in5_size[2])
{
  creal_T *in1_data;
  double d;
  int i;
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  in1_data = in1->data;
  stride_0_1 = (in3_size[1] != 1);
  stride_1_1 = (in5_size[1] != 1);
  if (in5_size[1] == 1) {
    loop_ub = in3_size[1];
  } else {
    loop_ub = in5_size[1];
  }
  for (i = 0; i < loop_ub; i++) {
    d = in5_data[i * stride_1_1];
    in1_data[i].re = in3_data[i * stride_0_1] + 0.0 * d;
    in1_data[i].im = d;
  }
}

/*
 * Arguments    : const cell_wrap_4 b_PosUWB2[4]
 *                const double xt_b_data[]
 *                const int xt_b_size[2]
 *                const double yt_b_data[]
 *                const int yt_b_size[2]
 *                const double xain_data[]
 *                const int xain_size[2]
 *                const double yain_data[]
 *                const int yain_size[2]
 *                const emxArray_real_T *b_DistMap
 *                double Ln
 *                creal_T *PosHH
 *                double *HeadingHH
 * Return Type  : void
 */
void UWBMultiTagPos_V3_1(const cell_wrap_4 b_PosUWB2[4],
                         const double xt_b_data[], const int xt_b_size[2],
                         const double yt_b_data[], const int yt_b_size[2],
                         const double xain_data[], const int xain_size[2],
                         const double yain_data[], const int yain_size[2],
                         const emxArray_real_T *b_DistMap, double Ln,
                         creal_T *PosHH, double *HeadingHH)
{
  static creal_T TagCandA[80000];
  static creal_T CenterCands[20000];
  static creal_T HeadingCands[20000];
  static double SortV[20000];
  static unsigned int LessThan1m1[20000];
  emxArray_boolean_T *b_x;
  emxArray_boolean_T *r2;
  emxArray_creal_T *Xain;
  emxArray_creal_T *Xt_b;
  emxArray_creal_T *sortedCenter;
  emxArray_creal_T *sortedHeading;
  emxArray_creal_T *x;
  emxArray_int32_T *b_i;
  emxArray_int32_T *r;
  emxArray_int32_T *r3;
  emxArray_real_T *DistErr;
  emxArray_real_T *TempA;
  emxArray_real_T *TempB;
  emxArray_real_T *r1;
  emxArray_real_T *y;
  creal_T Xt_b_data[65];
  creal_T Temp[4];
  creal_T b_Temp[4];
  creal_T z[2];
  creal_T CenterCandA;
  creal_T HeadingCandA;
  creal_T PrevHeadingCandA;
  creal_T *Xain_data;
  creal_T *sortedCenter_data;
  const double *DistMap_data;
  double PosUWB2_tmp;
  double PrevAbsHeadingCandA;
  double ai;
  double ar;
  double b_PosUWB2_tmp;
  double b_r;
  double b_s;
  double bi;
  double br;
  double brm;
  double *DistErr_data;
  double *TempA_data;
  double *TempB_data;
  int iidx[20000];
  int Xt_b_size[2];
  int i;
  int i1;
  int i2;
  int i3;
  int idx;
  int k;
  int k0;
  int kk;
  int ll;
  int mm;
  int nn;
  int nx;
  int ss;
  int *i_data;
  short size_tmp_idx_1;
  boolean_T b_LessThan1m1[20000];
  boolean_T exitg1;
  boolean_T guard1;
  boolean_T guard2;
  boolean_T guard3;
  boolean_T *x_data;
  DistMap_data = b_DistMap->data;
  if (xt_b_size[1] == yt_b_size[1]) {
    Xt_b_size[0] = 1;
    Xt_b_size[1] = xt_b_size[1];
    idx = xt_b_size[1];
    for (i = 0; i < idx; i++) {
      b_s = yt_b_data[i];
      Xt_b_data[i].re = xt_b_data[i] + 0.0 * b_s;
      Xt_b_data[i].im = b_s;
    }
  } else {
    d_binary_expand_op(Xt_b_data, Xt_b_size, xt_b_data, xt_b_size, yt_b_data,
                       yt_b_size);
  }
  emxInit_creal_T(&Xain);
  i = Xain->size[0] * Xain->size[1];
  Xain->size[0] = 1;
  k0 = (int)Ln;
  Xain->size[1] = (int)Ln;
  emxEnsureCapacity_creal_T(Xain, i);
  Xain_data = Xain->data;
  for (i = 0; i < k0; i++) {
    Xain_data[i].re = 0.0;
    Xain_data[i].im = 0.0;
  }
  if (xain_size[1] == yain_size[1]) {
    idx = xain_size[1];
    for (i = 0; i < idx; i++) {
      b_s = yain_data[i];
      Xain_data[i].re = xain_data[i] + 0.0 * b_s;
      Xain_data[i].im = b_s;
    }
  } else {
    e_binary_expand_op(Xain, xain_data, xain_size, yain_data, yain_size);
    Xain_data = Xain->data;
  }
  memset(&HeadingCands[0], 0, 20000U * sizeof(creal_T));
  memset(&CenterCands[0], 0, 20000U * sizeof(creal_T));
  memset(&TagCandA[0], 0, 80000U * sizeof(creal_T));
  memset(&LessThan1m1[0], 0, 20000U * sizeof(unsigned int));
  ss = 0;
  PrevAbsHeadingCandA = 100.0;
  PosHH->re = 0.0;
  PosHH->im = 0.0;
  PrevHeadingCandA.re = 0.0;
  PrevHeadingCandA.im = 0.0;
  i = b_PosUWB2[0].f1.size[1];
  emxInit_real_T(&DistErr, 2);
  emxInit_real_T(&TempA, 2);
  emxInit_creal_T(&x);
  emxInit_int32_T(&b_i, 1);
  emxInit_boolean_T(&b_x, 1);
  for (kk = 0; kk < i; kk++) {
    Temp[0] = b_PosUWB2[0].f1.data[kk];
    i1 = b_PosUWB2[1].f1.size[1];
    for (ll = 0; ll < i1; ll++) {
      Temp[1] = b_PosUWB2[1].f1.data[ll];
      i2 = b_PosUWB2[2].f1.size[1];
      for (mm = 0; mm < i2; mm++) {
        Temp[2] = b_PosUWB2[2].f1.data[mm];
        i3 = b_PosUWB2[3].f1.size[1];
        for (nn = 0; nn < i3; nn++) {
          Temp[3] = b_PosUWB2[3].f1.data[nn];
          k0 = 0;
          if ((Temp[0].re == 0.0) && (Temp[0].im == 0.0)) {
            k0 = 1;
          }
          if ((Temp[1].re == 0.0) && (Temp[1].im == 0.0)) {
            k0++;
          }
          if ((Temp[2].re == 0.0) && (Temp[2].im == 0.0)) {
            k0++;
          }
          if ((Temp[3].re == 0.0) && (Temp[3].im == 0.0)) {
            k0++;
          }
          if (k0 == 0) {
            CenterCandA = mean(Temp);
            if (Xt_b_size[1] == 4) {
              ar = Temp[0].re - CenterCandA.re;
              ai = Temp[0].im - CenterCandA.im;
              if (Xt_b_data[0].im == 0.0) {
                if (ai == 0.0) {
                  b_Temp[0].re = ar / Xt_b_data[0].re;
                  b_Temp[0].im = 0.0;
                } else if (ar == 0.0) {
                  b_Temp[0].re = 0.0;
                  b_Temp[0].im = ai / Xt_b_data[0].re;
                } else {
                  b_Temp[0].re = ar / Xt_b_data[0].re;
                  b_Temp[0].im = ai / Xt_b_data[0].re;
                }
              } else if (Xt_b_data[0].re == 0.0) {
                if (ar == 0.0) {
                  b_Temp[0].re = ai / Xt_b_data[0].im;
                  b_Temp[0].im = 0.0;
                } else if (ai == 0.0) {
                  b_Temp[0].re = 0.0;
                  b_Temp[0].im = -(ar / Xt_b_data[0].im);
                } else {
                  b_Temp[0].re = ai / Xt_b_data[0].im;
                  b_Temp[0].im = -(ar / Xt_b_data[0].im);
                }
              } else {
                brm = fabs(Xt_b_data[0].re);
                b_r = fabs(Xt_b_data[0].im);
                if (brm > b_r) {
                  b_s = Xt_b_data[0].im / Xt_b_data[0].re;
                  b_r = Xt_b_data[0].re + b_s * Xt_b_data[0].im;
                  b_Temp[0].re = (ar + b_s * ai) / b_r;
                  b_Temp[0].im = (ai - b_s * ar) / b_r;
                } else if (b_r == brm) {
                  if (Xt_b_data[0].re > 0.0) {
                    b_s = 0.5;
                  } else {
                    b_s = -0.5;
                  }
                  if (Xt_b_data[0].im > 0.0) {
                    b_r = 0.5;
                  } else {
                    b_r = -0.5;
                  }
                  b_Temp[0].re = (ar * b_s + ai * b_r) / brm;
                  b_Temp[0].im = (ai * b_s - ar * b_r) / brm;
                } else {
                  b_s = Xt_b_data[0].re / Xt_b_data[0].im;
                  b_r = Xt_b_data[0].im + b_s * Xt_b_data[0].re;
                  b_Temp[0].re = (b_s * ar + ai) / b_r;
                  b_Temp[0].im = (b_s * ai - ar) / b_r;
                }
              }
              ar = Temp[1].re - CenterCandA.re;
              ai = Temp[1].im - CenterCandA.im;
              if (Xt_b_data[1].im == 0.0) {
                if (ai == 0.0) {
                  b_Temp[1].re = ar / Xt_b_data[1].re;
                  b_Temp[1].im = 0.0;
                } else if (ar == 0.0) {
                  b_Temp[1].re = 0.0;
                  b_Temp[1].im = ai / Xt_b_data[1].re;
                } else {
                  b_Temp[1].re = ar / Xt_b_data[1].re;
                  b_Temp[1].im = ai / Xt_b_data[1].re;
                }
              } else if (Xt_b_data[1].re == 0.0) {
                if (ar == 0.0) {
                  b_Temp[1].re = ai / Xt_b_data[1].im;
                  b_Temp[1].im = 0.0;
                } else if (ai == 0.0) {
                  b_Temp[1].re = 0.0;
                  b_Temp[1].im = -(ar / Xt_b_data[1].im);
                } else {
                  b_Temp[1].re = ai / Xt_b_data[1].im;
                  b_Temp[1].im = -(ar / Xt_b_data[1].im);
                }
              } else {
                brm = fabs(Xt_b_data[1].re);
                b_r = fabs(Xt_b_data[1].im);
                if (brm > b_r) {
                  b_s = Xt_b_data[1].im / Xt_b_data[1].re;
                  b_r = Xt_b_data[1].re + b_s * Xt_b_data[1].im;
                  b_Temp[1].re = (ar + b_s * ai) / b_r;
                  b_Temp[1].im = (ai - b_s * ar) / b_r;
                } else if (b_r == brm) {
                  if (Xt_b_data[1].re > 0.0) {
                    b_s = 0.5;
                  } else {
                    b_s = -0.5;
                  }
                  if (Xt_b_data[1].im > 0.0) {
                    b_r = 0.5;
                  } else {
                    b_r = -0.5;
                  }
                  b_Temp[1].re = (ar * b_s + ai * b_r) / brm;
                  b_Temp[1].im = (ai * b_s - ar * b_r) / brm;
                } else {
                  b_s = Xt_b_data[1].re / Xt_b_data[1].im;
                  b_r = Xt_b_data[1].im + b_s * Xt_b_data[1].re;
                  b_Temp[1].re = (b_s * ar + ai) / b_r;
                  b_Temp[1].im = (b_s * ai - ar) / b_r;
                }
              }
              ar = Temp[2].re - CenterCandA.re;
              ai = Temp[2].im - CenterCandA.im;
              if (Xt_b_data[2].im == 0.0) {
                if (ai == 0.0) {
                  b_Temp[2].re = ar / Xt_b_data[2].re;
                  b_Temp[2].im = 0.0;
                } else if (ar == 0.0) {
                  b_Temp[2].re = 0.0;
                  b_Temp[2].im = ai / Xt_b_data[2].re;
                } else {
                  b_Temp[2].re = ar / Xt_b_data[2].re;
                  b_Temp[2].im = ai / Xt_b_data[2].re;
                }
              } else if (Xt_b_data[2].re == 0.0) {
                if (ar == 0.0) {
                  b_Temp[2].re = ai / Xt_b_data[2].im;
                  b_Temp[2].im = 0.0;
                } else if (ai == 0.0) {
                  b_Temp[2].re = 0.0;
                  b_Temp[2].im = -(ar / Xt_b_data[2].im);
                } else {
                  b_Temp[2].re = ai / Xt_b_data[2].im;
                  b_Temp[2].im = -(ar / Xt_b_data[2].im);
                }
              } else {
                brm = fabs(Xt_b_data[2].re);
                b_r = fabs(Xt_b_data[2].im);
                if (brm > b_r) {
                  b_s = Xt_b_data[2].im / Xt_b_data[2].re;
                  b_r = Xt_b_data[2].re + b_s * Xt_b_data[2].im;
                  b_Temp[2].re = (ar + b_s * ai) / b_r;
                  b_Temp[2].im = (ai - b_s * ar) / b_r;
                } else if (b_r == brm) {
                  if (Xt_b_data[2].re > 0.0) {
                    b_s = 0.5;
                  } else {
                    b_s = -0.5;
                  }
                  if (Xt_b_data[2].im > 0.0) {
                    b_r = 0.5;
                  } else {
                    b_r = -0.5;
                  }
                  b_Temp[2].re = (ar * b_s + ai * b_r) / brm;
                  b_Temp[2].im = (ai * b_s - ar * b_r) / brm;
                } else {
                  b_s = Xt_b_data[2].re / Xt_b_data[2].im;
                  b_r = Xt_b_data[2].im + b_s * Xt_b_data[2].re;
                  b_Temp[2].re = (b_s * ar + ai) / b_r;
                  b_Temp[2].im = (b_s * ai - ar) / b_r;
                }
              }
              ar = Temp[3].re - CenterCandA.re;
              ai = Temp[3].im - CenterCandA.im;
              if (Xt_b_data[3].im == 0.0) {
                if (ai == 0.0) {
                  b_Temp[3].re = ar / Xt_b_data[3].re;
                  b_Temp[3].im = 0.0;
                } else if (ar == 0.0) {
                  b_Temp[3].re = 0.0;
                  b_Temp[3].im = ai / Xt_b_data[3].re;
                } else {
                  b_Temp[3].re = ar / Xt_b_data[3].re;
                  b_Temp[3].im = ai / Xt_b_data[3].re;
                }
              } else if (Xt_b_data[3].re == 0.0) {
                if (ar == 0.0) {
                  b_Temp[3].re = ai / Xt_b_data[3].im;
                  b_Temp[3].im = 0.0;
                } else if (ai == 0.0) {
                  b_Temp[3].re = 0.0;
                  b_Temp[3].im = -(ar / Xt_b_data[3].im);
                } else {
                  b_Temp[3].re = ai / Xt_b_data[3].im;
                  b_Temp[3].im = -(ar / Xt_b_data[3].im);
                }
              } else {
                brm = fabs(Xt_b_data[3].re);
                b_r = fabs(Xt_b_data[3].im);
                if (brm > b_r) {
                  b_s = Xt_b_data[3].im / Xt_b_data[3].re;
                  b_r = Xt_b_data[3].re + b_s * Xt_b_data[3].im;
                  b_Temp[3].re = (ar + b_s * ai) / b_r;
                  b_Temp[3].im = (ai - b_s * ar) / b_r;
                } else if (b_r == brm) {
                  if (Xt_b_data[3].re > 0.0) {
                    b_s = 0.5;
                  } else {
                    b_s = -0.5;
                  }
                  if (Xt_b_data[3].im > 0.0) {
                    b_r = 0.5;
                  } else {
                    b_r = -0.5;
                  }
                  b_Temp[3].re = (ar * b_s + ai * b_r) / brm;
                  b_Temp[3].im = (ai * b_s - ar * b_r) / brm;
                } else {
                  b_s = Xt_b_data[3].re / Xt_b_data[3].im;
                  b_r = Xt_b_data[3].im + b_s * Xt_b_data[3].re;
                  b_Temp[3].re = (b_s * ar + ai) / b_r;
                  b_Temp[3].im = (b_s * ai - ar) / b_r;
                }
              }
              HeadingCandA = mean(b_Temp);
            } else {
              HeadingCandA =
                  b_binary_expand_op(Temp, CenterCandA, Xt_b_data, Xt_b_size);
            }
          } else {
            guard1 = false;
            guard2 = false;
            guard3 = false;
            if ((Temp[0].re != 0.0) || (Temp[0].im != 0.0)) {
              PosUWB2_tmp = b_PosUWB2[3].f1.data[nn].re;
              b_PosUWB2_tmp = b_PosUWB2[3].f1.data[nn].im;
              if ((PosUWB2_tmp != 0.0) || (b_PosUWB2_tmp != 0.0)) {
                ar = Temp[0].re + PosUWB2_tmp;
                ai = Temp[0].im + b_PosUWB2_tmp;
                if (ai == 0.0) {
                  CenterCandA.re = ar / 2.0;
                  CenterCandA.im = 0.0;
                } else if (ar == 0.0) {
                  CenterCandA.re = 0.0;
                  CenterCandA.im = ai / 2.0;
                } else {
                  CenterCandA.re = ar / 2.0;
                  CenterCandA.im = ai / 2.0;
                }
                ar = Temp[0].re - CenterCandA.re;
                ai = Temp[0].im - CenterCandA.im;
                if (Xt_b_data[0].im == 0.0) {
                  if (ai == 0.0) {
                    z[0].re = ar / Xt_b_data[0].re;
                    z[0].im = 0.0;
                  } else if (ar == 0.0) {
                    z[0].re = 0.0;
                    z[0].im = ai / Xt_b_data[0].re;
                  } else {
                    z[0].re = ar / Xt_b_data[0].re;
                    z[0].im = ai / Xt_b_data[0].re;
                  }
                } else if (Xt_b_data[0].re == 0.0) {
                  if (ar == 0.0) {
                    z[0].re = ai / Xt_b_data[0].im;
                    z[0].im = 0.0;
                  } else if (ai == 0.0) {
                    z[0].re = 0.0;
                    z[0].im = -(ar / Xt_b_data[0].im);
                  } else {
                    z[0].re = ai / Xt_b_data[0].im;
                    z[0].im = -(ar / Xt_b_data[0].im);
                  }
                } else {
                  brm = fabs(Xt_b_data[0].re);
                  b_r = fabs(Xt_b_data[0].im);
                  if (brm > b_r) {
                    b_s = Xt_b_data[0].im / Xt_b_data[0].re;
                    b_r = Xt_b_data[0].re + b_s * Xt_b_data[0].im;
                    z[0].re = (ar + b_s * ai) / b_r;
                    z[0].im = (ai - b_s * ar) / b_r;
                  } else if (b_r == brm) {
                    if (Xt_b_data[0].re > 0.0) {
                      b_s = 0.5;
                    } else {
                      b_s = -0.5;
                    }
                    if (Xt_b_data[0].im > 0.0) {
                      b_r = 0.5;
                    } else {
                      b_r = -0.5;
                    }
                    z[0].re = (ar * b_s + ai * b_r) / brm;
                    z[0].im = (ai * b_s - ar * b_r) / brm;
                  } else {
                    b_s = Xt_b_data[0].re / Xt_b_data[0].im;
                    b_r = Xt_b_data[0].im + b_s * Xt_b_data[0].re;
                    z[0].re = (b_s * ar + ai) / b_r;
                    z[0].im = (b_s * ai - ar) / b_r;
                  }
                }
                ar = Temp[3].re - CenterCandA.re;
                ai = Temp[3].im - CenterCandA.im;
                if (Xt_b_data[3].im == 0.0) {
                  if (ai == 0.0) {
                    z[1].re = ar / Xt_b_data[3].re;
                    z[1].im = 0.0;
                  } else if (ar == 0.0) {
                    z[1].re = 0.0;
                    z[1].im = ai / Xt_b_data[3].re;
                  } else {
                    z[1].re = ar / Xt_b_data[3].re;
                    z[1].im = ai / Xt_b_data[3].re;
                  }
                } else if (Xt_b_data[3].re == 0.0) {
                  if (ar == 0.0) {
                    z[1].re = ai / Xt_b_data[3].im;
                    z[1].im = 0.0;
                  } else if (ai == 0.0) {
                    z[1].re = 0.0;
                    z[1].im = -(ar / Xt_b_data[3].im);
                  } else {
                    z[1].re = ai / Xt_b_data[3].im;
                    z[1].im = -(ar / Xt_b_data[3].im);
                  }
                } else {
                  brm = fabs(Xt_b_data[3].re);
                  b_r = fabs(Xt_b_data[3].im);
                  if (brm > b_r) {
                    b_s = Xt_b_data[3].im / Xt_b_data[3].re;
                    b_r = Xt_b_data[3].re + b_s * Xt_b_data[3].im;
                    z[1].re = (ar + b_s * ai) / b_r;
                    z[1].im = (ai - b_s * ar) / b_r;
                  } else if (b_r == brm) {
                    if (Xt_b_data[3].re > 0.0) {
                      b_s = 0.5;
                    } else {
                      b_s = -0.5;
                    }
                    if (Xt_b_data[3].im > 0.0) {
                      b_r = 0.5;
                    } else {
                      b_r = -0.5;
                    }
                    z[1].re = (ar * b_s + ai * b_r) / brm;
                    z[1].im = (ai * b_s - ar * b_r) / brm;
                  } else {
                    b_s = Xt_b_data[3].re / Xt_b_data[3].im;
                    b_r = Xt_b_data[3].im + b_s * Xt_b_data[3].re;
                    z[1].re = (b_s * ar + ai) / b_r;
                    z[1].im = (b_s * ai - ar) / b_r;
                  }
                }
                ar = z[0].re + z[1].re;
                ai = z[0].im + z[1].im;
                if (ai == 0.0) {
                  HeadingCandA.re = ar / 2.0;
                  HeadingCandA.im = 0.0;
                } else if (ar == 0.0) {
                  HeadingCandA.re = 0.0;
                  HeadingCandA.im = ai / 2.0;
                } else {
                  HeadingCandA.re = ar / 2.0;
                  HeadingCandA.im = ai / 2.0;
                }
              } else {
                guard3 = true;
              }
            } else {
              guard3 = true;
            }
            if (guard3) {
              if (((Temp[1].re != 0.0) || (Temp[1].im != 0.0)) &&
                  ((Temp[2].re != 0.0) || (Temp[2].im != 0.0))) {
                ar = Temp[1].re + Temp[2].re;
                ai = Temp[1].im + Temp[2].im;
                if (ai == 0.0) {
                  CenterCandA.re = ar / 2.0;
                  CenterCandA.im = 0.0;
                } else if (ar == 0.0) {
                  CenterCandA.re = 0.0;
                  CenterCandA.im = ai / 2.0;
                } else {
                  CenterCandA.re = ar / 2.0;
                  CenterCandA.im = ai / 2.0;
                }
                ar = Temp[1].re - CenterCandA.re;
                ai = Temp[1].im - CenterCandA.im;
                if (Xt_b_data[1].im == 0.0) {
                  if (ai == 0.0) {
                    z[0].re = ar / Xt_b_data[1].re;
                    z[0].im = 0.0;
                  } else if (ar == 0.0) {
                    z[0].re = 0.0;
                    z[0].im = ai / Xt_b_data[1].re;
                  } else {
                    z[0].re = ar / Xt_b_data[1].re;
                    z[0].im = ai / Xt_b_data[1].re;
                  }
                } else if (Xt_b_data[1].re == 0.0) {
                  if (ar == 0.0) {
                    z[0].re = ai / Xt_b_data[1].im;
                    z[0].im = 0.0;
                  } else if (ai == 0.0) {
                    z[0].re = 0.0;
                    z[0].im = -(ar / Xt_b_data[1].im);
                  } else {
                    z[0].re = ai / Xt_b_data[1].im;
                    z[0].im = -(ar / Xt_b_data[1].im);
                  }
                } else {
                  brm = fabs(Xt_b_data[1].re);
                  b_r = fabs(Xt_b_data[1].im);
                  if (brm > b_r) {
                    b_s = Xt_b_data[1].im / Xt_b_data[1].re;
                    b_r = Xt_b_data[1].re + b_s * Xt_b_data[1].im;
                    z[0].re = (ar + b_s * ai) / b_r;
                    z[0].im = (ai - b_s * ar) / b_r;
                  } else if (b_r == brm) {
                    if (Xt_b_data[1].re > 0.0) {
                      b_s = 0.5;
                    } else {
                      b_s = -0.5;
                    }
                    if (Xt_b_data[1].im > 0.0) {
                      b_r = 0.5;
                    } else {
                      b_r = -0.5;
                    }
                    z[0].re = (ar * b_s + ai * b_r) / brm;
                    z[0].im = (ai * b_s - ar * b_r) / brm;
                  } else {
                    b_s = Xt_b_data[1].re / Xt_b_data[1].im;
                    b_r = Xt_b_data[1].im + b_s * Xt_b_data[1].re;
                    z[0].re = (b_s * ar + ai) / b_r;
                    z[0].im = (b_s * ai - ar) / b_r;
                  }
                }
                ar = Temp[2].re - CenterCandA.re;
                ai = Temp[2].im - CenterCandA.im;
                if (Xt_b_data[2].im == 0.0) {
                  if (ai == 0.0) {
                    z[1].re = ar / Xt_b_data[2].re;
                    z[1].im = 0.0;
                  } else if (ar == 0.0) {
                    z[1].re = 0.0;
                    z[1].im = ai / Xt_b_data[2].re;
                  } else {
                    z[1].re = ar / Xt_b_data[2].re;
                    z[1].im = ai / Xt_b_data[2].re;
                  }
                } else if (Xt_b_data[2].re == 0.0) {
                  if (ar == 0.0) {
                    z[1].re = ai / Xt_b_data[2].im;
                    z[1].im = 0.0;
                  } else if (ai == 0.0) {
                    z[1].re = 0.0;
                    z[1].im = -(ar / Xt_b_data[2].im);
                  } else {
                    z[1].re = ai / Xt_b_data[2].im;
                    z[1].im = -(ar / Xt_b_data[2].im);
                  }
                } else {
                  brm = fabs(Xt_b_data[2].re);
                  b_r = fabs(Xt_b_data[2].im);
                  if (brm > b_r) {
                    b_s = Xt_b_data[2].im / Xt_b_data[2].re;
                    b_r = Xt_b_data[2].re + b_s * Xt_b_data[2].im;
                    z[1].re = (ar + b_s * ai) / b_r;
                    z[1].im = (ai - b_s * ar) / b_r;
                  } else if (b_r == brm) {
                    if (Xt_b_data[2].re > 0.0) {
                      b_s = 0.5;
                    } else {
                      b_s = -0.5;
                    }
                    if (Xt_b_data[2].im > 0.0) {
                      b_r = 0.5;
                    } else {
                      b_r = -0.5;
                    }
                    z[1].re = (ar * b_s + ai * b_r) / brm;
                    z[1].im = (ai * b_s - ar * b_r) / brm;
                  } else {
                    b_s = Xt_b_data[2].re / Xt_b_data[2].im;
                    b_r = Xt_b_data[2].im + b_s * Xt_b_data[2].re;
                    z[1].re = (b_s * ar + ai) / b_r;
                    z[1].im = (b_s * ai - ar) / b_r;
                  }
                }
                ar = z[0].re + z[1].re;
                ai = z[0].im + z[1].im;
                if (ai == 0.0) {
                  HeadingCandA.re = ar / 2.0;
                  HeadingCandA.im = 0.0;
                } else if (ar == 0.0) {
                  HeadingCandA.re = 0.0;
                  HeadingCandA.im = ai / 2.0;
                } else {
                  HeadingCandA.re = ar / 2.0;
                  HeadingCandA.im = ai / 2.0;
                }
              } else if (((Temp[0].re != 0.0) || (Temp[0].im != 0.0)) &&
                         ((Temp[1].re != 0.0) || (Temp[1].im != 0.0))) {
                ar = Temp[0].re - Temp[1].re;
                ai = Temp[0].im - Temp[1].im;
                br = Xt_b_data[0].re - Xt_b_data[1].re;
                bi = Xt_b_data[0].im - Xt_b_data[1].im;
                if (bi == 0.0) {
                  if (ai == 0.0) {
                    HeadingCandA.re = ar / br;
                    HeadingCandA.im = 0.0;
                  } else if (ar == 0.0) {
                    HeadingCandA.re = 0.0;
                    HeadingCandA.im = ai / br;
                  } else {
                    HeadingCandA.re = ar / br;
                    HeadingCandA.im = ai / br;
                  }
                } else if (br == 0.0) {
                  if (ar == 0.0) {
                    HeadingCandA.re = ai / bi;
                    HeadingCandA.im = 0.0;
                  } else if (ai == 0.0) {
                    HeadingCandA.re = 0.0;
                    HeadingCandA.im = -(ar / bi);
                  } else {
                    HeadingCandA.re = ai / bi;
                    HeadingCandA.im = -(ar / bi);
                  }
                } else {
                  brm = fabs(br);
                  b_r = fabs(bi);
                  if (brm > b_r) {
                    b_s = bi / br;
                    b_r = br + b_s * bi;
                    HeadingCandA.re = (ar + b_s * ai) / b_r;
                    HeadingCandA.im = (ai - b_s * ar) / b_r;
                  } else if (b_r == brm) {
                    if (br > 0.0) {
                      b_s = 0.5;
                    } else {
                      b_s = -0.5;
                    }
                    if (bi > 0.0) {
                      b_r = 0.5;
                    } else {
                      b_r = -0.5;
                    }
                    HeadingCandA.re = (ar * b_s + ai * b_r) / brm;
                    HeadingCandA.im = (ai * b_s - ar * b_r) / brm;
                  } else {
                    b_s = br / bi;
                    b_r = bi + b_s * br;
                    HeadingCandA.re = (b_s * ar + ai) / b_r;
                    HeadingCandA.im = (b_s * ai - ar) / b_r;
                  }
                }
                ar = Temp[0].re + Temp[1].re;
                ai = Temp[0].im + Temp[1].im;
                if (ai == 0.0) {
                  brm = ar / 2.0;
                  bi = 0.0;
                } else if (ar == 0.0) {
                  brm = 0.0;
                  bi = ai / 2.0;
                } else {
                  brm = ar / 2.0;
                  bi = ai / 2.0;
                }
                ar = Xt_b_data[0].re + Xt_b_data[1].re;
                ai = Xt_b_data[0].im + Xt_b_data[1].im;
                if (ai == 0.0) {
                  PosUWB2_tmp = ar / 2.0;
                  b_s = 0.0;
                } else if (ar == 0.0) {
                  PosUWB2_tmp = 0.0;
                  b_s = ai / 2.0;
                } else {
                  PosUWB2_tmp = ar / 2.0;
                  b_s = ai / 2.0;
                }
                b_r = PosUWB2_tmp * HeadingCandA.re - b_s * HeadingCandA.im;
                b_s = PosUWB2_tmp * HeadingCandA.im + b_s * HeadingCandA.re;
                br = rt_hypotd_snf(HeadingCandA.re, HeadingCandA.im);
                if (b_s == 0.0) {
                  PosUWB2_tmp = b_r / br;
                  b_s = 0.0;
                } else if (b_r == 0.0) {
                  PosUWB2_tmp = 0.0;
                  b_s /= br;
                } else {
                  PosUWB2_tmp = b_r / br;
                  b_s /= br;
                }
                CenterCandA.re = brm - PosUWB2_tmp;
                CenterCandA.im = bi - b_s;
              } else if ((Temp[1].re != 0.0) || (Temp[1].im != 0.0)) {
                PosUWB2_tmp = b_PosUWB2[3].f1.data[nn].re;
                b_PosUWB2_tmp = b_PosUWB2[3].f1.data[nn].im;
                if ((PosUWB2_tmp != 0.0) || (b_PosUWB2_tmp != 0.0)) {
                  ar = Temp[1].re - PosUWB2_tmp;
                  ai = Temp[1].im - b_PosUWB2_tmp;
                  br = Xt_b_data[1].re - Xt_b_data[3].re;
                  bi = Xt_b_data[1].im - Xt_b_data[3].im;
                  if (bi == 0.0) {
                    if (ai == 0.0) {
                      HeadingCandA.re = ar / br;
                      HeadingCandA.im = 0.0;
                    } else if (ar == 0.0) {
                      HeadingCandA.re = 0.0;
                      HeadingCandA.im = ai / br;
                    } else {
                      HeadingCandA.re = ar / br;
                      HeadingCandA.im = ai / br;
                    }
                  } else if (br == 0.0) {
                    if (ar == 0.0) {
                      HeadingCandA.re = ai / bi;
                      HeadingCandA.im = 0.0;
                    } else if (ai == 0.0) {
                      HeadingCandA.re = 0.0;
                      HeadingCandA.im = -(ar / bi);
                    } else {
                      HeadingCandA.re = ai / bi;
                      HeadingCandA.im = -(ar / bi);
                    }
                  } else {
                    brm = fabs(br);
                    b_r = fabs(bi);
                    if (brm > b_r) {
                      b_s = bi / br;
                      b_r = br + b_s * bi;
                      HeadingCandA.re = (ar + b_s * ai) / b_r;
                      HeadingCandA.im = (ai - b_s * ar) / b_r;
                    } else if (b_r == brm) {
                      if (br > 0.0) {
                        b_s = 0.5;
                      } else {
                        b_s = -0.5;
                      }
                      if (bi > 0.0) {
                        b_r = 0.5;
                      } else {
                        b_r = -0.5;
                      }
                      HeadingCandA.re = (ar * b_s + ai * b_r) / brm;
                      HeadingCandA.im = (ai * b_s - ar * b_r) / brm;
                    } else {
                      b_s = br / bi;
                      b_r = bi + b_s * br;
                      HeadingCandA.re = (b_s * ar + ai) / b_r;
                      HeadingCandA.im = (b_s * ai - ar) / b_r;
                    }
                  }
                  ar = Temp[1].re + PosUWB2_tmp;
                  ai = Temp[1].im + b_PosUWB2_tmp;
                  if (ai == 0.0) {
                    brm = ar / 2.0;
                    bi = 0.0;
                  } else if (ar == 0.0) {
                    brm = 0.0;
                    bi = ai / 2.0;
                  } else {
                    brm = ar / 2.0;
                    bi = ai / 2.0;
                  }
                  ar = Xt_b_data[1].re + Xt_b_data[3].re;
                  ai = Xt_b_data[1].im + Xt_b_data[3].im;
                  if (ai == 0.0) {
                    PosUWB2_tmp = ar / 2.0;
                    b_s = 0.0;
                  } else if (ar == 0.0) {
                    PosUWB2_tmp = 0.0;
                    b_s = ai / 2.0;
                  } else {
                    PosUWB2_tmp = ar / 2.0;
                    b_s = ai / 2.0;
                  }
                  b_r = PosUWB2_tmp * HeadingCandA.re - b_s * HeadingCandA.im;
                  b_s = PosUWB2_tmp * HeadingCandA.im + b_s * HeadingCandA.re;
                  br = rt_hypotd_snf(HeadingCandA.re, HeadingCandA.im);
                  if (b_s == 0.0) {
                    PosUWB2_tmp = b_r / br;
                    b_s = 0.0;
                  } else if (b_r == 0.0) {
                    PosUWB2_tmp = 0.0;
                    b_s /= br;
                  } else {
                    PosUWB2_tmp = b_r / br;
                    b_s /= br;
                  }
                  CenterCandA.re = brm - PosUWB2_tmp;
                  CenterCandA.im = bi - b_s;
                } else {
                  guard2 = true;
                }
              } else {
                guard2 = true;
              }
            }
            if (guard2) {
              if ((Temp[2].re != 0.0) || (Temp[2].im != 0.0)) {
                PosUWB2_tmp = b_PosUWB2[3].f1.data[nn].re;
                b_PosUWB2_tmp = b_PosUWB2[3].f1.data[nn].im;
                if ((PosUWB2_tmp != 0.0) || (b_PosUWB2_tmp != 0.0)) {
                  ar = Temp[2].re - PosUWB2_tmp;
                  ai = Temp[2].im - b_PosUWB2_tmp;
                  br = Xt_b_data[2].re - Xt_b_data[3].re;
                  bi = Xt_b_data[2].im - Xt_b_data[3].im;
                  if (bi == 0.0) {
                    if (ai == 0.0) {
                      HeadingCandA.re = ar / br;
                      HeadingCandA.im = 0.0;
                    } else if (ar == 0.0) {
                      HeadingCandA.re = 0.0;
                      HeadingCandA.im = ai / br;
                    } else {
                      HeadingCandA.re = ar / br;
                      HeadingCandA.im = ai / br;
                    }
                  } else if (br == 0.0) {
                    if (ar == 0.0) {
                      HeadingCandA.re = ai / bi;
                      HeadingCandA.im = 0.0;
                    } else if (ai == 0.0) {
                      HeadingCandA.re = 0.0;
                      HeadingCandA.im = -(ar / bi);
                    } else {
                      HeadingCandA.re = ai / bi;
                      HeadingCandA.im = -(ar / bi);
                    }
                  } else {
                    brm = fabs(br);
                    b_r = fabs(bi);
                    if (brm > b_r) {
                      b_s = bi / br;
                      b_r = br + b_s * bi;
                      HeadingCandA.re = (ar + b_s * ai) / b_r;
                      HeadingCandA.im = (ai - b_s * ar) / b_r;
                    } else if (b_r == brm) {
                      if (br > 0.0) {
                        b_s = 0.5;
                      } else {
                        b_s = -0.5;
                      }
                      if (bi > 0.0) {
                        b_r = 0.5;
                      } else {
                        b_r = -0.5;
                      }
                      HeadingCandA.re = (ar * b_s + ai * b_r) / brm;
                      HeadingCandA.im = (ai * b_s - ar * b_r) / brm;
                    } else {
                      b_s = br / bi;
                      b_r = bi + b_s * br;
                      HeadingCandA.re = (b_s * ar + ai) / b_r;
                      HeadingCandA.im = (b_s * ai - ar) / b_r;
                    }
                  }
                  ar = Temp[2].re + PosUWB2_tmp;
                  ai = Temp[2].im + b_PosUWB2_tmp;
                  if (ai == 0.0) {
                    brm = ar / 2.0;
                    bi = 0.0;
                  } else if (ar == 0.0) {
                    brm = 0.0;
                    bi = ai / 2.0;
                  } else {
                    brm = ar / 2.0;
                    bi = ai / 2.0;
                  }
                  ar = Xt_b_data[2].re + Xt_b_data[3].re;
                  ai = Xt_b_data[2].im + Xt_b_data[3].im;
                  if (ai == 0.0) {
                    PosUWB2_tmp = ar / 2.0;
                    b_s = 0.0;
                  } else if (ar == 0.0) {
                    PosUWB2_tmp = 0.0;
                    b_s = ai / 2.0;
                  } else {
                    PosUWB2_tmp = ar / 2.0;
                    b_s = ai / 2.0;
                  }
                  b_r = PosUWB2_tmp * HeadingCandA.re - b_s * HeadingCandA.im;
                  b_s = PosUWB2_tmp * HeadingCandA.im + b_s * HeadingCandA.re;
                  br = rt_hypotd_snf(HeadingCandA.re, HeadingCandA.im);
                  if (b_s == 0.0) {
                    PosUWB2_tmp = b_r / br;
                    b_s = 0.0;
                  } else if (b_r == 0.0) {
                    PosUWB2_tmp = 0.0;
                    b_s /= br;
                  } else {
                    PosUWB2_tmp = b_r / br;
                    b_s /= br;
                  }
                  CenterCandA.re = brm - PosUWB2_tmp;
                  CenterCandA.im = bi - b_s;
                } else {
                  guard1 = true;
                }
              } else {
                guard1 = true;
              }
            }
            if (guard1) {
              if (((Temp[2].re != 0.0) || (Temp[2].im != 0.0)) &&
                  ((Temp[0].re != 0.0) || (Temp[0].im != 0.0))) {
                ar = Temp[2].re - Temp[0].re;
                ai = Temp[2].im - Temp[0].im;
                br = Xt_b_data[2].re - Xt_b_data[0].re;
                bi = Xt_b_data[2].im - Xt_b_data[0].im;
                if (bi == 0.0) {
                  if (ai == 0.0) {
                    HeadingCandA.re = ar / br;
                    HeadingCandA.im = 0.0;
                  } else if (ar == 0.0) {
                    HeadingCandA.re = 0.0;
                    HeadingCandA.im = ai / br;
                  } else {
                    HeadingCandA.re = ar / br;
                    HeadingCandA.im = ai / br;
                  }
                } else if (br == 0.0) {
                  if (ar == 0.0) {
                    HeadingCandA.re = ai / bi;
                    HeadingCandA.im = 0.0;
                  } else if (ai == 0.0) {
                    HeadingCandA.re = 0.0;
                    HeadingCandA.im = -(ar / bi);
                  } else {
                    HeadingCandA.re = ai / bi;
                    HeadingCandA.im = -(ar / bi);
                  }
                } else {
                  brm = fabs(br);
                  b_r = fabs(bi);
                  if (brm > b_r) {
                    b_s = bi / br;
                    b_r = br + b_s * bi;
                    HeadingCandA.re = (ar + b_s * ai) / b_r;
                    HeadingCandA.im = (ai - b_s * ar) / b_r;
                  } else if (b_r == brm) {
                    if (br > 0.0) {
                      b_s = 0.5;
                    } else {
                      b_s = -0.5;
                    }
                    if (bi > 0.0) {
                      b_r = 0.5;
                    } else {
                      b_r = -0.5;
                    }
                    HeadingCandA.re = (ar * b_s + ai * b_r) / brm;
                    HeadingCandA.im = (ai * b_s - ar * b_r) / brm;
                  } else {
                    b_s = br / bi;
                    b_r = bi + b_s * br;
                    HeadingCandA.re = (b_s * ar + ai) / b_r;
                    HeadingCandA.im = (b_s * ai - ar) / b_r;
                  }
                }
                ar = Temp[0].re + Temp[2].re;
                ai = Temp[0].im + Temp[2].im;
                if (ai == 0.0) {
                  brm = ar / 2.0;
                  bi = 0.0;
                } else if (ar == 0.0) {
                  brm = 0.0;
                  bi = ai / 2.0;
                } else {
                  brm = ar / 2.0;
                  bi = ai / 2.0;
                }
                ar = Xt_b_data[0].re + Xt_b_data[2].re;
                ai = Xt_b_data[0].im + Xt_b_data[2].im;
                if (ai == 0.0) {
                  PosUWB2_tmp = ar / 2.0;
                  b_s = 0.0;
                } else if (ar == 0.0) {
                  PosUWB2_tmp = 0.0;
                  b_s = ai / 2.0;
                } else {
                  PosUWB2_tmp = ar / 2.0;
                  b_s = ai / 2.0;
                }
                b_r = PosUWB2_tmp * HeadingCandA.re - b_s * HeadingCandA.im;
                b_s = PosUWB2_tmp * HeadingCandA.im + b_s * HeadingCandA.re;
                br = rt_hypotd_snf(HeadingCandA.re, HeadingCandA.im);
                if (b_s == 0.0) {
                  PosUWB2_tmp = b_r / br;
                  b_s = 0.0;
                } else if (b_r == 0.0) {
                  PosUWB2_tmp = 0.0;
                  b_s /= br;
                } else {
                  PosUWB2_tmp = b_r / br;
                  b_s /= br;
                }
                CenterCandA.re = brm - PosUWB2_tmp;
                CenterCandA.im = bi - b_s;
              } else {
                CenterCandA = mean(Temp);
                if (Xt_b_size[1] == 4) {
                  ar = Temp[0].re - CenterCandA.re;
                  ai = Temp[0].im - CenterCandA.im;
                  if (Xt_b_data[0].im == 0.0) {
                    if (ai == 0.0) {
                      b_Temp[0].re = ar / Xt_b_data[0].re;
                      b_Temp[0].im = 0.0;
                    } else if (ar == 0.0) {
                      b_Temp[0].re = 0.0;
                      b_Temp[0].im = ai / Xt_b_data[0].re;
                    } else {
                      b_Temp[0].re = ar / Xt_b_data[0].re;
                      b_Temp[0].im = ai / Xt_b_data[0].re;
                    }
                  } else if (Xt_b_data[0].re == 0.0) {
                    if (ar == 0.0) {
                      b_Temp[0].re = ai / Xt_b_data[0].im;
                      b_Temp[0].im = 0.0;
                    } else if (ai == 0.0) {
                      b_Temp[0].re = 0.0;
                      b_Temp[0].im = -(ar / Xt_b_data[0].im);
                    } else {
                      b_Temp[0].re = ai / Xt_b_data[0].im;
                      b_Temp[0].im = -(ar / Xt_b_data[0].im);
                    }
                  } else {
                    brm = fabs(Xt_b_data[0].re);
                    b_r = fabs(Xt_b_data[0].im);
                    if (brm > b_r) {
                      b_s = Xt_b_data[0].im / Xt_b_data[0].re;
                      b_r = Xt_b_data[0].re + b_s * Xt_b_data[0].im;
                      b_Temp[0].re = (ar + b_s * ai) / b_r;
                      b_Temp[0].im = (ai - b_s * ar) / b_r;
                    } else if (b_r == brm) {
                      if (Xt_b_data[0].re > 0.0) {
                        b_s = 0.5;
                      } else {
                        b_s = -0.5;
                      }
                      if (Xt_b_data[0].im > 0.0) {
                        b_r = 0.5;
                      } else {
                        b_r = -0.5;
                      }
                      b_Temp[0].re = (ar * b_s + ai * b_r) / brm;
                      b_Temp[0].im = (ai * b_s - ar * b_r) / brm;
                    } else {
                      b_s = Xt_b_data[0].re / Xt_b_data[0].im;
                      b_r = Xt_b_data[0].im + b_s * Xt_b_data[0].re;
                      b_Temp[0].re = (b_s * ar + ai) / b_r;
                      b_Temp[0].im = (b_s * ai - ar) / b_r;
                    }
                  }
                  ar = Temp[1].re - CenterCandA.re;
                  ai = Temp[1].im - CenterCandA.im;
                  if (Xt_b_data[1].im == 0.0) {
                    if (ai == 0.0) {
                      b_Temp[1].re = ar / Xt_b_data[1].re;
                      b_Temp[1].im = 0.0;
                    } else if (ar == 0.0) {
                      b_Temp[1].re = 0.0;
                      b_Temp[1].im = ai / Xt_b_data[1].re;
                    } else {
                      b_Temp[1].re = ar / Xt_b_data[1].re;
                      b_Temp[1].im = ai / Xt_b_data[1].re;
                    }
                  } else if (Xt_b_data[1].re == 0.0) {
                    if (ar == 0.0) {
                      b_Temp[1].re = ai / Xt_b_data[1].im;
                      b_Temp[1].im = 0.0;
                    } else if (ai == 0.0) {
                      b_Temp[1].re = 0.0;
                      b_Temp[1].im = -(ar / Xt_b_data[1].im);
                    } else {
                      b_Temp[1].re = ai / Xt_b_data[1].im;
                      b_Temp[1].im = -(ar / Xt_b_data[1].im);
                    }
                  } else {
                    brm = fabs(Xt_b_data[1].re);
                    b_r = fabs(Xt_b_data[1].im);
                    if (brm > b_r) {
                      b_s = Xt_b_data[1].im / Xt_b_data[1].re;
                      b_r = Xt_b_data[1].re + b_s * Xt_b_data[1].im;
                      b_Temp[1].re = (ar + b_s * ai) / b_r;
                      b_Temp[1].im = (ai - b_s * ar) / b_r;
                    } else if (b_r == brm) {
                      if (Xt_b_data[1].re > 0.0) {
                        b_s = 0.5;
                      } else {
                        b_s = -0.5;
                      }
                      if (Xt_b_data[1].im > 0.0) {
                        b_r = 0.5;
                      } else {
                        b_r = -0.5;
                      }
                      b_Temp[1].re = (ar * b_s + ai * b_r) / brm;
                      b_Temp[1].im = (ai * b_s - ar * b_r) / brm;
                    } else {
                      b_s = Xt_b_data[1].re / Xt_b_data[1].im;
                      b_r = Xt_b_data[1].im + b_s * Xt_b_data[1].re;
                      b_Temp[1].re = (b_s * ar + ai) / b_r;
                      b_Temp[1].im = (b_s * ai - ar) / b_r;
                    }
                  }
                  ar = Temp[2].re - CenterCandA.re;
                  ai = Temp[2].im - CenterCandA.im;
                  if (Xt_b_data[2].im == 0.0) {
                    if (ai == 0.0) {
                      b_Temp[2].re = ar / Xt_b_data[2].re;
                      b_Temp[2].im = 0.0;
                    } else if (ar == 0.0) {
                      b_Temp[2].re = 0.0;
                      b_Temp[2].im = ai / Xt_b_data[2].re;
                    } else {
                      b_Temp[2].re = ar / Xt_b_data[2].re;
                      b_Temp[2].im = ai / Xt_b_data[2].re;
                    }
                  } else if (Xt_b_data[2].re == 0.0) {
                    if (ar == 0.0) {
                      b_Temp[2].re = ai / Xt_b_data[2].im;
                      b_Temp[2].im = 0.0;
                    } else if (ai == 0.0) {
                      b_Temp[2].re = 0.0;
                      b_Temp[2].im = -(ar / Xt_b_data[2].im);
                    } else {
                      b_Temp[2].re = ai / Xt_b_data[2].im;
                      b_Temp[2].im = -(ar / Xt_b_data[2].im);
                    }
                  } else {
                    brm = fabs(Xt_b_data[2].re);
                    b_r = fabs(Xt_b_data[2].im);
                    if (brm > b_r) {
                      b_s = Xt_b_data[2].im / Xt_b_data[2].re;
                      b_r = Xt_b_data[2].re + b_s * Xt_b_data[2].im;
                      b_Temp[2].re = (ar + b_s * ai) / b_r;
                      b_Temp[2].im = (ai - b_s * ar) / b_r;
                    } else if (b_r == brm) {
                      if (Xt_b_data[2].re > 0.0) {
                        b_s = 0.5;
                      } else {
                        b_s = -0.5;
                      }
                      if (Xt_b_data[2].im > 0.0) {
                        b_r = 0.5;
                      } else {
                        b_r = -0.5;
                      }
                      b_Temp[2].re = (ar * b_s + ai * b_r) / brm;
                      b_Temp[2].im = (ai * b_s - ar * b_r) / brm;
                    } else {
                      b_s = Xt_b_data[2].re / Xt_b_data[2].im;
                      b_r = Xt_b_data[2].im + b_s * Xt_b_data[2].re;
                      b_Temp[2].re = (b_s * ar + ai) / b_r;
                      b_Temp[2].im = (b_s * ai - ar) / b_r;
                    }
                  }
                  ar = Temp[3].re - CenterCandA.re;
                  ai = Temp[3].im - CenterCandA.im;
                  if (Xt_b_data[3].im == 0.0) {
                    if (ai == 0.0) {
                      b_Temp[3].re = ar / Xt_b_data[3].re;
                      b_Temp[3].im = 0.0;
                    } else if (ar == 0.0) {
                      b_Temp[3].re = 0.0;
                      b_Temp[3].im = ai / Xt_b_data[3].re;
                    } else {
                      b_Temp[3].re = ar / Xt_b_data[3].re;
                      b_Temp[3].im = ai / Xt_b_data[3].re;
                    }
                  } else if (Xt_b_data[3].re == 0.0) {
                    if (ar == 0.0) {
                      b_Temp[3].re = ai / Xt_b_data[3].im;
                      b_Temp[3].im = 0.0;
                    } else if (ai == 0.0) {
                      b_Temp[3].re = 0.0;
                      b_Temp[3].im = -(ar / Xt_b_data[3].im);
                    } else {
                      b_Temp[3].re = ai / Xt_b_data[3].im;
                      b_Temp[3].im = -(ar / Xt_b_data[3].im);
                    }
                  } else {
                    brm = fabs(Xt_b_data[3].re);
                    b_r = fabs(Xt_b_data[3].im);
                    if (brm > b_r) {
                      b_s = Xt_b_data[3].im / Xt_b_data[3].re;
                      b_r = Xt_b_data[3].re + b_s * Xt_b_data[3].im;
                      b_Temp[3].re = (ar + b_s * ai) / b_r;
                      b_Temp[3].im = (ai - b_s * ar) / b_r;
                    } else if (b_r == brm) {
                      if (Xt_b_data[3].re > 0.0) {
                        b_s = 0.5;
                      } else {
                        b_s = -0.5;
                      }
                      if (Xt_b_data[3].im > 0.0) {
                        b_r = 0.5;
                      } else {
                        b_r = -0.5;
                      }
                      b_Temp[3].re = (ar * b_s + ai * b_r) / brm;
                      b_Temp[3].im = (ai * b_s - ar * b_r) / brm;
                    } else {
                      b_s = Xt_b_data[3].re / Xt_b_data[3].im;
                      b_r = Xt_b_data[3].im + b_s * Xt_b_data[3].re;
                      b_Temp[3].re = (b_s * ar + ai) / b_r;
                      b_Temp[3].im = (b_s * ai - ar) / b_r;
                    }
                  }
                  HeadingCandA = mean(b_Temp);
                } else {
                  HeadingCandA = b_binary_expand_op(Temp, CenterCandA,
                                                    Xt_b_data, Xt_b_size);
                }
              }
            }
          }
          b_r = rt_hypotd_snf(HeadingCandA.re, HeadingCandA.im);
          b_s = fabs(b_r - 1.0);
          if (b_s <= 1.0) {
            PosUWB2_tmp = Xt_b_data[0].re * HeadingCandA.re -
                          Xt_b_data[0].im * HeadingCandA.im;
            b_s = Xt_b_data[0].re * HeadingCandA.im +
                  Xt_b_data[0].im * HeadingCandA.re;
            if (b_s == 0.0) {
              PosUWB2_tmp /= b_r;
              b_s = 0.0;
            } else if (PosUWB2_tmp == 0.0) {
              PosUWB2_tmp = 0.0;
              b_s /= b_r;
            } else {
              PosUWB2_tmp /= b_r;
              b_s /= b_r;
            }
            TagCandA[ss].re = CenterCandA.re + PosUWB2_tmp;
            TagCandA[ss].im = CenterCandA.im + b_s;
            PosUWB2_tmp = Xt_b_data[1].re * HeadingCandA.re -
                          Xt_b_data[1].im * HeadingCandA.im;
            b_s = Xt_b_data[1].re * HeadingCandA.im +
                  Xt_b_data[1].im * HeadingCandA.re;
            if (b_s == 0.0) {
              PosUWB2_tmp /= b_r;
              b_s = 0.0;
            } else if (PosUWB2_tmp == 0.0) {
              PosUWB2_tmp = 0.0;
              b_s /= b_r;
            } else {
              PosUWB2_tmp /= b_r;
              b_s /= b_r;
            }
            TagCandA[ss + 20000].re = CenterCandA.re + PosUWB2_tmp;
            TagCandA[ss + 20000].im = CenterCandA.im + b_s;
            PosUWB2_tmp = Xt_b_data[2].re * HeadingCandA.re -
                          Xt_b_data[2].im * HeadingCandA.im;
            b_s = Xt_b_data[2].re * HeadingCandA.im +
                  Xt_b_data[2].im * HeadingCandA.re;
            if (b_s == 0.0) {
              PosUWB2_tmp /= b_r;
              b_s = 0.0;
            } else if (PosUWB2_tmp == 0.0) {
              PosUWB2_tmp = 0.0;
              b_s /= b_r;
            } else {
              PosUWB2_tmp /= b_r;
              b_s /= b_r;
            }
            TagCandA[ss + 40000].re = CenterCandA.re + PosUWB2_tmp;
            TagCandA[ss + 40000].im = CenterCandA.im + b_s;
            PosUWB2_tmp = Xt_b_data[3].re * HeadingCandA.re -
                          Xt_b_data[3].im * HeadingCandA.im;
            b_s = Xt_b_data[3].re * HeadingCandA.im +
                  Xt_b_data[3].im * HeadingCandA.re;
            if (b_s == 0.0) {
              PosUWB2_tmp /= b_r;
              b_s = 0.0;
            } else if (PosUWB2_tmp == 0.0) {
              PosUWB2_tmp = 0.0;
              b_s /= b_r;
            } else {
              PosUWB2_tmp /= b_r;
              b_s /= b_r;
            }
            TagCandA[ss + 60000].re = CenterCandA.re + PosUWB2_tmp;
            TagCandA[ss + 60000].im = CenterCandA.im + b_s;
            k = x->size[0] * x->size[1];
            x->size[0] = 4;
            idx = Xain->size[1];
            x->size[1] = Xain->size[1];
            emxEnsureCapacity_creal_T(x, k);
            sortedCenter_data = x->data;
            for (k = 0; k < idx; k++) {
              b_s = Xain_data[k].re;
              sortedCenter_data[4 * k].re = TagCandA[ss].re - b_s;
              b_r = Xain_data[k].im;
              sortedCenter_data[4 * k].im = TagCandA[ss].im - b_r;
              k0 = 4 * k + 1;
              sortedCenter_data[k0].re = TagCandA[ss + 20000].re - b_s;
              sortedCenter_data[k0].im = TagCandA[ss + 20000].im - b_r;
              k0 = 4 * k + 2;
              sortedCenter_data[k0].re = TagCandA[ss + 40000].re - b_s;
              sortedCenter_data[k0].im = TagCandA[ss + 40000].im - b_r;
              k0 = 4 * k + 3;
              sortedCenter_data[k0].re = TagCandA[ss + 60000].re - b_s;
              sortedCenter_data[k0].im = TagCandA[ss + 60000].im - b_r;
            }
            nx = x->size[1] << 2;
            k = TempA->size[0] * TempA->size[1];
            TempA->size[0] = 4;
            TempA->size[1] = x->size[1];
            emxEnsureCapacity_real_T(TempA, k);
            TempA_data = TempA->data;
            for (k = 0; k < nx; k++) {
              TempA_data[k] = rt_hypotd_snf(sortedCenter_data[k].re,
                                            sortedCenter_data[k].im);
            }
            idx = b_DistMap->size[1];
            if (b_DistMap->size[1] == TempA->size[1]) {
              k = TempA->size[0] * TempA->size[1];
              TempA->size[0] = 4;
              TempA->size[1] = b_DistMap->size[1];
              emxEnsureCapacity_real_T(TempA, k);
              TempA_data = TempA->data;
              for (k = 0; k < idx; k++) {
                TempA_data[4 * k] =
                    DistMap_data[4 * k + 4 * b_DistMap->size[1] * 99] -
                    TempA_data[4 * k];
                k0 = 4 * k + 1;
                TempA_data[k0] =
                    DistMap_data[(4 * k + 4 * b_DistMap->size[1] * 99) + 1] -
                    TempA_data[k0];
                k0 = 4 * k + 2;
                TempA_data[k0] =
                    DistMap_data[(4 * k + 4 * b_DistMap->size[1] * 99) + 2] -
                    TempA_data[k0];
                k0 = 4 * k + 3;
                TempA_data[k0] =
                    DistMap_data[(4 * k + 4 * b_DistMap->size[1] * 99) + 3] -
                    TempA_data[k0];
              }
            } else {
              binary_expand_op(TempA, b_DistMap);
              TempA_data = TempA->data;
            }
            nx = TempA->size[1] << 2;
            k = DistErr->size[0] * DistErr->size[1];
            DistErr->size[0] = 4;
            DistErr->size[1] = TempA->size[1];
            emxEnsureCapacity_real_T(DistErr, k);
            DistErr_data = DistErr->data;
            for (k = 0; k < nx; k++) {
              DistErr_data[k] = fabs(TempA_data[k]);
            }
            k = b_x->size[0];
            b_x->size[0] = DistErr->size[1] << 2;
            emxEnsureCapacity_boolean_T(b_x, k);
            x_data = b_x->data;
            idx = DistErr->size[1] << 2;
            for (k = 0; k < idx; k++) {
              x_data[k] = (DistErr_data[k] < 1.0);
            }
            nx = b_x->size[0];
            idx = 0;
            k = b_i->size[0];
            b_i->size[0] = b_x->size[0];
            emxEnsureCapacity_int32_T(b_i, k);
            i_data = b_i->data;
            k0 = 0;
            exitg1 = false;
            while ((!exitg1) && (k0 <= nx - 1)) {
              if (x_data[k0]) {
                idx++;
                i_data[idx - 1] = k0 + 1;
                if (idx >= nx) {
                  exitg1 = true;
                } else {
                  k0++;
                }
              } else {
                k0++;
              }
            }
            if (b_x->size[0] == 1) {
              if (idx == 0) {
                b_i->size[0] = 0;
              }
            } else {
              k = b_i->size[0];
              if (idx < 1) {
                b_i->size[0] = 0;
              } else {
                b_i->size[0] = idx;
              }
              emxEnsureCapacity_int32_T(b_i, k);
            }
            LessThan1m1[ss] = (unsigned int)b_i->size[0];
            CenterCands[ss] = CenterCandA;
            HeadingCands[ss] = HeadingCandA;
            ss++;
          } else if (b_s < PrevAbsHeadingCandA) {
            PrevAbsHeadingCandA = b_s;
            *PosHH = CenterCandA;
            PrevHeadingCandA = HeadingCandA;
          }
        }
      }
    }
  }
  emxFree_int32_T(&b_i);
  emxFree_creal_T(&x);
  emxFree_real_T(&DistErr);
  emxInit_creal_T(&sortedCenter);
  emxInit_creal_T(&sortedHeading);
  emxInit_int32_T(&r, 2);
  if ((ss + 1 == 1) && (PrevAbsHeadingCandA == 100.0)) {
    PosHH->re = 0.0;
    PosHH->im = 0.0;
    *HeadingHH = 0.0;
  } else if (ss + 1 == 1) {
    *HeadingHH = rt_atan2d_snf(PrevHeadingCandA.im, PrevHeadingCandA.re);
  } else {
    for (i = 0; i < 20000; i++) {
      SortV[i] = LessThan1m1[i];
    }
    sort(SortV, iidx);
    for (i = 0; i < 20000; i++) {
      b_LessThan1m1[i] = (LessThan1m1[i] == SortV[0]);
    }
    eml_find(b_LessThan1m1, r);
    size_tmp_idx_1 = (short)r->size[1];
    for (i = 0; i < 20000; i++) {
      b_LessThan1m1[i] = (LessThan1m1[i] == SortV[0]);
    }
    eml_find(b_LessThan1m1, r);
    if (r->size[1] < 1) {
      idx = 0;
    } else {
      idx = size_tmp_idx_1;
    }
    i = sortedCenter->size[0] * sortedCenter->size[1];
    sortedCenter->size[0] = 1;
    sortedCenter->size[1] = idx;
    emxEnsureCapacity_creal_T(sortedCenter, i);
    sortedCenter_data = sortedCenter->data;
    for (i = 0; i < idx; i++) {
      sortedCenter_data[i] = CenterCands[iidx[i] - 1];
    }
    if (r->size[1] < 1) {
      idx = 0;
    } else {
      idx = size_tmp_idx_1;
    }
    i = sortedHeading->size[0] * sortedHeading->size[1];
    sortedHeading->size[0] = 1;
    sortedHeading->size[1] = idx;
    emxEnsureCapacity_creal_T(sortedHeading, i);
    sortedCenter_data = sortedHeading->data;
    for (i = 0; i < idx; i++) {
      sortedCenter_data[i] = HeadingCands[iidx[i] - 1];
    }
    *PosHH = b_mean(sortedCenter);
    PrevHeadingCandA = b_mean(sortedHeading);
    *HeadingHH = rt_atan2d_snf(PrevHeadingCandA.im, PrevHeadingCandA.re);
  }
  emxFree_int32_T(&r);
  emxFree_creal_T(&sortedHeading);
  emxFree_creal_T(&sortedCenter);
  PrevHeadingCandA.re = *HeadingHH * 0.0;
  if (*HeadingHH == 0.0) {
    b_s = PrevHeadingCandA.re;
    PrevHeadingCandA.re = exp(b_s);
    PrevHeadingCandA.im = 0.0;
  } else {
    b_r = exp(PrevHeadingCandA.re / 2.0);
    PrevHeadingCandA.re = b_r * (b_r * cos(*HeadingHH));
    PrevHeadingCandA.im = b_r * (b_r * sin(*HeadingHH));
  }
  idx = Xt_b_size[1] - 1;
  for (i = 0; i <= idx; i++) {
    b_r = Xt_b_data[i].im;
    b_s = Xt_b_data[i].re;
    Xt_b_data[i].re =
        PosHH->re + (PrevHeadingCandA.re * b_s - PrevHeadingCandA.im * b_r);
    Xt_b_data[i].im =
        PosHH->im + (PrevHeadingCandA.re * b_r + PrevHeadingCandA.im * b_s);
  }
  emxInit_creal_T(&Xt_b);
  i = Xt_b->size[0] * Xt_b->size[1];
  Xt_b->size[0] = Xt_b_size[1];
  Xt_b->size[1] = Xain->size[1];
  emxEnsureCapacity_creal_T(Xt_b, i);
  sortedCenter_data = Xt_b->data;
  idx = Xain->size[1];
  for (i = 0; i < idx; i++) {
    k0 = Xt_b_size[1];
    for (i1 = 0; i1 < k0; i1++) {
      sortedCenter_data[i1 + Xt_b->size[0] * i].re =
          Xt_b_data[i1].re - Xain_data[i].re;
      sortedCenter_data[i1 + Xt_b->size[0] * i].im =
          Xt_b_data[i1].im - Xain_data[i].im;
    }
  }
  emxFree_creal_T(&Xain);
  emxInit_real_T(&r1, 2);
  b_abs(Xt_b, r1);
  DistErr_data = r1->data;
  emxFree_creal_T(&Xt_b);
  if ((r1->size[0] == 4) && (r1->size[1] == b_DistMap->size[1])) {
    i = TempA->size[0] * TempA->size[1];
    TempA->size[0] = 4;
    TempA->size[1] = r1->size[1];
    emxEnsureCapacity_real_T(TempA, i);
    TempA_data = TempA->data;
    idx = r1->size[1];
    for (i = 0; i < idx; i++) {
      for (i1 = 0; i1 < 4; i1++) {
        i2 = i1 + 4 * i;
        TempA_data[i2] = DistErr_data[i1 + r1->size[0] * i] -
                         DistMap_data[i2 + 4 * b_DistMap->size[1] * 99];
      }
    }
  } else {
    c_binary_expand_op(TempA, r1, b_DistMap);
    TempA_data = TempA->data;
  }
  emxFree_real_T(&r1);
  emxInit_boolean_T(&r2, 2);
  i = r2->size[0] * r2->size[1];
  r2->size[0] = 4;
  r2->size[1] = b_DistMap->size[1];
  emxEnsureCapacity_boolean_T(r2, i);
  x_data = r2->data;
  idx = b_DistMap->size[1];
  for (i = 0; i < idx; i++) {
    x_data[4 * i] = (DistMap_data[4 * i + 4 * b_DistMap->size[1] * 99] == 0.0);
    x_data[4 * i + 1] =
        (DistMap_data[(4 * i + 4 * b_DistMap->size[1] * 99) + 1] == 0.0);
    x_data[4 * i + 2] =
        (DistMap_data[(4 * i + 4 * b_DistMap->size[1] * 99) + 2] == 0.0);
    x_data[4 * i + 3] =
        (DistMap_data[(4 * i + 4 * b_DistMap->size[1] * 99) + 3] == 0.0);
  }
  idx = (r2->size[1] << 2) - 1;
  k0 = 0;
  for (nx = 0; nx <= idx; nx++) {
    if (x_data[nx]) {
      k0++;
    }
  }
  emxInit_int32_T(&r3, 1);
  i = r3->size[0];
  r3->size[0] = k0;
  emxEnsureCapacity_int32_T(r3, i);
  i_data = r3->data;
  k0 = 0;
  for (nx = 0; nx <= idx; nx++) {
    if (x_data[nx]) {
      i_data[k0] = nx + 1;
      k0++;
    }
  }
  emxFree_boolean_T(&r2);
  idx = r3->size[0];
  for (i = 0; i < idx; i++) {
    TempA_data[i_data[i] - 1] = 0.0;
  }
  emxFree_int32_T(&r3);
  emxInit_real_T(&TempB, 1);
  i = TempB->size[0];
  TempB->size[0] = TempA->size[1] << 2;
  emxEnsureCapacity_real_T(TempB, i);
  TempB_data = TempB->data;
  idx = TempA->size[1] << 2;
  for (i = 0; i < idx; i++) {
    TempB_data[i] = TempA_data[i];
  }
  i = b_x->size[0];
  b_x->size[0] = TempA->size[1] << 2;
  emxEnsureCapacity_boolean_T(b_x, i);
  x_data = b_x->data;
  idx = TempA->size[1] << 2;
  for (i = 0; i < idx; i++) {
    x_data[i] = (TempA_data[i] == 0.0);
  }
  nx = TempA->size[1] << 2;
  k0 = 0;
  i = b_x->size[0];
  for (k = 0; k < i; k++) {
    k0 += x_data[k];
  }
  idx = (TempA->size[1] << 2) - k0;
  emxFree_real_T(&TempA);
  k0 = -1;
  for (k = 0; k < nx; k++) {
    if ((k + 1 > b_x->size[0]) || (!x_data[k])) {
      k0++;
      TempB_data[k0] = TempB_data[k];
    }
  }
  emxFree_boolean_T(&b_x);
  i = TempB->size[0];
  if (idx < 1) {
    TempB->size[0] = 0;
  } else {
    TempB->size[0] = idx;
  }
  emxEnsureCapacity_real_T(TempB, i);
  TempB_data = TempB->data;
  nx = TempB->size[0];
  emxInit_real_T(&y, 1);
  i = y->size[0];
  y->size[0] = TempB->size[0];
  emxEnsureCapacity_real_T(y, i);
  DistErr_data = y->data;
  for (k = 0; k < nx; k++) {
    DistErr_data[k] = fabs(TempB_data[k]);
  }
  idx = y->size[0];
  for (i = 0; i < idx; i++) {
    b_r = DistErr_data[i];
    DistErr_data[i] = b_r * b_r;
  }
  if ((sqrt(c_mean(y)) > 0.5) || (TempB->size[0] < 11)) {
    PosHH->re = 0.0;
    PosHH->im = 0.0;
  }
  emxFree_real_T(&y);
  emxFree_real_T(&TempB);
}

/*
 * File trailer for UWBMultiTagPos_V3_1.c
 *
 * [EOF]
 */
