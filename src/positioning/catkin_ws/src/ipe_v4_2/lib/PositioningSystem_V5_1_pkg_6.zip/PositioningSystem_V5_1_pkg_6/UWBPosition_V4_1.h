/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: UWBPosition_V4_1.h
 *
 * MATLAB Coder version            : 5.5
 * C/C++ source code generated on  : 24-Jul-2024 13:01:20
 */

#ifndef UWBPOSITION_V4_1_H
#define UWBPOSITION_V4_1_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void UWBPosition_V4_1(double s_time, double Ln, double Nanchor, double TagID,
                      const double RxIDUWB_data[], const int RxIDUWB_size[2],
                      const double RxDistOrig_data[],
                      const int RxDistOrig_size[2], const double xain_data[],
                      const int xain_size[2], const double yain_data[],
                      const int yain_size[2], const double zain_data[],
                      const double xt_b_data[], const int xt_b_size[2],
                      const double yt_b_data[], const int yt_b_size[2],
                      double zt_b, creal_T *PosUWBO, double *HeadingUWBO,
                      double *UWBFull);

void UWBPosition_V4_1_free(void);

void UWBPosition_V4_1_init(void);

void d_binary_expand_op(creal_T in1_data[], int in1_size[2],
                        const double in2_data[], const int in2_size[2],
                        const double in4_data[], const int in4_size[2]);

void s_time_prev_not_empty_init(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for UWBPosition_V4_1.h
 *
 * [EOF]
 */
