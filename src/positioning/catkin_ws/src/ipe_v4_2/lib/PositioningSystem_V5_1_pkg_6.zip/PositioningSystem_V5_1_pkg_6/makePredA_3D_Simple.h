/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: makePredA_3D_Simple.h
 *
 * MATLAB Coder version            : 5.5
 * C/C++ source code generated on  : 24-Jul-2024 13:01:20
 */

#ifndef MAKEPREDA_3D_SIMPLE_H
#define MAKEPREDA_3D_SIMPLE_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void makePredA_3D_Simple(const double Xhat[15], const double acc[3],
                         const double p[3], double A[225]);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for makePredA_3D_Simple.h
 *
 * [EOF]
 */
