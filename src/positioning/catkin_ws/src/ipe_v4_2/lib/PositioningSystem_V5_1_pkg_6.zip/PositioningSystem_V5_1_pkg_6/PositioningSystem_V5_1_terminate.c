/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: PositioningSystem_V5_1_terminate.c
 *
 * MATLAB Coder version            : 5.5
 * C/C++ source code generated on  : 24-Jul-2024 13:01:20
 */

/* Include Files */
#include "PositioningSystem_V5_1_terminate.h"
#include "PositioningSystem_V5_1_data.h"
#include "UWBPosition_V4_1.h"
#include "rt_nonfinite.h"

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : void
 */
void PositioningSystem_V5_1_terminate(void)
{
  UWBPosition_V4_1_free();
  isInitialized_PositioningSystem_V5_1 = false;
}

/*
 * File trailer for PositioningSystem_V5_1_terminate.c
 *
 * [EOF]
 */
