/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: PositioningSystem_V5_1_data.h
 *
 * MATLAB Coder version            : 5.5
 * C/C++ source code generated on  : 24-Jul-2024 13:01:20
 */

#ifndef POSITIONINGSYSTEM_V5_1_DATA_H
#define POSITIONINGSYSTEM_V5_1_DATA_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

/* Variable Declarations */
extern double PosP[3];
extern double roll;
extern double pitch;
extern double yaw;
extern double s;
extern double Hroll;
extern double Hpitch;
extern double Hyaw;
extern creal_T totPosP[5];
extern double UWBless;
extern boolean_T isInitialized_PositioningSystem_V5_1;

#endif
/*
 * File trailer for PositioningSystem_V5_1_data.h
 *
 * [EOF]
 */
