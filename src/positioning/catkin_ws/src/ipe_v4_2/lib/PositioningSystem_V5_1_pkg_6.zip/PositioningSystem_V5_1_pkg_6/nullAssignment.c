/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: nullAssignment.c
 *
 * MATLAB Coder version            : 5.5
 * C/C++ source code generated on  : 24-Jul-2024 13:01:20
 */

/* Include Files */
#include "nullAssignment.h"
#include "rt_nonfinite.h"
#include <string.h>

/* Function Definitions */
/*
 * Arguments    : creal_T x_data[]
 *                int x_size[2]
 *                const int idx_data[]
 *                const int idx_size[2]
 * Return Type  : void
 */
void nullAssignment(creal_T x_data[], int x_size[2], const int idx_data[],
                    const int idx_size[2])
{
  int b_size_idx_1;
  int k;
  int k0;
  int nxin;
  int nxout;
  boolean_T b_data[12];
  nxin = x_size[1];
  b_size_idx_1 = x_size[1];
  nxout = x_size[1];
  if (nxout - 1 >= 0) {
    memset(&b_data[0], 0, (unsigned int)nxout * sizeof(boolean_T));
  }
  nxout = idx_size[1];
  for (k = 0; k < nxout; k++) {
    b_data[idx_data[k] - 1] = true;
  }
  nxout = 0;
  for (k = 0; k < b_size_idx_1; k++) {
    nxout += b_data[k];
  }
  nxout = x_size[1] - nxout;
  k0 = -1;
  for (k = 0; k < nxin; k++) {
    if ((k + 1 > b_size_idx_1) || (!b_data[k])) {
      k0++;
      x_data[k0] = x_data[k];
    }
  }
  if (nxout < 1) {
    x_size[1] = 0;
  } else {
    x_size[1] = nxout;
  }
}

/*
 * File trailer for nullAssignment.c
 *
 * [EOF]
 */
