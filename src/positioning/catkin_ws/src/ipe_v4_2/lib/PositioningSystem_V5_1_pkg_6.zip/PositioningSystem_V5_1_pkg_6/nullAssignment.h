/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: nullAssignment.h
 *
 * MATLAB Coder version            : 5.5
 * C/C++ source code generated on  : 24-Jul-2024 13:01:20
 */

#ifndef NULLASSIGNMENT_H
#define NULLASSIGNMENT_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void nullAssignment(creal_T x_data[], int x_size[2], const int idx_data[],
                    const int idx_size[2]);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for nullAssignment.h
 *
 * [EOF]
 */
