/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: EKF_UWB_SLAM_4.c
 *
 * MATLAB Coder version            : 5.5
 * C/C++ source code generated on  : 24-Jul-2024 13:01:20
 */

/* Include Files */
#include "EKF_UWB_SLAM_4.h"
#include "PositioningSystem_V5_1_data.h"
#include "PositioningSystem_V5_1_rtwutil.h"
#include "mod.h"
#include "rt_nonfinite.h"
#include "xzgetrf.h"
#include <math.h>
#include <string.h>

/* Variable Definitions */
static double b_H[96];

static double c_P[256];

static double b_Q[256];

static double b_R[36];

/* Function Definitions */
/*
 * Arguments    : const creal_T PosUWB
 *                double HeadUWB
 *                double dPosSLAM[3]
 *                double dHeadSLAM[3]
 *                const double PosSLAMc[3]
 *                creal_T *Posn
 *                double Headn[3]
 * Return Type  : void
 */
void EKF_UWB_SLAM_4(const creal_T PosUWB, double HeadUWB, double dPosSLAM[3],
                    double dHeadSLAM[3], const double PosSLAMc[3],
                    creal_T *Posn, double Headn[3])
{
  double A[256];
  double Pp[256];
  double b_A[256];
  double K[96];
  double b_Pp[96];
  double b[36];
  double x[36];
  double xp[16];
  double b_PosUWB[6];
  double A_tmp;
  double A_tmp_tmp;
  double A_tmp_tmp_tmp;
  double b_A_tmp;
  double b_A_tmp_tmp;
  double b_A_tmp_tmp_tmp;
  double b_xn_tmp;
  double c_A_tmp;
  double c_A_tmp_tmp;
  double c_xn_tmp;
  double d_A_tmp;
  double d_A_tmp_tmp;
  double d_xn_tmp;
  double e_xn_tmp;
  double xn_tmp;
  double xn_tmp_tmp;
  int ipiv[6];
  int b_i;
  int b_tmp;
  int i;
  int i1;
  int j;
  int k;
  int kAcol;
  int pipk;
  signed char p[6];
  if ((PosUWB.re != 0.0) || (PosUWB.im != 0.0)) {
    if (PosP[0] == 0.0) {
      /* || (dPosSLAM(1)==0) */
      /*  PosP = [real(PosUWB);0;imag(PosUWB)]; */
      PosP[0] = PosSLAMc[0];
      PosP[1] = PosSLAMc[1];
      PosP[2] = PosSLAMc[2];
      s = 3.3027;
      roll = 0.034;
      pitch = 1.5508;
      yaw = 0.0076;
      /*  Eul = quat2eul(QuatInit); */
      Hroll = 0.034;
      /*  Hpitch = HeadUWB; */
      Hpitch = 1.5508;
      Hyaw = 0.0076;
      /*  s = 7.14; */
      /*  s = 8.3; */
    } else if (dPosSLAM[0] == 0.0) {
      /*  Eul = quat2eul(QuatInit); */
      /*  Hroll = Eul(1); */
      /*  Hpitch = Eul(2); */
      /*  Hyaw = Eul(3); */
      /*  load('MapParams4.mat') */
      s = 3.3027;
      roll = 0.034;
      pitch = 1.5508;
      yaw = 0.0076;
      /*  roll =  0; */
      /*  pitch = 0; */
      /*  yaw =  0; */
      /*          s = 4.6; */
      /*  sA = s*eulr2dcm([0 -pi*0.57 0]); */
      /*   */
      /*  SLAMposInit = [40.572;0;4.2114]; */
      /*  roll = 0; */
      /*  pitch = -pi*0.57; */
      /*  yaw = 0; */
      /*  load("MapParams3.mat"); */
      /*  s = sqrt(sum(abs(sA*[1;0;0]).^2)); */
      /*   */
      /*  TrMat = eulr2dcm([pi/2 0 pi/2]); */
      /*  Tempp = TrMat*sA/s; */
      /*  Tep = dcm2eulr(Tempp)-[pi/2; 0; pi/2]; */
      /*   */
      /*  % Tep = dcm2eulr(sA/s); */
      /*  roll = Tep(1); */
      /*  pitch = Tep(3); */
      /*  yaw = -Tep(2); */
      /*   */
      /*  Q = 1e-7*ones(16,16); */
      /*  Temp = Ajacob(ones(1,16)); */
      /*  Q(Temp==0)=0; */
      /*  roll = roll - dHeadSLAM(1); */
      /*  pitch = pitch - dHeadSLAM(2); */
      /*  yaw = yaw - dHeadSLAM(3); */
    } else if ((sqrt((dHeadSLAM[0] * dHeadSLAM[0] +
                      dHeadSLAM[1] * dHeadSLAM[1]) +
                     dHeadSLAM[2] * dHeadSLAM[2]) > 0.5) ||
               (sqrt((dPosSLAM[0] * dPosSLAM[0] + dPosSLAM[1] * dPosSLAM[1]) +
                     dPosSLAM[2] * dPosSLAM[2]) > 0.1)) {
      /*  s = 4.6; */
      /*  sA = s*eulr2dcm([0 -pi*0.57 0]); */
      /*   */
      /*  SLAMposInit = [40.572;0;4.2114]; */
      /*  roll = 0; */
      /*  pitch = -pi*0.57; */
      /*  yaw = 0; */
      dPosSLAM[0] = 0.0;
      dHeadSLAM[0] = 0.0;
      dPosSLAM[1] = 0.0;
      dHeadSLAM[1] = 0.0;
      dPosSLAM[2] = 0.0;
      dHeadSLAM[2] = 0.0;
      s = 3.3027;
      roll = 0.034;
      pitch = 1.5508;
      yaw = 0.0076;
      /*  PosP = PosSLAMc; */
    }
  }
  /* ------------------------ */
  xn_tmp = cos(roll);
  b_xn_tmp = sin(roll);
  c_xn_tmp = sin(yaw);
  d_xn_tmp = cos(yaw);
  e_xn_tmp = cos(pitch);
  xn_tmp_tmp = sin(pitch);
  xp[0] = PosP[0] + s * ((((xn_tmp * e_xn_tmp * dPosSLAM[0] -
                            b_xn_tmp * d_xn_tmp * dPosSLAM[1]) +
                           xn_tmp * xn_tmp_tmp * c_xn_tmp * dPosSLAM[1]) +
                          b_xn_tmp * c_xn_tmp * dPosSLAM[2]) +
                         cos(roll) * xn_tmp_tmp * d_xn_tmp * dPosSLAM[2]);
  xp[1] = PosP[1] + s * ((((b_xn_tmp * e_xn_tmp * dPosSLAM[0] +
                            xn_tmp * d_xn_tmp * dPosSLAM[1]) +
                           b_xn_tmp * xn_tmp_tmp * c_xn_tmp * dPosSLAM[1]) -
                          xn_tmp * c_xn_tmp * dPosSLAM[2]) +
                         sin(roll) * xn_tmp_tmp * d_xn_tmp * dPosSLAM[2]);
  xp[2] = PosP[2] +
          s * ((-xn_tmp_tmp * dPosSLAM[0] + e_xn_tmp * c_xn_tmp * dPosSLAM[1]) +
               e_xn_tmp * d_xn_tmp * dPosSLAM[2]);
  xp[3] = dPosSLAM[0];
  xp[4] = dPosSLAM[1];
  xp[5] = dPosSLAM[2];
  xp[6] = roll;
  xp[7] = pitch;
  xp[8] = yaw;
  xp[9] = s;
  xp[10] =
      (Hroll + b_mod(dHeadSLAM[0] + 1.5707963267948966)) - 1.5707963267948966;
  xp[11] =
      (Hpitch + c_mod(dHeadSLAM[1] + 3.1415926535897931)) - 3.1415926535897931;
  xp[12] =
      (Hyaw + b_mod(dHeadSLAM[2] + 1.5707963267948966)) - 1.5707963267948966;
  xp[13] = dHeadSLAM[0];
  xp[14] = dHeadSLAM[1];
  xp[15] = dHeadSLAM[2];
  if ((PosUWB.re != 0.0) || (PosUWB.im != 0.0)) {
    /*  if (PosP(1)==0) */
    /*      PosP = [real(PosUWB);0;imag(PosUWB)]; */
    /*      pitch = HeadUWB; */
    /*      s = 8.3; */
    /*  end */
    /* ------------------------ */
    memset(&A[0], 0, 256U * sizeof(double));
    for (k = 0; k < 16; k++) {
      A[k + (k << 4)] = 1.0;
    }
    A_tmp_tmp = cos(roll);
    b_A_tmp_tmp = cos(pitch);
    A[48] = s * A_tmp_tmp * b_A_tmp_tmp;
    A_tmp = sin(roll);
    c_A_tmp_tmp = sin(yaw);
    b_A_tmp = cos(yaw);
    c_A_tmp = sin(pitch);
    A[64] = s * (-A_tmp * b_A_tmp + A_tmp_tmp * c_A_tmp * c_A_tmp_tmp);
    A[80] = s * (A_tmp * c_A_tmp_tmp + cos(roll) * sin(pitch) * b_A_tmp);
    A[96] = s * ((((-sin(roll) * b_A_tmp_tmp * dPosSLAM[0] -
                    A_tmp_tmp * b_A_tmp * dPosSLAM[1]) -
                   A_tmp * c_A_tmp * c_A_tmp_tmp * dPosSLAM[1]) +
                  A_tmp_tmp * c_A_tmp_tmp * dPosSLAM[2]) -
                 sin(roll) * sin(pitch) * b_A_tmp * dPosSLAM[2]);
    d_A_tmp_tmp = A_tmp_tmp * b_A_tmp_tmp;
    A[112] = s * ((A_tmp_tmp * -c_A_tmp * dPosSLAM[0] +
                   d_A_tmp_tmp * c_A_tmp_tmp * dPosSLAM[1]) +
                  d_A_tmp_tmp * b_A_tmp * dPosSLAM[2]);
    A_tmp_tmp_tmp = cos(roll);
    b_A_tmp_tmp_tmp = sin(pitch);
    d_xn_tmp = A_tmp_tmp_tmp * b_A_tmp_tmp_tmp;
    d_A_tmp = d_xn_tmp * c_A_tmp_tmp;
    e_xn_tmp = sin(roll);
    xn_tmp_tmp = sin(yaw);
    b_xn_tmp = e_xn_tmp * xn_tmp_tmp;
    c_xn_tmp = cos(yaw);
    xn_tmp = d_xn_tmp * c_xn_tmp;
    A[128] = s * (((b_xn_tmp * dPosSLAM[1] + xn_tmp * dPosSLAM[1]) +
                   A_tmp * b_A_tmp * dPosSLAM[2]) -
                  d_A_tmp * dPosSLAM[2]);
    d_A_tmp =
        (((d_A_tmp_tmp * dPosSLAM[0] - e_xn_tmp * c_xn_tmp * dPosSLAM[1]) +
          d_A_tmp * dPosSLAM[1]) +
         b_xn_tmp * dPosSLAM[2]) +
        xn_tmp * dPosSLAM[2];
    A[144] = d_A_tmp;
    A[49] = s * (A_tmp * b_A_tmp_tmp);
    d_A_tmp_tmp = A_tmp_tmp_tmp * c_xn_tmp;
    d_xn_tmp = e_xn_tmp * b_A_tmp_tmp_tmp;
    xn_tmp = d_xn_tmp * xn_tmp_tmp;
    A[65] = s * (d_A_tmp_tmp + xn_tmp);
    d_xn_tmp *= c_xn_tmp;
    A[81] = s * (-A_tmp_tmp * c_A_tmp_tmp + d_xn_tmp);
    A[97] = s * d_A_tmp;
    A_tmp_tmp = cos(pitch);
    d_A_tmp = e_xn_tmp * A_tmp_tmp;
    A[113] = s * ((A_tmp * -b_A_tmp_tmp_tmp * dPosSLAM[0] +
                   d_A_tmp * c_A_tmp_tmp * dPosSLAM[1]) +
                  d_A_tmp * b_A_tmp * dPosSLAM[2]);
    A[129] =
        s *
        (((-A_tmp_tmp_tmp * xn_tmp_tmp * dPosSLAM[1] + d_xn_tmp * dPosSLAM[1]) -
          d_A_tmp_tmp * dPosSLAM[2]) -
         xn_tmp * dPosSLAM[2]);
    A[145] = (((d_A_tmp * dPosSLAM[0] + d_A_tmp_tmp * dPosSLAM[1]) +
               xn_tmp * dPosSLAM[1]) -
              A_tmp_tmp_tmp * xn_tmp_tmp * dPosSLAM[2]) +
             d_xn_tmp * dPosSLAM[2];
    A[50] = s * -b_A_tmp_tmp_tmp;
    A[66] = s * (b_A_tmp_tmp * c_A_tmp_tmp);
    A[82] = s * (b_A_tmp_tmp * b_A_tmp);
    A[114] =
        s *
        ((-b_A_tmp_tmp * dPosSLAM[0] - c_A_tmp * c_A_tmp_tmp * dPosSLAM[1]) -
         c_A_tmp * b_A_tmp * dPosSLAM[2]);
    A_tmp = A_tmp_tmp * xn_tmp_tmp;
    b_A_tmp = A_tmp_tmp * c_xn_tmp;
    A[130] = s * (b_A_tmp * dPosSLAM[1] - A_tmp * dPosSLAM[2]);
    A[146] = (-b_A_tmp_tmp_tmp * dPosSLAM[0] + A_tmp * dPosSLAM[1]) +
             b_A_tmp * dPosSLAM[2];
    A[218] = 1.0;
    A[235] = 1.0;
    A[252] = 1.0;
    xn_tmp = HeadUWB - Hpitch;
    if (xn_tmp > 6.2831853071795862) {
      HeadUWB -= 6.2831853071795862 * floor(xn_tmp / 6.2831853071795862);
    } else if (Hpitch - HeadUWB > 6.2831853071795862) {
      HeadUWB +=
          6.2831853071795862 * floor((Hpitch - HeadUWB) / 6.2831853071795862);
    }
    xn_tmp = HeadUWB - Hpitch;
    if (xn_tmp > 3.1415926535897931) {
      HeadUWB -= 6.2831853071795862;
    } else if (xn_tmp < -3.1415926535897931) {
      HeadUWB += 6.2831853071795862;
    }
    /*  z = [real(PosUWB);imag(PosUWB);HeadUWB]; */
    for (i = 0; i < 16; i++) {
      for (i1 = 0; i1 < 16; i1++) {
        xn_tmp = 0.0;
        for (pipk = 0; pipk < 16; pipk++) {
          xn_tmp += A[i + (pipk << 4)] * c_P[pipk + (i1 << 4)];
        }
        b_A[i + (i1 << 4)] = xn_tmp;
      }
      for (i1 = 0; i1 < 16; i1++) {
        xn_tmp = 0.0;
        for (pipk = 0; pipk < 16; pipk++) {
          kAcol = pipk << 4;
          xn_tmp += b_A[i + kAcol] * A[i1 + kAcol];
        }
        pipk = i + (i1 << 4);
        Pp[pipk] = xn_tmp + b_Q[pipk];
      }
    }
    for (i = 0; i < 6; i++) {
      for (i1 = 0; i1 < 16; i1++) {
        K[i1 + (i << 4)] = b_H[i + 6 * i1];
      }
    }
    memset(&b[0], 0, 36U * sizeof(double));
    for (i = 0; i < 6; i++) {
      for (i1 = 0; i1 < 16; i1++) {
        xn_tmp = 0.0;
        for (pipk = 0; pipk < 16; pipk++) {
          xn_tmp += b_H[i + 6 * pipk] * Pp[pipk + (i1 << 4)];
        }
        b_Pp[i + 6 * i1] = xn_tmp;
      }
      for (i1 = 0; i1 < 6; i1++) {
        xn_tmp = 0.0;
        for (pipk = 0; pipk < 16; pipk++) {
          xn_tmp += b_Pp[i + 6 * pipk] * K[pipk + (i1 << 4)];
        }
        pipk = i + 6 * i1;
        x[pipk] = xn_tmp + b_R[pipk];
      }
    }
    xzgetrf(x, ipiv, &pipk);
    for (i = 0; i < 6; i++) {
      p[i] = (signed char)(i + 1);
    }
    for (k = 0; k < 5; k++) {
      i = ipiv[k];
      if (i > k + 1) {
        pipk = p[i - 1];
        p[i - 1] = p[k];
        p[k] = (signed char)pipk;
      }
    }
    for (k = 0; k < 6; k++) {
      b_tmp = 6 * (p[k] - 1);
      b[k + b_tmp] = 1.0;
      for (j = k + 1; j < 7; j++) {
        i = (j + b_tmp) - 1;
        if (b[i] != 0.0) {
          i1 = j + 1;
          for (b_i = i1; b_i < 7; b_i++) {
            pipk = (b_i + b_tmp) - 1;
            b[pipk] -= b[i] * x[(b_i + 6 * (j - 1)) - 1];
          }
        }
      }
    }
    for (j = 0; j < 6; j++) {
      pipk = 6 * j;
      for (k = 5; k >= 0; k--) {
        kAcol = 6 * k;
        i = k + pipk;
        xn_tmp = b[i];
        if (xn_tmp != 0.0) {
          b[i] = xn_tmp / x[k + kAcol];
          for (b_i = 0; b_i < k; b_i++) {
            b_tmp = b_i + pipk;
            b[b_tmp] -= b[i] * x[b_i + kAcol];
          }
        }
      }
    }
    for (i = 0; i < 16; i++) {
      for (i1 = 0; i1 < 6; i1++) {
        xn_tmp = 0.0;
        for (pipk = 0; pipk < 16; pipk++) {
          xn_tmp += Pp[i + (pipk << 4)] * K[pipk + (i1 << 4)];
        }
        b_Pp[i + (i1 << 4)] = xn_tmp;
      }
    }
    for (i = 0; i < 16; i++) {
      for (i1 = 0; i1 < 6; i1++) {
        xn_tmp = 0.0;
        for (pipk = 0; pipk < 6; pipk++) {
          xn_tmp += b_Pp[i + (pipk << 4)] * b[pipk + 6 * i1];
        }
        K[i + (i1 << 4)] = xn_tmp;
      }
    }
    b_PosUWB[0] = PosUWB.re;
    b_PosUWB[1] = 0.0;
    b_PosUWB[2] = PosUWB.im;
    b_PosUWB[3] = 0.0;
    b_PosUWB[4] = HeadUWB;
    b_PosUWB[5] = 0.0;
    for (i = 0; i < 6; i++) {
      xn_tmp = 0.0;
      for (i1 = 0; i1 < 16; i1++) {
        xn_tmp += b_H[i + 6 * i1] * xp[i1];
      }
      b_PosUWB[i] -= xn_tmp;
    }
    for (i = 0; i < 16; i++) {
      xn_tmp = 0.0;
      for (i1 = 0; i1 < 6; i1++) {
        xn_tmp += K[i + (i1 << 4)] * b_PosUWB[i1];
      }
      xp[i] += xn_tmp;
      for (i1 = 0; i1 < 16; i1++) {
        xn_tmp = 0.0;
        for (pipk = 0; pipk < 6; pipk++) {
          xn_tmp += K[i + (pipk << 4)] * b_H[pipk + 6 * i1];
        }
        A[i + (i1 << 4)] = xn_tmp;
      }
      for (i1 = 0; i1 < 16; i1++) {
        xn_tmp = 0.0;
        for (pipk = 0; pipk < 16; pipk++) {
          xn_tmp += A[i + (pipk << 4)] * Pp[pipk + (i1 << 4)];
        }
        pipk = i + (i1 << 4);
        c_P[pipk] = Pp[pipk] - xn_tmp;
      }
    }
    UWBless = 0.0;
  } else {
    UWBless++;
    /*  TempAA = eulr2dcm(HeadSLAMc)*[1;0;0]; */
    /*  Eulr_r = quaternionToEulerYXZ(QuatInit, eulr2dcm([roll  pitch  yaw]));
     */
    /*  x(1) = PosSLAMc(1); */
    /*  x(2) = PosSLAMc(2); */
    /*  x(3) = PosSLAMc(3); */
    /*  x(11) = 0; */
    /*  x(12) = atan2(TempAA(1),TempAA(3)); */
    /*  x(13) = 0; */
    /*  x(1) = PosSLAMc(1); */
    /*  x(2) = PosSLAMc(2); */
    /*  x(3) = PosSLAMc(3); */
    /*   */
    /*  x(11) = HeadSLAMc(1); */
    /*  x(12) = HeadSLAMc(2); */
    /*  x(13) = HeadSLAMc(3); */
    if (UWBless > 30.0) {
      /*  x(11:13) = Eulr_r; */
      xp[11] = c_mod(rt_atan2d_snf(totPosP[4].re - totPosP[0].re,
                                   totPosP[4].im - totPosP[0].im) +
                     6.2831853071795862);
    }
  }
  PosP[0] = xp[0];
  PosP[1] = xp[1];
  PosP[2] = xp[2];
  roll = xp[6];
  pitch = xp[7];
  yaw = xp[8];
  s = xp[9];
  /*   */
  /*  Tep = dcm2eulr(sA); */
  /*  roll = Tep(1); */
  /*  pitch = -Tep(3); */
  /*  yaw = Tep(2); */
  Hroll = xp[10];
  Hpitch = xp[11];
  Hyaw = xp[12];
  xn_tmp = PosP[0] + PosP[2] * 0.0;
  Posn->re = xn_tmp;
  Posn->im = PosP[2];
  Headn[0] = Hroll;
  Headn[1] = Hpitch;
  Headn[2] = Hyaw;
  /*   */
  /*  totHead = [totHead [Hroll;Hpitch;Hyaw]]; */
  /*  totA = [totA [roll;pitch;yaw]]; */
  /*  totHUWB = [totHUWB HeadUWB]; */
  /*   */
  totPosP[0] = totPosP[1];
  totPosP[1] = totPosP[2];
  totPosP[2] = totPosP[3];
  totPosP[3] = totPosP[4];
  totPosP[4].re = xn_tmp;
  totPosP[4].im = PosP[2];
  /*  totPosUWB = [totPosUWB PosUWB]; */
  /*   */
  /*  totdHeadSLAM = [totdHeadSLAM reshape(dHeadSLAM(:),3,1)]; */
  /*  totdPosSLAM = [totdPosSLAM dPosSLAM]; */
}

/*
 * Arguments    : void
 * Return Type  : void
 */
void EKF_UWB_SLAM_4_init(void)
{
  static const unsigned char uv[217] = {
      1U,   2U,   3U,   4U,   5U,   6U,   7U,   8U,   9U,   10U,  11U,  12U,
      13U,  14U,  15U,  16U,  18U,  19U,  20U,  21U,  22U,  23U,  24U,  25U,
      26U,  27U,  28U,  29U,  30U,  31U,  32U,  33U,  35U,  36U,  37U,  38U,
      39U,  40U,  41U,  42U,  43U,  44U,  45U,  46U,  47U,  52U,  53U,  54U,
      55U,  56U,  57U,  58U,  59U,  60U,  61U,  62U,  63U,  67U,  69U,  70U,
      71U,  72U,  73U,  74U,  75U,  76U,  77U,  78U,  79U,  83U,  84U,  86U,
      87U,  88U,  89U,  90U,  91U,  92U,  93U,  94U,  95U,  98U,  99U,  100U,
      101U, 103U, 104U, 105U, 106U, 107U, 108U, 109U, 110U, 111U, 115U, 116U,
      117U, 118U, 120U, 121U, 122U, 123U, 124U, 125U, 126U, 127U, 131U, 132U,
      133U, 134U, 135U, 137U, 138U, 139U, 140U, 141U, 142U, 143U, 147U, 148U,
      149U, 150U, 151U, 152U, 154U, 155U, 156U, 157U, 158U, 159U, 160U, 161U,
      162U, 163U, 164U, 165U, 166U, 167U, 168U, 169U, 171U, 172U, 173U, 174U,
      175U, 176U, 177U, 178U, 179U, 180U, 181U, 182U, 183U, 184U, 185U, 186U,
      188U, 189U, 190U, 191U, 192U, 193U, 194U, 195U, 196U, 197U, 198U, 199U,
      200U, 201U, 202U, 203U, 205U, 206U, 207U, 208U, 209U, 210U, 211U, 212U,
      213U, 214U, 215U, 216U, 217U, 219U, 220U, 222U, 223U, 224U, 225U, 226U,
      227U, 228U, 229U, 230U, 231U, 232U, 233U, 234U, 236U, 237U, 239U, 240U,
      241U, 242U, 243U, 244U, 245U, 246U, 247U, 248U, 249U, 250U, 251U, 253U,
      254U};
  static const signed char iv[96] = {
      1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0,
      0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  static const signed char iv1[36] = {
      100, 0, 0, 0,   0, 0, 0, 100, 0, 0, 0,   0, 0, 0, 100, 0, 0, 0,
      0,   0, 0, 100, 0, 0, 0, 0,   0, 0, 100, 0, 0, 0, 0,   0, 0, 100};
  int i;
  for (i = 0; i < 96; i++) {
    b_H[i] = iv[i];
  }
  for (i = 0; i < 36; i++) {
    b_R[i] = iv1[i];
  }
  Hroll = 0.0;
  Hpitch = 0.0;
  Hyaw = 0.0;
  UWBless = 0.0;
  memset(&totPosP[0], 0, 5U * sizeof(creal_T));
  /*  s = 8.14; */
  PosP[0] = 0.0;
  PosP[1] = 0.0;
  PosP[2] = 0.0;
  for (i = 0; i < 256; i++) {
    b_Q[i] = 1.0E-5;
  }
  /*  Q = 1e-7*ones(16,16); */
  for (i = 0; i < 217; i++) {
    b_Q[uv[i]] = 0.0;
  }
  for (i = 0; i < 256; i++) {
    c_P[i] = 1.0;
  }
  for (i = 0; i < 217; i++) {
    c_P[uv[i]] = 0.0;
  }
  /*   */
  /*      ParkingLot = uint8([]); */
  /*      ParkingLotS= imread('B1_ParkingLot.jpg'); */
  /*      for sx = 1:size(ParkingLotS,1) */
  /*          for sy = 1:size(ParkingLotS,2) */
  /*              % ParkingLot(sy,sx,:) =
   * ParkingLotS(size(ParkingLotS,1)-sx+1,size(ParkingLotS,2)-sy+1,:); */
  /*              ParkingLot(sy,sx,:) =
   * ParkingLotS(sx,size(ParkingLotS,2)-sy+1,:); */
  /*          end */
  /*      end */
  /*      figure(123411);hold off; */
  /*      imshow(ParkingLot); */
  /*  load('MapParams4.mat') */
  s = 3.3027;
  roll = 0.034;
  pitch = 1.5508;
  yaw = 0.0076;
}

/*
 * File trailer for EKF_UWB_SLAM_4.c
 *
 * [EOF]
 */
