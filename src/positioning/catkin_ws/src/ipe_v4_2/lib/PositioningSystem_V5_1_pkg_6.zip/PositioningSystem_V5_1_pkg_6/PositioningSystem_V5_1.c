/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: PositioningSystem_V5_1.c
 *
 * MATLAB Coder version            : 5.5
 * C/C++ source code generated on  : 24-Jul-2024 13:01:20
 */

/* Include Files */
#include "PositioningSystem_V5_1.h"
#include "EKF_UWB_SLAM_4.h"
#include "EKF_UWB_SLAM_IMU_1.h"
#include "PositioningSystem_V5_1_data.h"
#include "PositioningSystem_V5_1_initialize.h"
#include "PositioningSystem_V5_1_rtwutil.h"
#include "UWBPosition_V4_1.h"
#include "exp.h"
#include "interp1.h"
#include "mod.h"
#include "rt_nonfinite.h"
#include "rt_nonfinite.h"
#include <math.h>
#include <string.h>

/* Type Definitions */
#ifndef struct_emxArray_real_T_1x65
#define struct_emxArray_real_T_1x65
struct emxArray_real_T_1x65 {
  double data[65];
  int size[2];
};
#endif /* struct_emxArray_real_T_1x65 */
#ifndef typedef_emxArray_real_T_1x65
#define typedef_emxArray_real_T_1x65
typedef struct emxArray_real_T_1x65 emxArray_real_T_1x65;
#endif /* typedef_emxArray_real_T_1x65 */

/* Variable Definitions */
static double s_time_vec[4];

static emxArray_real_T_1x65 xt_b;

static emxArray_real_T_1x65 yt_b;

static double P[225];

static creal_T FiFoUWBpos[100];

static double FiFoUWBhead[100];

static double FiFoUWBtime[100];

static double FiFoSLAMpos[300];

static double FiFoSLAMhead[400];

static double FiFoSLAMtime[100];

static double FiFoSLAMEulDiff[300];

static double firstV;

static double sA[9];

static double SLAMposInit[3];

static double SLAMSet;

static double FiFoIMUacc[12];

static double FiFoIMUgyro[12];

static creal_T FiFoSLAMUWBpos[100];

static double FiFoSLAMUWBhead[100];

static double FiFoSLAMUWBtime[100];

static creal_T CAMPos;

/* Function Definitions */
/*
 * Arguments    : const double PositionVector_data[]
 *                const int PositionVector_size[2]
 *                double PositionOut[10]
 * Return Type  : void
 */
void PositioningSystem_V5_1(const double PositionVector_data[],
                            const int PositionVector_size[2],
                            double PositionOut[10])
{
  creal_T EKFpos;
  creal_T PosH;
  creal_T PrevPosHF;
  creal_T TT1;
  creal_T dc;
  double b_tmp_data[100];
  double tmp_data[100];
  double b_PositionVector_data[65];
  double c_PositionVector_data[65];
  double d_PositionVector_data[65];
  double e_PositionVector_data[65];
  double f_PositionVector_data[65];
  double SLAMpos[3];
  double curr_pos[3];
  double dv[3];
  double prev_pos[3];
  double HeadingH;
  double HeadingHF;
  double a;
  double absxk;
  double pitch_qt_rel;
  double prev_quat_tmp_idx_0;
  double prev_quat_tmp_idx_1;
  double prev_quat_tmp_idx_2;
  double q1_idx_3;
  double q2_idx_0;
  double q2_idx_2;
  double scale;
  double t;
  int b_PositionVector_size[2];
  int c_PositionVector_size[2];
  int d_PositionVector_size[2];
  int e_PositionVector_size[2];
  int FiFoSLAMhead_tmp;
  int FiFoSLAMpos_tmp;
  int i;
  int i1;
  int i2;
  int i3;
  int i4;
  int i5;
  int i6;
  int i7;
  int i8;
  int loop_ub;
  int trueCount;
  (void)PositionVector_size;
  if (!isInitialized_PositioningSystem_V5_1) {
    PositioningSystem_V5_1_initialize();
  }
  /*  dT = 0.001; */
  if (PositionVector_data[1] == 5.0) {
    PrevPosHF.re = 0.0;
    PrevPosHF.im = 0.0;
    HeadingHF = 0.0;
    PosH.re = 0.0;
    PosH.im = 0.0;
    HeadingH = 0.0;
    /*  dt = 10e-3; */
    if (PositionVector_data[2] != 0.0) {
      for (i = 0; i < 3; i++) {
        FiFoSLAMpos_tmp = 3 * (i + 1);
        FiFoIMUacc[3 * i] = FiFoIMUacc[FiFoSLAMpos_tmp];
        FiFoIMUacc[3 * i + 1] = FiFoIMUacc[FiFoSLAMpos_tmp + 1];
        FiFoIMUacc[3 * i + 2] = FiFoIMUacc[FiFoSLAMpos_tmp + 2];
      }
      for (i = 0; i < 3; i++) {
        FiFoIMUacc[i + 9] = PositionVector_data[i + 2];
        FiFoSLAMpos_tmp = 3 * (i + 1);
        FiFoIMUgyro[3 * i] = FiFoIMUgyro[FiFoSLAMpos_tmp];
        FiFoIMUgyro[3 * i + 1] = FiFoIMUgyro[FiFoSLAMpos_tmp + 1];
        FiFoIMUgyro[3 * i + 2] = FiFoIMUgyro[FiFoSLAMpos_tmp + 2];
      }
      /*  GyroD = mean(FiFoIMUgyro)*pi/180; */
      /*  acc = mean(FiFoIMUacc); */
      /*  GyroD = (FiFoIMUgyro(:,end))*pi/180; */
      FiFoIMUgyro[9] = PositionVector_data[5];
      prev_pos[0] = FiFoIMUacc[9];
      FiFoIMUgyro[10] = PositionVector_data[6];
      prev_pos[1] = FiFoIMUacc[10];
      FiFoIMUgyro[11] = PositionVector_data[7];
      prev_pos[2] = FiFoIMUacc[11] + 9.85;
      /*  [PosHF5, HeadingHF5, GammHF5, BetaHF5] = EKF_UWB_IMU_1(dt, acc, GyroD,
       * IMUtime, FiFoUWBpos(end), -FiFoUWBhead(end), FiFoUWBtime(end), grav);
       */
      EKF_UWB_SLAM_IMU_1(prev_pos, &FiFoIMUgyro[9], PositionVector_data[0],
                         FiFoSLAMUWBpos[99], FiFoSLAMUWBhead[99],
                         FiFoSLAMUWBtime[99], &TT1, &scale, &absxk, &t);
      /*  [PosHF5, HeadingHF5, GammHF5, BetaHF5] = EKF_UWB_SLAM_IMU_1(dt, acc,
       * GyroD, IMUtime,
       * FiFoSLAMUWBpos(end)-(-0.065+2.5*j)*exp(j*(FiFoSLAMUWBhead(end))),
       * FiFoSLAMUWBhead(end), FiFoSLAMUWBtime(end), grav); */
      /*          PosUWBIMU = [PosUWBIMU PosHF5]; */
      /*          HeadUWBIMU = [HeadUWBIMU HeadingHF5]; */
      /*          GammUWBIMU = [GammUWBIMU GammHF5]; */
      /*          BetaUWBIMU = [BetaUWBIMU BetaHF5]; */
    }
  } else if (PositionVector_data[1] == 6.0) {
    /*  GPS */
    PrevPosHF.re = 0.0;
    PrevPosHF.im = 0.0;
    HeadingHF = 0.0;
    PosH.re = 0.0;
    PosH.im = 0.0;
    HeadingH = 0.0;
  } else if (PositionVector_data[1] == 7.0) {
    /*  SLAM */
    PrevPosHF.re = 0.0;
    PrevPosHF.im = 0.0;
    HeadingHF = 0.0;
    PosH.re = 0.0;
    PosH.im = 0.0;
    HeadingH = 0.0;
    SLAMpos[0] = PositionVector_data[2];
    SLAMpos[1] = PositionVector_data[3];
    SLAMpos[2] = PositionVector_data[4];
    /*  SLAMorient = SLAMorient([4 1 2 3]); */
    if ((PositionVector_data[2] != 0.0) &&
        (FiFoSLAMtime[99] - PositionVector_data[0] < -0.001)) {
      for (i = 0; i < 99; i++) {
        FiFoSLAMpos_tmp = 3 * (i + 1);
        FiFoSLAMpos[3 * i] = FiFoSLAMpos[FiFoSLAMpos_tmp];
        FiFoSLAMpos[3 * i + 1] = FiFoSLAMpos[FiFoSLAMpos_tmp + 1];
        FiFoSLAMpos[3 * i + 2] = FiFoSLAMpos[FiFoSLAMpos_tmp + 2];
        FiFoSLAMpos_tmp = (i + 1) << 2;
        FiFoSLAMhead_tmp = i << 2;
        FiFoSLAMhead[FiFoSLAMhead_tmp] = FiFoSLAMhead[FiFoSLAMpos_tmp];
        FiFoSLAMhead[FiFoSLAMhead_tmp + 1] = FiFoSLAMhead[FiFoSLAMpos_tmp + 1];
        FiFoSLAMhead[FiFoSLAMhead_tmp + 2] = FiFoSLAMhead[FiFoSLAMpos_tmp + 2];
        FiFoSLAMhead[FiFoSLAMhead_tmp + 3] = FiFoSLAMhead[FiFoSLAMpos_tmp + 3];
        FiFoSLAMtime[i] = FiFoSLAMtime[i + 1];
      }
      FiFoSLAMpos[297] = SLAMpos[0];
      FiFoSLAMpos[298] = SLAMpos[1];
      FiFoSLAMpos[299] = SLAMpos[2];
      FiFoSLAMhead[396] = PositionVector_data[5];
      FiFoSLAMhead[397] = PositionVector_data[6];
      FiFoSLAMhead[398] = PositionVector_data[7];
      FiFoSLAMhead[399] = PositionVector_data[8];
      FiFoSLAMtime[99] = PositionVector_data[0];
      trueCount = 0;
      for (FiFoSLAMpos_tmp = 0; FiFoSLAMpos_tmp < 100; FiFoSLAMpos_tmp++) {
        if (FiFoSLAMtime[FiFoSLAMpos_tmp] != 0.0) {
          trueCount++;
        }
      }
      scale = FiFoSLAMtime[100 - trueCount];
      if ((scale < PositionVector_data[0] - 0.05) && (trueCount > 2)) {
        b_PositionVector_size[0] = 1;
        b_PositionVector_size[1] = trueCount;
        FiFoSLAMpos_tmp = trueCount - 100;
        c_PositionVector_size[0] = 1;
        c_PositionVector_size[1] = trueCount;
        for (i = 0; i <= FiFoSLAMpos_tmp + 99; i++) {
          FiFoSLAMhead_tmp = (i - trueCount) + 100;
          tmp_data[i] = FiFoSLAMtime[FiFoSLAMhead_tmp];
          b_tmp_data[i] = FiFoSLAMpos[3 * FiFoSLAMhead_tmp];
        }
        curr_pos[0] = interp1(tmp_data, b_PositionVector_size, b_tmp_data,
                              c_PositionVector_size, FiFoSLAMtime[99] - 0.05);
        b_PositionVector_size[0] = 1;
        b_PositionVector_size[1] = trueCount;
        c_PositionVector_size[0] = 1;
        c_PositionVector_size[1] = trueCount;
        for (i = 0; i <= FiFoSLAMpos_tmp + 99; i++) {
          FiFoSLAMhead_tmp = (i - trueCount) + 100;
          tmp_data[i] = FiFoSLAMtime[FiFoSLAMhead_tmp];
          b_tmp_data[i] = FiFoSLAMpos[3 * FiFoSLAMhead_tmp + 1];
        }
        curr_pos[1] = interp1(tmp_data, b_PositionVector_size, b_tmp_data,
                              c_PositionVector_size, FiFoSLAMtime[99] - 0.05);
        b_PositionVector_size[0] = 1;
        b_PositionVector_size[1] = trueCount;
        c_PositionVector_size[0] = 1;
        c_PositionVector_size[1] = trueCount;
        for (i = 0; i <= FiFoSLAMpos_tmp + 99; i++) {
          FiFoSLAMhead_tmp = (i - trueCount) + 100;
          tmp_data[i] = FiFoSLAMtime[FiFoSLAMhead_tmp];
          b_tmp_data[i] = FiFoSLAMpos[3 * FiFoSLAMhead_tmp + 2];
        }
        curr_pos[2] = interp1(tmp_data, b_PositionVector_size, b_tmp_data,
                              c_PositionVector_size, FiFoSLAMtime[99] - 0.05);
        if (scale < FiFoSLAMtime[98] - 0.05) {
          b_PositionVector_size[0] = 1;
          b_PositionVector_size[1] = trueCount;
          c_PositionVector_size[0] = 1;
          c_PositionVector_size[1] = trueCount;
          for (i = 0; i <= FiFoSLAMpos_tmp + 99; i++) {
            FiFoSLAMhead_tmp = (i - trueCount) + 100;
            tmp_data[i] = FiFoSLAMtime[FiFoSLAMhead_tmp];
            b_tmp_data[i] = FiFoSLAMpos[3 * FiFoSLAMhead_tmp];
          }
          prev_pos[0] = interp1(tmp_data, b_PositionVector_size, b_tmp_data,
                                c_PositionVector_size, FiFoSLAMtime[98] - 0.05);
          b_PositionVector_size[0] = 1;
          b_PositionVector_size[1] = trueCount;
          c_PositionVector_size[0] = 1;
          c_PositionVector_size[1] = trueCount;
          for (i = 0; i <= FiFoSLAMpos_tmp + 99; i++) {
            FiFoSLAMhead_tmp = (i - trueCount) + 100;
            tmp_data[i] = FiFoSLAMtime[FiFoSLAMhead_tmp];
            b_tmp_data[i] = FiFoSLAMpos[3 * FiFoSLAMhead_tmp + 1];
          }
          prev_pos[1] = interp1(tmp_data, b_PositionVector_size, b_tmp_data,
                                c_PositionVector_size, FiFoSLAMtime[98] - 0.05);
          b_PositionVector_size[0] = 1;
          b_PositionVector_size[1] = trueCount;
          c_PositionVector_size[0] = 1;
          c_PositionVector_size[1] = trueCount;
          for (i = 0; i <= FiFoSLAMpos_tmp + 99; i++) {
            FiFoSLAMhead_tmp = (i - trueCount) + 100;
            tmp_data[i] = FiFoSLAMtime[FiFoSLAMhead_tmp];
            b_tmp_data[i] = FiFoSLAMpos[3 * FiFoSLAMhead_tmp + 2];
          }
          prev_pos[2] = interp1(tmp_data, b_PositionVector_size, b_tmp_data,
                                c_PositionVector_size, FiFoSLAMtime[98] - 0.05);
        } else {
          prev_pos[0] = curr_pos[0];
          prev_pos[1] = curr_pos[1];
          prev_pos[2] = curr_pos[2];
        }
      } else {
        curr_pos[0] = FiFoSLAMpos[297];
        prev_pos[0] = FiFoSLAMpos[297];
        curr_pos[1] = FiFoSLAMpos[298];
        prev_pos[1] = FiFoSLAMpos[298];
        curr_pos[2] = FiFoSLAMpos[299];
        prev_pos[2] = FiFoSLAMpos[299];
      }
      if (PositionVector_data[2] != 0.0) {
        if (firstV == 0.0) {
          if ((FiFoUWBpos[99].re != 0.0) || (FiFoUWBpos[99].im != 0.0)) {
            firstV = 1.0;
          }
        } else {
          curr_pos[0] -= prev_pos[0];
          curr_pos[1] -= prev_pos[1];
          curr_pos[2] -= prev_pos[2];
          /*                 %% TODO:: shjang */
          scale = 3.3121686421112381E-170;
          absxk = fabs(FiFoSLAMhead[393]);
          if (absxk > 3.3121686421112381E-170) {
            a = 1.0;
            scale = absxk;
          } else {
            t = absxk / 3.3121686421112381E-170;
            a = t * t;
          }
          absxk = fabs(FiFoSLAMhead[394]);
          if (absxk > scale) {
            t = scale / absxk;
            a = a * t * t + 1.0;
            scale = absxk;
          } else {
            t = absxk / scale;
            a += t * t;
          }
          absxk = fabs(FiFoSLAMhead[395]);
          if (absxk > scale) {
            t = scale / absxk;
            a = a * t * t + 1.0;
            scale = absxk;
          } else {
            t = absxk / scale;
            a += t * t;
          }
          absxk = fabs(FiFoSLAMhead[392]);
          if (absxk > scale) {
            t = scale / absxk;
            a = a * t * t + 1.0;
            scale = absxk;
          } else {
            t = absxk / scale;
            a += t * t;
          }
          a = scale * sqrt(a);
          scale = a * a;
          /*  qt_rel = quatmultiply(curr_quat_tmp, prev_qt_inv); */
          absxk = PositionVector_data[6];
          t = PositionVector_data[7];
          a = PositionVector_data[8];
          q1_idx_3 = PositionVector_data[5];
          q2_idx_0 = FiFoSLAMhead[393] / scale;
          pitch_qt_rel = -FiFoSLAMhead[394] / scale;
          q2_idx_2 = -FiFoSLAMhead[395] / scale;
          scale = -FiFoSLAMhead[392] / scale;
          /*  q1과 q2는 각각 [w, x, y, z] 형식의 쿼터니언입니다. */
          /*  q는 q1과 q2의 곱입니다. */
          prev_quat_tmp_idx_0 =
              ((absxk * q2_idx_0 - t * pitch_qt_rel) - a * q2_idx_2) -
              q1_idx_3 * scale;
          prev_quat_tmp_idx_1 =
              ((absxk * pitch_qt_rel + q2_idx_0 * t) + a * scale) -
              q2_idx_2 * q1_idx_3;
          prev_quat_tmp_idx_2 =
              ((absxk * q2_idx_2 - t * scale) + q2_idx_0 * a) +
              pitch_qt_rel * q1_idx_3;
          absxk = ((absxk * scale + t * q2_idx_2) - pitch_qt_rel * a) +
                  q2_idx_0 * q1_idx_3;
          /*  Roll */
          /*  Pitch */
          scale = 2.0 * (prev_quat_tmp_idx_0 * prev_quat_tmp_idx_2 -
                         prev_quat_tmp_idx_1 * absxk);
          if (fabs(scale) >= 1.0) {
            if (rtIsNaN(scale)) {
              scale = rtNaN;
            } else if (scale < 0.0) {
              scale = -1.0;
            } else {
              scale = (scale > 0.0);
            }
            pitch_qt_rel = scale * 3.1415926535897931 / 2.0;
          } else {
            pitch_qt_rel = asin(scale);
          }
          /*  Yaw (psi) */
          scale = prev_quat_tmp_idx_2 * prev_quat_tmp_idx_2;
          prev_pos[0] = rt_atan2d_snf(
              2.0 * (prev_quat_tmp_idx_0 * prev_quat_tmp_idx_1 +
                     prev_quat_tmp_idx_2 * absxk),
              1.0 - 2.0 * (prev_quat_tmp_idx_1 * prev_quat_tmp_idx_1 + scale));
          prev_pos[1] = pitch_qt_rel;
          prev_pos[2] =
              rt_atan2d_snf(2.0 * (prev_quat_tmp_idx_0 * absxk +
                                   prev_quat_tmp_idx_1 * prev_quat_tmp_idx_2),
                            1.0 - 2.0 * (scale + absxk * absxk));
          /*  if sqrt(sum(abs(pos_diff_org).^2))<1 */
          /*      % RotMat_diff = (qua2dcm(curr_quat))/(qua2dcm(prev_quat)); */
          /*   */
          /*      RotMat_diff = (quat2rotm(curr_quat))/(quat2rotm(prev_quat));
           */
          /*      % EulCurr = equPlane(quat2eul(curr_quat)); */
          /*      % EulPrev = quat2eul(Prev_quat); */
          /*   */
          /*      TT = dcm2eulr(RotMat_diff); */
          /*      if abs(TT(3)) > pi/4 */
          /*          OffsetEulr = [pi/2; pi/2; 0]; */
          /*      else */
          /*          OffsetEulr = [0; 0; 0]; */
          /*      end */
          /*      TempOffDcm = eulr2dcm(OffsetEulr); */
          /*      RotEul_diff = dcm2eulr(RotMat_diff*TempOffDcm)-OffsetEulr; */
          /*   */
          /*  else */
          /*      RotMat_diff = eye(3); */
          /*      RotEul_diff = dcm2eulr(RotMat_diff); */
          /*      pos_diff_org = zeros(3,1); */
          /*      QuatInit = SLAMorient; */
          /*      firstV = 2; */
          /*  end */
          /*  TODO end */
          /*                 %% */
          /*  if Front == 1 */
          for (i = 0; i < 99; i++) {
            FiFoSLAMpos_tmp = 3 * (i + 1);
            FiFoSLAMEulDiff[3 * i] = FiFoSLAMEulDiff[FiFoSLAMpos_tmp];
            FiFoSLAMEulDiff[3 * i + 1] = FiFoSLAMEulDiff[FiFoSLAMpos_tmp + 1];
            FiFoSLAMEulDiff[3 * i + 2] = FiFoSLAMEulDiff[FiFoSLAMpos_tmp + 2];
          }
          FiFoSLAMEulDiff[297] = prev_pos[0];
          FiFoSLAMEulDiff[298] = pitch_qt_rel;
          FiFoSLAMEulDiff[299] = prev_pos[2];
          /*  else */
          /*      FiFoSLAMEulDiff = [FiFoSLAMEulDiff(:,2:end) (-RotEul_diff)];
           */
          /*  end */
          if (FiFoSLAMtime[98] < FiFoUWBtime[99] + 0.05) {
            /*  [EKFpos,EKFhead] =
             * EKF_UWB_SLAM_4(FiFoUWBpos(end)+(-0.065+0.74*j)*exp(j*(FiFoUWBhead(end))),
             * -FiFoUWBhead(end), pos_diff_org, RotEul_diff, QuatInit, PosSLAM,
             * tempEulr); */
            /*  if Front == 1 */
            TT1.re = FiFoUWBhead[99] * 0.0;
            TT1.im = FiFoUWBhead[99];
            b_exp(&TT1);
            scale = SLAMpos[0];
            t = SLAMpos[1];
            absxk = SLAMpos[2];
            for (i = 0; i < 3; i++) {
              dv[i] = ((sA[i] * scale + sA[i + 3] * t) + sA[i + 6] * absxk) +
                      SLAMposInit[i];
            }
            dc.re =
                FiFoUWBpos[99].re + (CAMPos.re * TT1.re - CAMPos.im * TT1.im);
            dc.im =
                FiFoUWBpos[99].im + (CAMPos.re * TT1.im + CAMPos.im * TT1.re);
            EKF_UWB_SLAM_4(dc, -FiFoUWBhead[99], curr_pos, prev_pos, dv,
                           &EKFpos, SLAMpos);
            /*  else */
            /*      [EKFpos,EKFhead] =
             * EKF_UWB_SLAM_4(FiFoUWBpos(end)+CAMPos*exp(j*(FiFoUWBhead(end))),
             * -FiFoUWBhead(end), pos_diff_org, -RotEul_diff, QuatInit, PosSLAM,
             * tempEulr); */
            /*  end */
          } else {
            /*  if Front == 1 */
            /* ------------------------ */
            scale = cos(roll);
            absxk = sin(roll);
            t = sin(yaw);
            a = cos(yaw);
            q1_idx_3 = cos(pitch);
            q2_idx_0 = sin(pitch);
            Hpitch = (Hpitch + c_mod(pitch_qt_rel + 3.1415926535897931)) -
                     3.1415926535897931;
            UWBless++;
            /*  TempAA = eulr2dcm(HeadSLAMc)*[1;0;0]; */
            /*  Eulr_r = quaternionToEulerYXZ(QuatInit, eulr2dcm([roll  pitch
             * yaw])); */
            /*  x(1) = PosSLAMc(1); */
            /*  x(2) = PosSLAMc(2); */
            /*  x(3) = PosSLAMc(3); */
            /*  x(11) = 0; */
            /*  x(12) = atan2(TempAA(1),TempAA(3)); */
            /*  x(13) = 0; */
            /*  x(1) = PosSLAMc(1); */
            /*  x(2) = PosSLAMc(2); */
            /*  x(3) = PosSLAMc(3); */
            /*   */
            /*  x(11) = HeadSLAMc(1); */
            /*  x(12) = HeadSLAMc(2); */
            /*  x(13) = HeadSLAMc(3); */
            if (UWBless > 30.0) {
              /*  x(11:13) = Eulr_r; */
              Hpitch = c_mod(rt_atan2d_snf(totPosP[4].re - totPosP[0].re,
                                           totPosP[4].im - totPosP[0].im) +
                             6.2831853071795862);
            }
            PosP[0] +=
                s *
                ((((scale * q1_idx_3 * curr_pos[0] - absxk * a * curr_pos[1]) +
                   scale * q2_idx_0 * t * curr_pos[1]) +
                  absxk * t * curr_pos[2]) +
                 cos(roll) * sin(pitch) * a * curr_pos[2]);
            PosP[1] +=
                s *
                ((((absxk * q1_idx_3 * curr_pos[0] + scale * a * curr_pos[1]) +
                   absxk * q2_idx_0 * t * curr_pos[1]) -
                  scale * t * curr_pos[2]) +
                 sin(roll) * sin(pitch) * a * curr_pos[2]);
            PosP[2] +=
                s * ((-q2_idx_0 * curr_pos[0] + q1_idx_3 * t * curr_pos[1]) +
                     q1_idx_3 * a * curr_pos[2]);
            /*   */
            /*  Tep = dcm2eulr(sA); */
            /*  roll = Tep(1); */
            /*  pitch = -Tep(3); */
            /*  yaw = Tep(2); */
            Hroll = (Hroll + b_mod(prev_pos[0] + 1.5707963267948966)) -
                    1.5707963267948966;
            Hyaw = (Hyaw + b_mod(prev_pos[2] + 1.5707963267948966)) -
                   1.5707963267948966;
            scale = PosP[0] + PosP[2] * 0.0;
            EKFpos.re = scale;
            EKFpos.im = PosP[2];
            SLAMpos[1] = Hpitch;
            /*   */
            /*  totHead = [totHead [Hroll;Hpitch;Hyaw]]; */
            /*  totA = [totA [roll;pitch;yaw]]; */
            /*  totHUWB = [totHUWB HeadUWB]; */
            /*   */
            totPosP[0] = totPosP[1];
            totPosP[1] = totPosP[2];
            totPosP[2] = totPosP[3];
            totPosP[3] = totPosP[4];
            totPosP[4].re = scale;
            totPosP[4].im = PosP[2];
            /*  totPosUWB = [totPosUWB PosUWB]; */
            /*   */
            /*  totdHeadSLAM = [totdHeadSLAM reshape(dHeadSLAM(:),3,1)]; */
            /*  totdPosSLAM = [totdPosSLAM dPosSLAM]; */
            /*  else */
            /*      [EKFpos,EKFhead] = EKF_UWB_SLAM_4(0,0, pos_diff_org,
             * -RotEul_diff, QuatInit, PosSLAM, tempEulr); */
            /*  end */
          }
          if (SLAMSet == 0.0) {
            if ((EKFpos.re != 0.0) || (EKFpos.im != 0.0)) {
              TT1.re = FiFoUWBhead[99] * 0.0;
              TT1.im = FiFoUWBhead[99];
              b_exp(&TT1);
              scale = CAMPos.re * TT1.re - CAMPos.im * TT1.im;
              absxk = CAMPos.re * TT1.im + CAMPos.im * TT1.re;
              if ((rt_hypotd_snf(EKFpos.re - (FiFoUWBpos[99].re + scale),
                                 EKFpos.im - (FiFoUWBpos[99].im + absxk)) <
                   0.5) &&
                  ((FiFoUWBpos[99].re != 0.0) || (FiFoUWBpos[99].im != 0.0))) {
                /*  &&
                 * (min(abs(mod((FiFoUWBhead(end)-EKFhead(2)),2*pi)),abs(mod((FiFoUWBhead(end)-EKFhead(2)),2*pi)-2*pi))<0.1)
                 */
                /*  if (EKFpos~=0) &&
                 * (abs(EKFpos-(FiFoUWBpos(end)+(-0.065+0.74*j)*exp(j*(FiFoUWBhead(end)))))<0.5)
                 * && (FiFoUWBpos(end)~=0) % &&
                 * (min(abs(mod((FiFoUWBhead(end)-EKFhead(2)),2*pi)),abs(mod((FiFoUWBhead(end)-EKFhead(2)),2*pi)-2*pi))<0.1)
                 */
                SLAMSet = 1.0;
                /*  PosHF = EKFpos; */
                /*  HeadingHF = EKFhead(2); */
                TT1.re = SLAMpos[1] * 0.0;
                TT1.im = -SLAMpos[1];
                b_exp(&TT1);
                PrevPosHF.re =
                    EKFpos.re - (CAMPos.re * TT1.re - CAMPos.im * TT1.im);
                PrevPosHF.im =
                    EKFpos.im - (CAMPos.re * TT1.im + CAMPos.im * TT1.re);
                HeadingHF = SLAMpos[1];
                for (i = 0; i < 99; i++) {
                  FiFoSLAMUWBpos[i] = FiFoSLAMUWBpos[i + 1];
                  FiFoSLAMUWBhead[i] = FiFoSLAMUWBhead[i + 1];
                  FiFoSLAMUWBtime[i] = FiFoSLAMUWBtime[i + 1];
                }
                FiFoSLAMUWBpos[99] = PrevPosHF;
                FiFoSLAMUWBhead[99] = SLAMpos[1];
                FiFoSLAMUWBtime[99] = PositionVector_data[0];
              }
            }
          } else {
            /*  PosHF = EKFpos; */
            /*  HeadingHF = EKFhead(2); */
            TT1.re = SLAMpos[1] * 0.0;
            TT1.im = -SLAMpos[1];
            b_exp(&TT1);
            PrevPosHF.re =
                EKFpos.re - (CAMPos.re * TT1.re - CAMPos.im * TT1.im);
            PrevPosHF.im =
                EKFpos.im - (CAMPos.re * TT1.im + CAMPos.im * TT1.re);
            HeadingHF = SLAMpos[1];
            for (i = 0; i < 99; i++) {
              FiFoSLAMUWBpos[i] = FiFoSLAMUWBpos[i + 1];
              FiFoSLAMUWBhead[i] = FiFoSLAMUWBhead[i + 1];
              FiFoSLAMUWBtime[i] = FiFoSLAMUWBtime[i + 1];
            }
            FiFoSLAMUWBpos[99] = PrevPosHF;
            FiFoSLAMUWBhead[99] = SLAMpos[1];
            FiFoSLAMUWBtime[99] = PositionVector_data[0];
          }
        }
      }
    }
  } else {
    /*  UWB */
    s_time_vec[0] = s_time_vec[1];
    s_time_vec[1] = s_time_vec[2];
    s_time_vec[2] = s_time_vec[3];
    s_time_vec[3] = PositionVector_data[0];
    scale = (PositionVector_data[4] + 6.0) - 1.0;
    if (scale < 6.0) {
      i = 0;
      i1 = 0;
    } else {
      i = 5;
      i1 = (int)scale;
    }
    scale = ((PositionVector_data[2] + 6.0) + PositionVector_data[4]) - 1.0;
    if (PositionVector_data[2] + 6.0 > scale) {
      FiFoSLAMpos_tmp = 0;
      FiFoSLAMhead_tmp = 0;
    } else {
      FiFoSLAMpos_tmp = (int)(PositionVector_data[2] + 6.0) - 1;
      FiFoSLAMhead_tmp = (int)scale;
    }
    scale = (PositionVector_data[2] + 6.0) + 4.0;
    t = scale + PositionVector_data[3];
    if (scale > t - 1.0) {
      trueCount = 0;
      i2 = 0;
    } else {
      trueCount = (int)scale - 1;
      i2 = (int)(t - 1.0);
    }
    scale = t + PositionVector_data[3];
    if (t > scale - 1.0) {
      i3 = 0;
      i4 = 0;
    } else {
      i3 = (int)t - 1;
      i4 = (int)(scale - 1.0);
    }
    t = scale + PositionVector_data[3];
    if (scale > t - 1.0) {
      i5 = 0;
      i6 = 0;
    } else {
      i5 = (int)scale - 1;
      i6 = (int)(t - 1.0);
    }
    if (t > (t + 4.0) - 1.0) {
      i7 = 0;
      i8 = -1;
    } else {
      i7 = (int)t - 1;
      i8 = (int)t + 2;
    }
    xt_b.size[0] = 1;
    loop_ub = i8 - i7;
    xt_b.size[1] = loop_ub + 1;
    for (i8 = 0; i8 <= loop_ub; i8++) {
      xt_b.data[i8] = PositionVector_data[i7 + i8];
    }
    if (t + 4.0 > ((t + 4.0) + 4.0) - 1.0) {
      i7 = 0;
      i8 = -1;
    } else {
      i7 = (int)(t + 4.0) - 1;
      i8 = (int)(t + 4.0) + 2;
    }
    yt_b.size[0] = 1;
    loop_ub = i8 - i7;
    yt_b.size[1] = loop_ub + 1;
    for (i8 = 0; i8 <= loop_ub; i8++) {
      yt_b.data[i8] = PositionVector_data[i7 + i8];
    }
    /*  [PosH, Heading, UWBAnc_Full] = UWBPosition_V3(s_time, Ln, LnC, Nanchor,
     * SensorNum, RxIDUWB, RxDistOrig, xain, yain, zain, xt_b, yt_b, zt_b); */
    b_PositionVector_size[0] = 1;
    loop_ub = i1 - i;
    b_PositionVector_size[1] = loop_ub;
    for (i1 = 0; i1 < loop_ub; i1++) {
      b_PositionVector_data[i1] = PositionVector_data[i + i1];
    }
    c_PositionVector_size[0] = 1;
    loop_ub = FiFoSLAMhead_tmp - FiFoSLAMpos_tmp;
    c_PositionVector_size[1] = loop_ub;
    for (i = 0; i < loop_ub; i++) {
      c_PositionVector_data[i] = PositionVector_data[FiFoSLAMpos_tmp + i];
    }
    d_PositionVector_size[0] = 1;
    loop_ub = i2 - trueCount;
    d_PositionVector_size[1] = loop_ub;
    for (i = 0; i < loop_ub; i++) {
      d_PositionVector_data[i] = PositionVector_data[trueCount + i];
    }
    e_PositionVector_size[0] = 1;
    loop_ub = i4 - i3;
    e_PositionVector_size[1] = loop_ub;
    for (i = 0; i < loop_ub; i++) {
      e_PositionVector_data[i] = PositionVector_data[i3 + i];
    }
    loop_ub = i6 - i5;
    for (i = 0; i < loop_ub; i++) {
      f_PositionVector_data[i] = PositionVector_data[i5 + i];
    }
    UWBPosition_V4_1(
        PositionVector_data[0], PositionVector_data[2], PositionVector_data[4],
        PositionVector_data[1], b_PositionVector_data, b_PositionVector_size,
        c_PositionVector_data, c_PositionVector_size, d_PositionVector_data,
        d_PositionVector_size, e_PositionVector_data, e_PositionVector_size,
        f_PositionVector_data, xt_b.data, xt_b.size, yt_b.data, yt_b.size,
        PositionVector_data[(int)((t + 4.0) + 4.0) - 1], &PosH, &HeadingH,
        &scale);
    if ((PosH.re != 0.0) || (PosH.im != 0.0)) {
      for (i = 0; i < 99; i++) {
        FiFoUWBpos[i] = FiFoUWBpos[i + 1];
        FiFoUWBhead[i] = FiFoUWBhead[i + 1];
        FiFoUWBtime[i] = FiFoUWBtime[i + 1];
      }
      FiFoUWBpos[99] = PosH;
      FiFoUWBhead[99] = HeadingH;
      FiFoUWBtime[99] = PositionVector_data[0];
    }
    if (SLAMSet == 0.0) {
      PrevPosHF = PosH;
      HeadingHF = -HeadingH;
      if ((PosH.re != 0.0) || (PosH.im != 0.0)) {
        for (i = 0; i < 99; i++) {
          FiFoSLAMUWBpos[i] = FiFoSLAMUWBpos[i + 1];
          FiFoSLAMUWBhead[i] = FiFoSLAMUWBhead[i + 1];
          FiFoSLAMUWBtime[i] = FiFoSLAMUWBtime[i + 1];
        }
        FiFoSLAMUWBpos[99] = PosH;
        FiFoSLAMUWBhead[99] = -HeadingH;
        FiFoSLAMUWBtime[99] = PositionVector_data[0];
      }
      /*  PosHF = PosH + (-0.065+0.74*j)*exp(j*HeadingH); */
    } else {
      PrevPosHF.re = 0.0;
      PrevPosHF.im = 0.0;
      HeadingHF = 0.0;
    }
    /*  */
  }
  /*  figure(123412);hold on;plot(PosHF,'ro'); */
  /*  PositionOut = [real(PosHF), imag(PosHF), 0, HeadingHF, GammHF, BetaHF,
   * Uncertainty(1,1), real(PosHF5), imag(PosHF5), HeadingHF5  ]; */
  PositionOut[0] = PrevPosHF.re;
  PositionOut[1] = PrevPosHF.im;
  PositionOut[2] = 0.0;
  PositionOut[3] = HeadingHF;
  PositionOut[4] = 0.0;
  PositionOut[5] = 0.0;
  PositionOut[6] = P[0];
  PositionOut[7] = PosH.re;
  PositionOut[8] = PosH.im;
  PositionOut[9] = HeadingH;
  /*  PositionOut = [real(PosHF5), imag(PosHF5), 0, -HeadingHF5, GammHF, BetaHF,
   * Uncertainty(1,1), real(PosH), imag(PosH), HeadingH  ]; */
  /*  */
}

/*
 * Arguments    : void
 * Return Type  : void
 */
void PositioningSystem_V5_1_init(void)
{
  static const double dv[9] = {
      -0.06611020732818,  -3.30859080761202,   -0.0075904315774107,
      3.30239075120085,   -0.213460995745502,  0.0339592364423471,
      -0.112716735233562, -0.0178754852105826, 0.999394394425305};
  int k;
  yt_b.size[1] = 0;
  xt_b.size[1] = 0;
  s_time_vec[0] = 0.0;
  s_time_vec[1] = 0.0;
  s_time_vec[2] = 0.0;
  s_time_vec[3] = 0.0;
  memset(&P[0], 0, 225U * sizeof(double));
  for (k = 0; k < 15; k++) {
    P[k + 15 * k] = 1.0;
  }
  memset(&FiFoUWBpos[0], 0, 100U * sizeof(creal_T));
  memset(&FiFoUWBhead[0], 0, 100U * sizeof(double));
  memset(&FiFoUWBtime[0], 0, 100U * sizeof(double));
  memset(&FiFoSLAMpos[0], 0, 300U * sizeof(double));
  memset(&FiFoSLAMhead[0], 0, 400U * sizeof(double));
  memset(&FiFoSLAMtime[0], 0, 100U * sizeof(double));
  memset(&FiFoSLAMUWBpos[0], 0, 100U * sizeof(creal_T));
  memset(&FiFoSLAMUWBhead[0], 0, 100U * sizeof(double));
  memset(&FiFoSLAMUWBtime[0], 0, 100U * sizeof(double));
  memset(&FiFoIMUacc[0], 0, 12U * sizeof(double));
  memset(&FiFoIMUgyro[0], 0, 12U * sizeof(double));
  memset(&FiFoSLAMEulDiff[0], 0, 300U * sizeof(double));
  firstV = 0.0;
  /*  load("MapParams2.mat"); */
  SLAMSet = 0.0;
  CAMPos.re = -0.06;
  CAMPos.im = -0.77;
  memcpy(&sA[0], &dv[0], 9U * sizeof(double));
  SLAMposInit[0] = 48.2402110895784;
  SLAMposInit[1] = 5.22590479979198;
  SLAMposInit[2] = 0.0;
}

/*
 * File trailer for PositioningSystem_V5_1.c
 *
 * [EOF]
 */
