/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: find.h
 *
 * MATLAB Coder version            : 5.5
 * C/C++ source code generated on  : 24-Jul-2024 13:01:20
 */

#ifndef FIND_H
#define FIND_H

/* Include Files */
#include "PositioningSystem_V5_1_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void eml_find(const boolean_T x[20000], emxArray_int32_T *i);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for find.h
 *
 * [EOF]
 */
