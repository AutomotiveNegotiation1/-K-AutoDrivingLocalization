/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: PositioningSystem_V5_1_initialize.c
 *
 * MATLAB Coder version            : 5.5
 * C/C++ source code generated on  : 24-Jul-2024 13:01:20
 */

/* Include Files */
#include "PositioningSystem_V5_1_initialize.h"
#include "EKF_UWB_SLAM_4.h"
#include "EKF_UWB_SLAM_IMU_1.h"
#include "PositioningSystem_V5_1.h"
#include "PositioningSystem_V5_1_data.h"
#include "UWBPosition_V4_1.h"
#include "rt_nonfinite.h"

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : void
 */
void PositioningSystem_V5_1_initialize(void)
{
  rt_InitInfAndNaN();
  s_time_prev_not_empty_init();
  PositioningSystem_V5_1_init();
  EKF_UWB_SLAM_IMU_1_init();
  EKF_UWB_SLAM_4_init();
  UWBPosition_V4_1_init();
  isInitialized_PositioningSystem_V5_1 = true;
}

/*
 * File trailer for PositioningSystem_V5_1_initialize.c
 *
 * [EOF]
 */
