/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: makePredA_3D_Simple.c
 *
 * MATLAB Coder version            : 5.5
 * C/C++ source code generated on  : 24-Jul-2024 13:01:20
 */

/* Include Files */
#include "makePredA_3D_Simple.h"
#include "rt_nonfinite.h"
#include <math.h>
#include <string.h>

/* Function Definitions */
/*
 * Arguments    : const double Xhat[15]
 *                const double acc[3]
 *                const double p[3]
 *                double A[225]
 * Return Type  : void
 */
void makePredA_3D_Simple(const double Xhat[15], const double acc[3],
                         const double p[3], double A[225])
{
  static const double y[9] = {0.005, 0.0, 0.0, 0.0,  0.005,
                              0.0,   0.0, 0.0, 0.005};
  static const signed char b[3] = {-1, 0, 0};
  static const signed char b_b[3] = {0, -1, 0};
  static const signed char c_b[3] = {0, 0, -1};
  double RotMat[9];
  double RotMatRalp[9];
  double RotMatRbet[9];
  double RotMatRgam[9];
  double ZyroUpdateRbet[9];
  double b_tmp[3];
  double A_tmp;
  double RotMatRalp_tmp;
  double RotMat_tmp;
  double RotMat_tmp_tmp;
  double RotMat_tmp_tmp_tmp;
  double ZyroUpdate_tmp;
  double b_A_tmp;
  double b_RotMatRalp_tmp;
  double b_RotMat_tmp;
  double b_RotMat_tmp_tmp;
  double c_A_tmp;
  double c_RotMat_tmp;
  double d;
  double d1;
  double d10;
  double d11;
  double d12;
  double d13;
  double d14;
  double d15;
  double d16;
  double d17;
  double d18;
  double d19;
  double d2;
  double d20;
  double d21;
  double d22;
  double d23;
  double d24;
  double d25;
  double d3;
  double d4;
  double d5;
  double d6;
  double d7;
  double d8;
  double d9;
  double d_A_tmp;
  double e_A_tmp;
  double f_A_tmp;
  double g_A_tmp;
  double h_A_tmp;
  double i_A_tmp;
  double j_A_tmp;
  double k_A_tmp;
  double l_A_tmp;
  double m_A_tmp;
  double n_A_tmp;
  double o_A_tmp;
  double p_A_tmp;
  double q_A_tmp;
  double r_A_tmp;
  int A_tmp_tmp;
  int ZyroUpdateRbet_tmp;
  int b_A_tmp_tmp;
  int c_RotMatRalp_tmp;
  int i;
  int k;
  memset(&A[0], 0, 225U * sizeof(double));
  for (k = 0; k < 15; k++) {
    A[k + 15 * k] = 1.0;
  }
  RotMat_tmp = sin(Xhat[9]);
  RotMat_tmp_tmp = cos(Xhat[11]);
  b_RotMat_tmp = cos(Xhat[9]);
  b_RotMat_tmp_tmp = sin(Xhat[11]);
  RotMat_tmp_tmp_tmp = cos(Xhat[10]);
  c_RotMat_tmp = sin(Xhat[10]);
  RotMat[0] = RotMat_tmp * RotMat_tmp_tmp_tmp;
  RotMat[3] = RotMat_tmp * c_RotMat_tmp * b_RotMat_tmp_tmp +
              b_RotMat_tmp * RotMat_tmp_tmp;
  RotMat[6] = sin(Xhat[9]) * sin(Xhat[10]) * RotMat_tmp_tmp -
              b_RotMat_tmp * b_RotMat_tmp_tmp;
  RotMat[1] = b_RotMat_tmp * RotMat_tmp_tmp_tmp;
  RotMat[4] = b_RotMat_tmp * c_RotMat_tmp * b_RotMat_tmp_tmp -
              RotMat_tmp * RotMat_tmp_tmp;
  RotMat[7] = cos(Xhat[9]) * sin(Xhat[10]) * RotMat_tmp_tmp +
              RotMat_tmp * b_RotMat_tmp_tmp;
  RotMat[2] = -c_RotMat_tmp;
  RotMat[5] = RotMat_tmp_tmp_tmp * b_RotMat_tmp_tmp;
  RotMat[8] = RotMat_tmp_tmp_tmp * RotMat_tmp_tmp;
  RotMatRalp_tmp = cos(Xhat[9]) * cos(Xhat[10]);
  RotMatRalp[0] = RotMatRalp_tmp;
  RotMatRalp[3] = cos(Xhat[9]) * sin(Xhat[10]) * sin(Xhat[11]) -
                  sin(Xhat[9]) * cos(Xhat[11]);
  b_RotMatRalp_tmp = cos(Xhat[9]) * sin(Xhat[10]) * cos(Xhat[11]) +
                     sin(Xhat[9]) * sin(Xhat[11]);
  RotMatRalp[6] = b_RotMatRalp_tmp;
  RotMatRalp[1] = -RotMat_tmp * RotMat_tmp_tmp_tmp;
  RotMatRalp[4] = -sin(Xhat[9]) * c_RotMat_tmp * b_RotMat_tmp_tmp -
                  cos(Xhat[9]) * cos(Xhat[11]);
  RotMat_tmp = -sin(Xhat[9]) * sin(Xhat[10]);
  RotMatRalp[7] = RotMat_tmp * RotMat_tmp_tmp + cos(Xhat[9]) * sin(Xhat[11]);
  RotMatRbet[0] = RotMat_tmp;
  RotMat_tmp = sin(Xhat[9]) * cos(Xhat[10]);
  RotMatRbet[3] = RotMat_tmp * b_RotMat_tmp_tmp;
  RotMatRbet[6] = RotMat_tmp * RotMat_tmp_tmp;
  RotMatRbet[1] = -b_RotMat_tmp * c_RotMat_tmp;
  RotMatRbet[4] = RotMatRalp_tmp * b_RotMat_tmp_tmp;
  RotMatRbet[7] = RotMatRalp_tmp * RotMat_tmp_tmp;
  RotMatRbet[2] = -RotMat_tmp_tmp_tmp;
  RotMatRbet[5] = -sin(Xhat[10]) * b_RotMat_tmp_tmp;
  RotMatRbet[8] = -sin(Xhat[10]) * RotMat_tmp_tmp;
  RotMatRgam[0] = 0.0;
  RotMatRgam[3] = sin(Xhat[9]) * sin(Xhat[10]) * cos(Xhat[11]) -
                  cos(Xhat[9]) * sin(Xhat[11]);
  RotMatRgam[6] = -sin(Xhat[9]) * sin(Xhat[10]) * sin(Xhat[11]) -
                  cos(Xhat[9]) * cos(Xhat[11]);
  RotMatRgam[1] = 0.0;
  RotMatRgam[4] = b_RotMatRalp_tmp;
  RotMatRgam[7] = -cos(Xhat[9]) * sin(Xhat[10]) * b_RotMat_tmp_tmp +
                  sin(Xhat[9]) * cos(Xhat[11]);
  RotMatRgam[2] = 0.0;
  RotMatRgam[5] = cos(Xhat[10]) * cos(Xhat[11]);
  RotMatRgam[8] = -cos(Xhat[10]) * b_RotMat_tmp_tmp;
  ZyroUpdate_tmp = tan(Xhat[10]);
  RotMat_tmp = RotMat_tmp_tmp_tmp * RotMat_tmp_tmp_tmp;
  ZyroUpdateRbet[3] = b_RotMat_tmp_tmp / RotMat_tmp;
  ZyroUpdateRbet[6] = RotMat_tmp_tmp / RotMat_tmp;
  ZyroUpdateRbet[5] = b_RotMat_tmp_tmp * c_RotMat_tmp / RotMat_tmp;
  ZyroUpdateRbet[8] = RotMat_tmp_tmp * c_RotMat_tmp / RotMat_tmp;
  A_tmp = 0.0;
  b_A_tmp = 0.0;
  c_A_tmp = 0.0;
  b_tmp[0] = acc[0] - Xhat[6];
  b_tmp[1] = acc[1] - Xhat[7];
  b_tmp[2] = acc[2] - Xhat[8];
  d = 0.0;
  RotMat_tmp = 0.0;
  b_RotMat_tmp = 0.0;
  d_A_tmp = 0.0;
  e_A_tmp = 0.0;
  f_A_tmp = 0.0;
  RotMatRalp_tmp = 0.0;
  b_RotMatRalp_tmp = 0.0;
  c_RotMat_tmp = 0.0;
  g_A_tmp = 0.0;
  h_A_tmp = 0.0;
  i_A_tmp = 0.0;
  d1 = 0.0;
  d2 = 0.0;
  d3 = 0.0;
  j_A_tmp = 0.0;
  k_A_tmp = 0.0;
  l_A_tmp = 0.0;
  d4 = 0.0;
  d5 = 0.0;
  d6 = 0.0;
  m_A_tmp = 0.0;
  n_A_tmp = 0.0;
  o_A_tmp = 0.0;
  d7 = 0.0;
  d8 = 0.0;
  d9 = 0.0;
  p_A_tmp = 0.0;
  q_A_tmp = 0.0;
  r_A_tmp = 0.0;
  d10 = 0.0;
  d11 = 0.0;
  d12 = 0.0;
  for (i = 0; i < 3; i++) {
    c_RotMatRalp_tmp = 3 * i + 2;
    RotMatRalp[c_RotMatRalp_tmp] = 0.0;
    ZyroUpdateRbet_tmp = 3 * i + 1;
    ZyroUpdateRbet[ZyroUpdateRbet_tmp] = 0.0;
    k = 15 * (i + 3);
    A[k] = y[3 * i];
    A[k + 1] = y[ZyroUpdateRbet_tmp];
    A[k + 2] = y[c_RotMatRalp_tmp];
    d13 = RotMat[3 * i];
    d14 = 1.25E-5 * d13;
    k = b[i];
    A_tmp += d14 * (double)k;
    A_tmp_tmp = b_b[i];
    b_A_tmp += d14 * (double)A_tmp_tmp;
    b_A_tmp_tmp = c_b[i];
    c_A_tmp += d14 * (double)b_A_tmp_tmp;
    d15 = RotMatRalp[3 * i];
    d16 = b_tmp[i];
    d += 1.25E-5 * d15 * d16;
    d17 = RotMatRbet[3 * i];
    RotMat_tmp += 1.25E-5 * d17 * d16;
    d18 = RotMatRgam[3 * i];
    b_RotMat_tmp += 1.25E-5 * d18 * d16;
    d19 = RotMat[ZyroUpdateRbet_tmp];
    d14 = 1.25E-5 * d19;
    d_A_tmp += d14 * (double)k;
    e_A_tmp += d14 * (double)A_tmp_tmp;
    f_A_tmp += d14 * (double)b_A_tmp_tmp;
    d20 = RotMatRalp[ZyroUpdateRbet_tmp];
    RotMatRalp_tmp += 1.25E-5 * d20 * d16;
    d21 = RotMatRbet[ZyroUpdateRbet_tmp];
    b_RotMatRalp_tmp += 1.25E-5 * d21 * d16;
    d22 = RotMatRgam[ZyroUpdateRbet_tmp];
    c_RotMat_tmp += 1.25E-5 * d22 * d16;
    d23 = RotMat[c_RotMatRalp_tmp];
    d14 = 1.25E-5 * d23;
    g_A_tmp += d14 * (double)k;
    h_A_tmp += d14 * (double)A_tmp_tmp;
    i_A_tmp += d14 * (double)b_A_tmp_tmp;
    d1 += 0.0 * d16;
    d24 = RotMatRbet[c_RotMatRalp_tmp];
    d2 += 1.25E-5 * d24 * d16;
    d25 = RotMatRgam[c_RotMatRalp_tmp];
    d3 += 1.25E-5 * d25 * d16;
    d14 = 0.005 * d13;
    j_A_tmp += d14 * (double)k;
    k_A_tmp += d14 * (double)A_tmp_tmp;
    l_A_tmp += d14 * (double)b_A_tmp_tmp;
    d4 += 0.005 * d15 * d16;
    d5 += 0.005 * d17 * d16;
    d6 += 0.005 * d18 * d16;
    d14 = 0.005 * d19;
    m_A_tmp += d14 * (double)k;
    n_A_tmp += d14 * (double)A_tmp_tmp;
    o_A_tmp += d14 * (double)b_A_tmp_tmp;
    d7 += 0.005 * d20 * d16;
    d8 += 0.005 * d21 * d16;
    d9 += 0.005 * d22 * d16;
    d14 = 0.005 * d23;
    p_A_tmp += d14 * (double)k;
    q_A_tmp += d14 * (double)A_tmp_tmp;
    r_A_tmp += d14 * (double)b_A_tmp_tmp;
    d10 += 0.0 * d16;
    d11 += 0.005 * d24 * d16;
    d12 += 0.005 * d25 * d16;
  }
  A[90] = A_tmp;
  A[105] = b_A_tmp;
  A[120] = c_A_tmp;
  A[135] = d;
  A[150] = RotMat_tmp;
  A[165] = b_RotMat_tmp;
  A[91] = d_A_tmp;
  A[106] = e_A_tmp;
  A[121] = f_A_tmp;
  A[136] = RotMatRalp_tmp;
  A[151] = b_RotMatRalp_tmp;
  A[166] = c_RotMat_tmp;
  A[92] = g_A_tmp;
  A[107] = h_A_tmp;
  A[122] = i_A_tmp;
  A[137] = d1;
  A[152] = d2;
  A[167] = d3;
  A[93] = j_A_tmp;
  A[108] = k_A_tmp;
  A[123] = l_A_tmp;
  A[138] = d4;
  A[153] = d5;
  A[168] = d6;
  A[94] = m_A_tmp;
  A[109] = n_A_tmp;
  A[124] = o_A_tmp;
  A[139] = d7;
  A[154] = d8;
  A[169] = d9;
  A[95] = p_A_tmp;
  A[110] = q_A_tmp;
  A[125] = r_A_tmp;
  A[140] = d10;
  A[155] = d11;
  A[170] = d12;
  b_tmp[1] = p[1] - Xhat[13];
  b_tmp[2] = p[2] - Xhat[14];
  A_tmp = 0.0 * (p[0] - Xhat[12]);
  b_A_tmp = (A_tmp + 0.0 * b_tmp[1]) + 0.0 * b_tmp[2];
  c_A_tmp = 0.005 * (RotMat_tmp_tmp / RotMat_tmp_tmp_tmp);
  A[174] = ((A_tmp + c_A_tmp * b_tmp[1]) +
            0.005 * (-b_RotMat_tmp_tmp / RotMat_tmp_tmp_tmp) * b_tmp[2]) +
           1.0;
  A[159] = (A_tmp + 0.005 * ZyroUpdateRbet[5] * b_tmp[1]) +
           0.005 * ZyroUpdateRbet[8] * b_tmp[2];
  A[144] = b_A_tmp;
  A[145] = b_A_tmp;
  A[146] = b_A_tmp + 1.0;
  d = 0.005 * (b_RotMat_tmp_tmp / RotMat_tmp_tmp_tmp);
  b_RotMat_tmp = d * 0.0;
  b_A_tmp = -d;
  d = 0.005 * RotMat_tmp_tmp;
  RotMat_tmp = d * 0.0;
  d_A_tmp = -d;
  d = 0.005 * (b_RotMat_tmp_tmp * ZyroUpdate_tmp);
  e_A_tmp = d * 0.0 - 0.005;
  f_A_tmp = -d;
  g_A_tmp = d * 0.0;
  b_A_tmp += c_A_tmp * 0.0;
  d = 0.005 * -b_RotMat_tmp_tmp;
  h_A_tmp = RotMat_tmp + d * 0.0;
  d_A_tmp += d * 0.0;
  i_A_tmp = RotMat_tmp - d;
  d = 0.005 * (RotMat_tmp_tmp * ZyroUpdate_tmp);
  e_A_tmp += d * 0.0;
  f_A_tmp += d * 0.0;
  g_A_tmp -= d;
  A[189] = b_RotMat_tmp + c_A_tmp * 0.0;
  A[204] = b_A_tmp;
  A[219] = b_RotMat_tmp - c_A_tmp;
  A[175] = (A_tmp + 0.005 * -sin(Xhat[11]) * b_tmp[1]) +
           0.005 * -RotMat_tmp_tmp * b_tmp[2];
  A[160] = ((A_tmp + 0.0 * b_tmp[1]) + 0.0 * b_tmp[2]) + 1.0;
  A[190] = h_A_tmp;
  A[205] = d_A_tmp;
  A[220] = i_A_tmp;
  A[176] = (A_tmp + 0.005 * (cos(Xhat[11]) * tan(Xhat[10])) * b_tmp[1]) +
           0.005 * (-b_RotMat_tmp_tmp * ZyroUpdate_tmp) * b_tmp[2];
  A[161] = (A_tmp + 0.005 * ZyroUpdateRbet[3] * b_tmp[1]) +
           0.005 * ZyroUpdateRbet[6] * b_tmp[2];
  A[191] = e_A_tmp;
  A[206] = f_A_tmp;
  A[221] = g_A_tmp;
}

/*
 * File trailer for makePredA_3D_Simple.c
 *
 * [EOF]
 */
