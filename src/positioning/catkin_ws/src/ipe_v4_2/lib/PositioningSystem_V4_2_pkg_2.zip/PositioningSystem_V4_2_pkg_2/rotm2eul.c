/*
 * rotm2eul.c
 *
 * Code generation for function 'rotm2eul'
 *
 */

/* Include files */
#include "rotm2eul.h"
#include "PositioningSystem_V4_2_rtwutil.h"
#include "rt_nonfinite.h"
#include <math.h>

/* Function Definitions */
void rotm2eul(const double b_R[9], double eul[3])
{
  double cy;
  double cySq;
  cySq = b_R[0] * b_R[0] + b_R[1] * b_R[1];
  cy = sqrt(cySq);
  eul[0] = rt_atan2d_snf(b_R[5], b_R[8]);
  eul[1] = rt_atan2d_snf(-b_R[2], cy);
  eul[2] = rt_atan2d_snf(b_R[1], b_R[0]);
  if (cySq < 2.2204460492503131E-15) {
    eul[0] = rt_atan2d_snf(-b_R[7], b_R[4]);
    eul[1] = rt_atan2d_snf(-b_R[2], cy);
    eul[2] = 0.0;
  }
  cySq = eul[0];
  eul[0] = eul[2];
  eul[2] = cySq;
}

/* End of code generation (rotm2eul.c) */
