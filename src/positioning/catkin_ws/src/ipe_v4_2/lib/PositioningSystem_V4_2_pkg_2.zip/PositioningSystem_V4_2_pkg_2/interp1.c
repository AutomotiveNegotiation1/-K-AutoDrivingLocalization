/*
 * interp1.c
 *
 * Code generation for function 'interp1'
 *
 */

/* Include files */
#include "interp1.h"
#include "rt_nonfinite.h"
#include "rt_nonfinite.h"
#include <string.h>

/* Function Definitions */
double interp1(const double varargin_1_data[], const int varargin_1_size[2],
               const double varargin_2_data[], const int varargin_2_size[2],
               double varargin_3)
{
  double x_data[100];
  double y_data[100];
  double Vq;
  int b_j1;
  int high_i;
  int j2;
  int nx;
  j2 = varargin_2_size[1];
  if (j2 - 1 >= 0) {
    memcpy(&y_data[0], &varargin_2_data[0], (unsigned int)j2 * sizeof(double));
  }
  high_i = varargin_1_size[1];
  j2 = varargin_1_size[1];
  if (j2 - 1 >= 0) {
    memcpy(&x_data[0], &varargin_1_data[0], (unsigned int)j2 * sizeof(double));
  }
  nx = varargin_1_size[1] - 1;
  j2 = 0;
  int exitg1;
  do {
    exitg1 = 0;
    if (j2 <= nx) {
      if (rtIsNaN(varargin_1_data[j2])) {
        exitg1 = 1;
      } else {
        j2++;
      }
    } else {
      double xtmp;
      int mid_i;
      if (varargin_1_data[1] < varargin_1_data[0]) {
        mid_i = (nx + 1) >> 1;
        for (b_j1 = 0; b_j1 < mid_i; b_j1++) {
          xtmp = x_data[b_j1];
          j2 = nx - b_j1;
          x_data[b_j1] = x_data[j2];
          x_data[j2] = xtmp;
        }
        mid_i = varargin_2_size[1] >> 1;
        for (b_j1 = 0; b_j1 < mid_i; b_j1++) {
          j2 = (varargin_2_size[1] - b_j1) - 1;
          xtmp = y_data[b_j1];
          y_data[b_j1] = y_data[j2];
          y_data[j2] = xtmp;
        }
      }
      Vq = rtNaN;
      if ((!rtIsNaN(varargin_3)) && (!(varargin_3 > x_data[high_i - 1])) &&
          (!(varargin_3 < x_data[0]))) {
        j2 = 1;
        nx = 2;
        while (high_i > nx) {
          mid_i = (j2 >> 1) + (high_i >> 1);
          if (((j2 & 1) == 1) && ((high_i & 1) == 1)) {
            mid_i++;
          }
          if (varargin_3 >= x_data[mid_i - 1]) {
            j2 = mid_i;
            nx = mid_i + 1;
          } else {
            high_i = mid_i;
          }
        }
        xtmp = x_data[j2 - 1];
        xtmp = (varargin_3 - xtmp) / (x_data[j2] - xtmp);
        if (xtmp == 0.0) {
          Vq = y_data[j2 - 1];
        } else if (xtmp == 1.0) {
          Vq = y_data[j2];
        } else {
          Vq = y_data[j2 - 1];
          if (!(Vq == y_data[j2])) {
            Vq = (1.0 - xtmp) * Vq + xtmp * y_data[j2];
          }
        }
      }
      exitg1 = 1;
    }
  } while (exitg1 == 0);
  return Vq;
}

/* End of code generation (interp1.c) */
