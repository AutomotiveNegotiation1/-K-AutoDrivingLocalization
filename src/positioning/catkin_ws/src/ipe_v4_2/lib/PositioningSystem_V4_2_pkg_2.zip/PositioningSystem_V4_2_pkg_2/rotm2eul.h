/*
 * rotm2eul.h
 *
 * Code generation for function 'rotm2eul'
 *
 */

#ifndef ROTM2EUL_H
#define ROTM2EUL_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void rotm2eul(const double b_R[9], double eul[3]);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (rotm2eul.h) */
