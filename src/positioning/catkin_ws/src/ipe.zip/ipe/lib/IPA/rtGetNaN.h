/*
 * rtGetNaN.h
 *
 * Code generation for function 'PositioningSystem_V2_3'
 *
 */

#ifndef RTGETNAN_H
#define RTGETNAN_H

/* Include files */
#include "rtwtypes.h"

#ifdef __cplusplus
extern "C" {
#endif

extern real_T rtGetNaN(void);
extern real32_T rtGetNaNF(void);

#ifdef __cplusplus
}
#endif
#endif
/* End of code generation (rtGetNaN.h) */
