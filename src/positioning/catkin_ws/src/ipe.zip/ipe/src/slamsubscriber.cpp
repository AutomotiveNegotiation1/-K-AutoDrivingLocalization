
#include <slamsubscriber.h> 

//double slam_x;
//double slam_y;
//double slam_z; 
//double slam_q1;
//double slam_q2;
//double slam_q3;
//double slam_q4; 

//ros::Publisher pub_slam;
//std::ostringstream topic_name_stream;


SlamSubscriber::SlamSubscriber(ros::NodeHandle& _node, IPECallback* _ipeCallback)
    : o_ipeCallback(_ipeCallback)
{
    setupSubscriber(_node);
    pub_slam = _node.advertise<geometry_msgs::PoseStamped>("/ipe/pose_slam2uwb", 10);
    socketManager = SocketManager::getInstance(); // <-- Add this line to initialize the socketManager
}

SlamSubscriber::~SlamSubscriber() {
}

void SlamSubscriber::operator()(IPEDataPacket &packet, double timestamp, SensorData* data) {
    std::cout << "slam process Packet Data " << std::endl;
    processPacketData(packet, timestamp, data);
}

void SlamSubscriber::registerCallback(const std::function<void(int)>& _callback) {
    callbacks.push_back(_callback);
}

std::string SlamSubscriber::getPacketFrameID() {
    return packetFrameID = m_frameId;
}

void SlamSubscriber::setupSubscriber(ros::NodeHandle& node) {
    
    topic_name_stream << "/orb_slam3/camera_pose";
    std::string topic_name = topic_name_stream.str();
    ROS_INFO("topic_name-->%s", topic_name.c_str());
    
    sub_slam = node.subscribe<geometry_msgs::PoseStamped>(topic_name, 10, &SlamSubscriber::_callback, this);
}


void SlamSubscriber::_callback(const geometry_msgs::PoseStamped::ConstPtr& msg) {

    m_ipeDataPacket = IPEDataPacket(msg);
    //std::cout << "SLAM test " << std::endl;
    m_ipeDataPacket.frame_id = "slam";
    if (o_ipeCallback) {
        o_ipeCallback->onLiveDataAvailable(m_ipeDataPacket);
    } else {
        ROS_WARN("m_kapCallback is a nullptr!");
    }
}

/*
void SlamSubscriber::sendUDPMessage(double center_x, double center_y, double heading) {
    std::ostringstream oss;
    oss << center_x << "," << center_y << "," << heading;
    std::string result = oss.str();
    socketManager->broadcastUDPMessage(result);
}
*/

void SlamSubscriber::rviz_match(double new_pos[3]) 
{
    geometry_msgs::PoseStamped ps;
    
    ps.header.frame_id = "slam";
    ps.pose.position.x = new_pos[0];
    ps.pose.position.y = new_pos[1];
    ps.pose.position.z = new_pos[2];

    pub_slam.publish(ps);
}

void SlamSubscriber::processPacketData(IPEDataPacket &packet, double timestamp, SensorData* newUWBData) 
{
    // 2024_06_04 (joo.hy)

    //std:: cout << "Process Slam Packet Data 1" << std:: endl; 
    
    if (packet.slam_x.empty()){
        std:: cout << "packet is emtpy" << std:: endl; 
        return;
    }
    double slam_x = packet.slam_x.back(); 
    double slam_y = packet.slam_y.back();
    double slam_z = packet.slam_z.back();

    //std:: cout << "Process Slam Packet Data 2" << std:: endl;  
   
    double Rotation_su[3][3] =
    {   
        { 7.8370, 1.8640, -13.4538},  
        {-1.8203, 7.5927, -5.4089},
        {0,0,0}
    };

    double Translation_su[3] = {40.2297, 12.7373, 0}; 
    double new_pos[3] = {0};  

    double slam_pos_out[3] = {slam_x, slam_y, 0.0};

    for (int i = 0; i < 3; i++) {
        new_pos[i] = 0; 
        for (int j = 0; j < 3; j++) {
            new_pos[i] += Rotation_su[i][j]*slam_pos_out[j];     
        }
        new_pos[i] += Translation_su[i] ; 
    }

    //ROS_INFO("slam2uwb--> (%d, %d, %d)", new_pos[0], new_pos[1], new_pos[2]);
    std:: cout << "new_pos[0]: "<< new_pos[0] << std::endl;
    std:: cout << "new_pos[1]: "<< new_pos[1] << std::endl;
    std:: cout << "new_pos[2]: "<< new_pos[2] << std::endl; 

    rviz_match(new_pos) ;   
}


    